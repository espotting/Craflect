# BRIEF - CRAFLECT FOUNDER DASHBOARD

## OBJECTIF
Implémenter le Dashboard Founder/Admin pour Craflect avec React + TypeScript + Tailwind CSS + shadcn/ui.

---

## DÉPENDANCES À INSTALLER

```bash
npm install recharts react-router-dom
```

---

## STRUCTURE DES FICHIERS

Le ZIP contient la structure suivante à copier dans `src/` :

```
src/
├── App.tsx                          # Router principal
├── pages/
│   ├── Overview.tsx                 # Dashboard principal (4 sections)
│   ├── Users.tsx                    # Gestion utilisateurs
│   ├── Subscriptions.tsx            # Gestion abonnements
│   ├── SystemLogs.tsx               # Logs système
│   └── Settings.tsx                 # Configuration
├── components/
│   ├── layout/
│   │   ├── Sidebar.tsx              # Navigation sidebar
│   │   └── Header.tsx               # Header avec search/notifications
│   └── dashboard/
│       ├── KPICard.tsx              # Composant carte KPI
│       ├── KPIPriorityBar.tsx       # Barre KPIs prioritaires
│       ├── PlatformHealthSection.tsx
│       ├── ProductUsageSection.tsx
│       ├── SaaSMetricsSection.tsx
│       └── GrowthMetricsSection.tsx
```

---

## ROUTES

| Route | Page |
|-------|------|
| `/system/founder` | Overview |
| `/system/founder/users` | Users |
| `/system/founder/subscriptions` | Subscriptions |
| `/system/founder/logs` | System Logs |
| `/system/founder/settings` | Settings |

---

## FONCTIONNALITÉS À IMPLÉMENTER

### 1. Overview (Page principale)
- **KPI Priority Bar** : MRR, DAU, Videos Created (7 days)
- **Platform Health** : Dataset metrics + graph ingestion
- **Product Usage** : DAU/WAU/MAU + content creation metrics
- **SaaS Metrics** : MRR, ARR, ARPU, churn, conversion
- **Growth Metrics** : Signups, retention, churn rate

### 2. Users
- Table avec recherche (nom/email)
- Filtres par plan (Free/Pro) et statut
- Actions : View Profile, Send Email, Suspend, Delete
- Pagination

### 3. Subscriptions
- Liste des abonnements avec MRR
- Filtres par statut (active/cancelled/past_due)
- Actions : View Invoices, Change Plan, Update Payment, Cancel

### 4. System Logs
- Logs avec niveaux (info/warning/error/success)
- Filtres par niveau
- Export
- Alertes visuelles (errors/warnings count)

### 5. Settings
- Tabs : General / API / Notifications / Security
- Maintenance mode toggle
- API keys management
- Email notification settings
- Security settings (2FA, session timeout)

---

## SÉCURITÉ (À IMPLÉMENTER)

### Protection des routes `/system/founder/*`
- Accessible uniquement aux comptes avec `role = 'admin'`
- Si non authentifié → redirect vers `/login`
- Si rôle insuffisant → redirect vers `/home`

### Middleware suggéré :
```typescript
// Vérifier le rôle admin avant d'accéder aux routes /system/founder
const isAdmin = user?.role === 'admin';
if (!isAdmin) return <Navigate to="/home" replace />;
```

---

## INTÉGRATION API (NEXT STEPS)

Remplacer les données mockées par les endpoints :

| Section | Endpoint suggéré |
|---------|------------------|
| Platform Health | `GET /api/admin/health/platform` |
| Product Usage | `GET /api/admin/metrics/usage` |
| SaaS Metrics | `GET /api/admin/metrics/saas` |
| Growth Metrics | `GET /api/admin/metrics/growth` |
| Users | `GET /api/admin/users` |
| Subscriptions | `GET /api/admin/subscriptions` |
| Logs | `GET /api/admin/logs` |
| Settings | `GET/PUT /api/admin/settings` |

---

## NOTES

- Les données sont actuellement en MOCK (à remplacer par les vraies API)
- Les KPIs "Patterns Detected" et "Opportunities Generated" affichent "Coming soon"
- Design responsive (mobile-friendly sidebar)
- Couleurs cohérentes avec le Dashboard User existant
