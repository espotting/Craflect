import { Sidebar } from '@/components/layout/Sidebar';
import { Header } from '@/components/layout/Header';
import { KPIPriorityBar } from '@/components/dashboard/KPIPriorityBar';
import { PlatformHealthSection } from '@/components/dashboard/PlatformHealthSection';
import { ProductUsageSection } from '@/components/dashboard/ProductUsageSection';
import { SaaSMetricsSection } from '@/components/dashboard/SaaSMetricsSection';
import { GrowthMetricsSection } from '@/components/dashboard/GrowthMetricsSection';

export function Overview() {
  return (
    <div className="min-h-screen bg-gray-50 flex">
      {/* Sidebar */}
      <Sidebar />

      {/* Main Content */}
      <div className="flex-1 flex flex-col min-h-screen overflow-hidden">
        {/* Header */}
        <Header />

        {/* Dashboard Content */}
        <main className="flex-1 overflow-y-auto p-6">
          <div className="max-w-7xl mx-auto space-y-10">
            {/* Page Title */}
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-2xl font-bold text-gray-900">Overview</h1>
                <p className="text-sm text-gray-500 mt-1">
                  Platform performance at a glance
                </p>
              </div>
              <div className="flex items-center gap-2 text-sm text-gray-500">
                <span className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse" />
                Live data
              </div>
            </div>

            {/* Priority KPIs Bar */}
            <KPIPriorityBar />

            {/* Divider */}
            <div className="border-t border-gray-200" />

            {/* Section 1: Platform Health */}
            <PlatformHealthSection />

            {/* Divider */}
            <div className="border-t border-gray-200" />

            {/* Section 2: Product Usage */}
            <ProductUsageSection />

            {/* Divider */}
            <div className="border-t border-gray-200" />

            {/* Section 3: SaaS Metrics */}
            <SaaSMetricsSection />

            {/* Divider */}
            <div className="border-t border-gray-200" />

            {/* Section 4: Growth Metrics */}
            <GrowthMetricsSection />

            {/* Footer */}
            <footer className="pt-8 pb-4 text-center text-sm text-gray-400">
              <p>Craflect Founder Dashboard • v1.0</p>
            </footer>
          </div>
        </main>
      </div>
    </div>
  );
}
