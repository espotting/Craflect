import { useState } from 'react';
import { Sidebar } from '@/components/layout/Sidebar';
import { Header } from '@/components/layout/Header';
import { Card } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Search, Download, Filter, AlertCircle, Info, AlertTriangle, CheckCircle } from 'lucide-react';

// Mock logs data
const mockLogs = [
  { id: 1, timestamp: '2024-06-15 14:32:18', level: 'info', message: 'User login successful', user: 'alice@example.com', source: 'auth' },
  { id: 2, timestamp: '2024-06-15 14:30:45', level: 'warning', message: 'API rate limit approaching', user: 'system', source: 'api' },
  { id: 3, timestamp: '2024-06-15 14:28:12', level: 'error', message: 'Video classification failed', user: 'bob@example.com', source: 'engine' },
  { id: 4, timestamp: '2024-06-15 14:25:33', level: 'info', message: 'New subscription created', user: 'carla@example.com', source: 'billing' },
  { id: 5, timestamp: '2024-06-15 14:20:01', level: 'info', message: 'Dataset ingestion completed', user: 'system', source: 'engine' },
  { id: 6, timestamp: '2024-06-15 14:15:22', level: 'success', message: 'Payment processed', user: 'emma@example.com', source: 'billing' },
  { id: 7, timestamp: '2024-06-15 14:10:55', level: 'warning', message: 'High memory usage detected', user: 'system', source: 'system' },
  { id: 8, timestamp: '2024-06-15 14:05:18', level: 'info', message: 'User profile updated', user: 'grace@example.com', source: 'auth' },
  { id: 9, timestamp: '2024-06-15 14:00:00', level: 'info', message: 'Daily report generated', user: 'system', source: 'system' },
  { id: 10, timestamp: '2024-06-15 13:55:42', level: 'error', message: 'Database connection timeout', user: 'system', source: 'database' },
];

const levelColors: Record<string, string> = {
  info: 'bg-blue-100 text-blue-700 border-blue-200',
  warning: 'bg-amber-100 text-amber-700 border-amber-200',
  error: 'bg-red-100 text-red-700 border-red-200',
  success: 'bg-emerald-100 text-emerald-700 border-emerald-200',
};

const levelIcons: Record<string, React.ReactNode> = {
  info: <Info className="w-4 h-4 text-blue-600" />,
  warning: <AlertTriangle className="w-4 h-4 text-amber-600" />,
  error: <AlertCircle className="w-4 h-4 text-red-600" />,
  success: <CheckCircle className="w-4 h-4 text-emerald-600" />,
};

export function SystemLogs() {
  const [searchQuery, setSearchQuery] = useState('');
  const [levelFilter, setLevelFilter] = useState<string | null>(null);

  const filteredLogs = mockLogs.filter((log) => {
    const matchesSearch =
      log.message.toLowerCase().includes(searchQuery.toLowerCase()) ||
      log.user.toLowerCase().includes(searchQuery.toLowerCase()) ||
      log.source.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesLevel = levelFilter ? log.level === levelFilter : true;
    return matchesSearch && matchesLevel;
  });

  const errorCount = mockLogs.filter((l) => l.level === 'error').length;
  const warningCount = mockLogs.filter((l) => l.level === 'warning').length;

  return (
    <div className="min-h-screen bg-gray-50 flex">
      <Sidebar />

      <div className="flex-1 flex flex-col min-h-screen overflow-hidden">
        <Header />

        <main className="flex-1 overflow-y-auto p-6">
          <div className="max-w-7xl mx-auto space-y-6">
            {/* Page Header */}
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-2xl font-bold text-gray-900">System Logs</h1>
                <p className="text-sm text-gray-500 mt-1">
                  Monitor platform activity and issues
                </p>
              </div>
              <div className="flex items-center gap-4">
                {errorCount > 0 && (
                  <div className="flex items-center gap-2 px-4 py-2 bg-red-50 rounded-lg">
                    <AlertCircle className="w-5 h-5 text-red-600" />
                    <span className="text-sm font-medium text-red-700">{errorCount} errors</span>
                  </div>
                )}
                {warningCount > 0 && (
                  <div className="flex items-center gap-2 px-4 py-2 bg-amber-50 rounded-lg">
                    <AlertTriangle className="w-5 h-5 text-amber-600" />
                    <span className="text-sm font-medium text-amber-700">{warningCount} warnings</span>
                  </div>
                )}
              </div>
            </div>

            {/* Search & Filters */}
            <Card className="p-4">
              <div className="flex items-center gap-4">
                <div className="relative flex-1 max-w-md">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                  <Input
                    placeholder="Search logs..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-10"
                  />
                </div>
                <div className="flex items-center gap-2">
                  <Filter className="w-4 h-4 text-gray-500" />
                  <span className="text-sm text-gray-500">Filter:</span>
                </div>
                <Button
                  variant={levelFilter === null ? 'default' : 'outline'}
                  size="sm"
                  onClick={() => setLevelFilter(null)}
                >
                  All
                </Button>
                <Button
                  variant={levelFilter === 'info' ? 'default' : 'outline'}
                  size="sm"
                  onClick={() => setLevelFilter('info')}
                >
                  Info
                </Button>
                <Button
                  variant={levelFilter === 'warning' ? 'default' : 'outline'}
                  size="sm"
                  onClick={() => setLevelFilter('warning')}
                >
                  Warning
                </Button>
                <Button
                  variant={levelFilter === 'error' ? 'default' : 'outline'}
                  size="sm"
                  onClick={() => setLevelFilter('error')}
                >
                  Error
                </Button>
                <Button variant="outline" className="ml-auto">
                  <Download className="w-4 h-4 mr-2" />
                  Export
                </Button>
              </div>
            </Card>

            {/* Logs Table */}
            <Card>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Timestamp</TableHead>
                    <TableHead>Level</TableHead>
                    <TableHead>Message</TableHead>
                    <TableHead>User</TableHead>
                    <TableHead>Source</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredLogs.map((log) => (
                    <TableRow key={log.id}>
                      <TableCell className="text-gray-600 font-mono text-sm">
                        {log.timestamp}
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          {levelIcons[log.level]}
                          <Badge variant="outline" className={levelColors[log.level]}>
                            {log.level}
                          </Badge>
                        </div>
                      </TableCell>
                      <TableCell className="text-gray-900">{log.message}</TableCell>
                      <TableCell className="text-gray-600">{log.user}</TableCell>
                      <TableCell>
                        <Badge variant="secondary" className="text-xs">
                          {log.source}
                        </Badge>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </Card>

            {/* Pagination */}
            <div className="flex items-center justify-between">
              <p className="text-sm text-gray-500">
                Showing {filteredLogs.length} of {mockLogs.length} logs
              </p>
              <div className="flex items-center gap-2">
                <Button variant="outline" size="sm" disabled>
                  Previous
                </Button>
                <Button variant="outline" size="sm">
                  Next
                </Button>
              </div>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}
