import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { Sparkles, ArrowRight, Check } from 'lucide-react';
import { Button } from '@/components/ui/button';

const steps = [
  { id: 'welcome', title: 'Welcome' },
  { id: 'role', title: 'Your Role' },
  { id: 'topics', title: 'Topics' },
  { id: 'analyzing', title: 'Analyzing' },
  { id: 'result', title: 'Your First Idea' },
];

export function Onboarding() {
  const navigate = useNavigate();
  const [currentStep, setCurrentStep] = useState(0);
  const [selectedRole, setSelectedRole] = useState<string | null>(null);
  const [selectedTopics, setSelectedTopics] = useState<string[]>([]);

  const roles = [
    { id: 'creator', label: 'Créateur de contenu', icon: '✨' },
    { id: 'marketer', label: 'Marketeur', icon: '📢' },
    { id: 'entrepreneur', label: 'Entrepreneur', icon: '💼' },
    { id: 'explorer', label: 'Explorateur de tendances', icon: '🔍' },
  ];

  const topics = [
    'AI tools', 'AI automation', 'Online business',
    'Entrepreneurship', 'Digital marketing', 'Ecommerce',
    'SaaS', 'Real estate', 'Finance', 'Crypto',
  ];

  const handleNext = () => {
    if (currentStep < steps.length - 1) {
      setCurrentStep(currentStep + 1);
    } else {
      navigate('/dashboard');
    }
  };

  const handleTopicToggle = (topic: string) => {
    if (selectedTopics.includes(topic)) {
      setSelectedTopics(selectedTopics.filter(t => t !== topic));
    } else if (selectedTopics.length < 3) {
      setSelectedTopics([...selectedTopics, topic]);
    }
  };

  const progress = ((currentStep + 1) / steps.length) * 100;

  return (
    <div className="min-h-screen bg-[#0a0a0f] flex flex-col">
      {/* Progress Bar */}
      <div className="w-full h-1 bg-gray-800">
        <motion.div
          className="h-full bg-gradient-to-r from-violet-600 to-fuchsia-600"
          initial={{ width: 0 }}
          animate={{ width: `${progress}%` }}
          transition={{ duration: 0.5 }}
        />
      </div>

      {/* Main Content */}
      <main className="flex-1 flex items-center justify-center px-6 py-12">
        <AnimatePresence mode="wait">
          {/* Step 1: Welcome */}
          {currentStep === 0 && (
            <motion.div
              key="welcome"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.5 }}
              className="text-center max-w-lg"
            >
              <motion.div
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ delay: 0.2, type: 'spring' }}
                className="w-20 h-20 bg-violet-500/10 rounded-2xl flex items-center justify-center mx-auto mb-8"
              >
                <Sparkles className="w-10 h-10 text-violet-500" />
              </motion.div>
              <h1 className="text-4xl font-bold text-white mb-4">
                Créer des vidéos virales avec l'IA
              </h1>
              <p className="text-gray-400 text-lg mb-8">
                Répondez à 3 questions rapides et obtenez votre première idée de vidéo virale.
              </p>
              <Button
                onClick={handleNext}
                className="h-14 px-8 bg-gradient-to-r from-violet-600 to-fuchsia-600 hover:from-violet-500 hover:to-fuchsia-500 text-white font-semibold rounded-xl transition-all"
              >
                Commencer
                <ArrowRight className="w-5 h-5 ml-2" />
              </Button>
            </motion.div>
          )}

          {/* Step 2: Role Selection */}
          {currentStep === 1 && (
            <motion.div
              key="role"
              initial={{ opacity: 0, x: 50 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -50 }}
              transition={{ duration: 0.5 }}
              className="w-full max-w-lg"
            >
              <h2 className="text-3xl font-bold text-white text-center mb-2">
                Comment créez-vous du contenu ?
              </h2>
              <p className="text-gray-400 text-center mb-8">
                Cela nous aide à personnaliser vos recommandations.
              </p>
              <div className="grid grid-cols-2 gap-4">
                {roles.map((role) => (
                  <motion.button
                    key={role.id}
                    onClick={() => setSelectedRole(role.id)}
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                    className={`p-6 rounded-2xl border-2 transition-all text-left ${
                      selectedRole === role.id
                        ? 'border-violet-500 bg-violet-500/10'
                        : 'border-gray-800 bg-[#1a1a24] hover:border-gray-700'
                    }`}
                  >
                    <span className="text-3xl mb-3 block">{role.icon}</span>
                    <span className={`font-medium ${selectedRole === role.id ? 'text-white' : 'text-gray-300'}`}>
                      {role.label}
                    </span>
                  </motion.button>
                ))}
              </div>
              <div className="mt-8 flex justify-center">
                <Button
                  onClick={handleNext}
                  disabled={!selectedRole}
                  className="h-14 px-8 bg-gradient-to-r from-violet-600 to-fuchsia-600 hover:from-violet-500 hover:to-fuchsia-500 text-white font-semibold rounded-xl transition-all disabled:opacity-50"
                >
                  Continue
                  <ArrowRight className="w-5 h-5 ml-2" />
                </Button>
              </div>
            </motion.div>
          )}

          {/* Step 3: Topics */}
          {currentStep === 2 && (
            <motion.div
              key="topics"
              initial={{ opacity: 0, x: 50 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -50 }}
              transition={{ duration: 0.5 }}
              className="w-full max-w-2xl"
            >
              <h2 className="text-3xl font-bold text-white text-center mb-2">
                Quels sujets de contenu créez-vous ?
              </h2>
              <p className="text-gray-400 text-center mb-8">
                Sélectionnez jusqu'à 3 niches pour que nous puissions trouver des idées virales pour vous.
              </p>
              <div className="flex flex-wrap justify-center gap-3 mb-8">
                {topics.map((topic) => {
                  const isSelected = selectedTopics.includes(topic);
                  return (
                    <motion.button
                      key={topic}
                      onClick={() => handleTopicToggle(topic)}
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                      className={`px-6 py-3 rounded-full border-2 transition-all ${
                        isSelected
                          ? 'border-violet-500 bg-violet-500/20 text-white'
                          : 'border-gray-700 bg-[#1a1a24] text-gray-400 hover:border-gray-600 hover:text-gray-300'
                      }`}
                    >
                      {isSelected && <Check className="w-4 h-4 inline mr-2" />}
                      {topic}
                    </motion.button>
                  );
                })}
              </div>
              <div className="text-center">
                <p className="text-gray-500 mb-4">
                  {selectedTopics.length}/3 sélectionné{selectedTopics.length !== 1 ? 's' : ''}
                </p>
                <Button
                  onClick={handleNext}
                  disabled={selectedTopics.length === 0}
                  className="h-14 px-8 bg-gradient-to-r from-violet-600 to-fuchsia-600 hover:from-violet-500 hover:to-fuchsia-500 text-white font-semibold rounded-xl transition-all disabled:opacity-50"
                >
                  Continue
                  <ArrowRight className="w-5 h-5 ml-2" />
                </Button>
              </div>
            </motion.div>
          )}

          {/* Step 4: Analyzing */}
          {currentStep === 3 && (
            <motion.div
              key="analyzing"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.5 }}
              className="text-center max-w-lg"
              onAnimationComplete={() => {
                setTimeout(() => handleNext(), 4000);
              }}
            >
              <motion.div
                animate={{ rotate: 360 }}
                transition={{ duration: 2, repeat: Infinity, ease: 'linear' }}
                className="w-16 h-16 border-4 border-violet-500/20 border-t-violet-500 rounded-full mx-auto mb-8"
              />
              <h2 className="text-3xl font-bold text-white mb-6">
                Analyse des patterns viraux dans votre niche...
              </h2>
              <div className="space-y-3">
                {[
                  'Analyse des hooks tendances',
                  'Analyse des formats viraux',
                  'Analyse de l\'engagement dans la niche',
                  'Calcul du score de viralité',
                ].map((item, index) => (
                  <motion.div
                    key={item}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: index * 0.5 }}
                    className="flex items-center gap-3 text-gray-400"
                  >
                    <motion.div
                      initial={{ scale: 0 }}
                      animate={{ scale: 1 }}
                      transition={{ delay: index * 0.5 + 0.3 }}
                      className="w-6 h-6 bg-emerald-500/20 rounded-full flex items-center justify-center"
                    >
                      <Check className="w-4 h-4 text-emerald-500" />
                    </motion.div>
                    {item}
                  </motion.div>
                ))}
              </div>
            </motion.div>
          )}

          {/* Step 5: Result */}
          {currentStep === 4 && (
            <motion.div
              key="result"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.5 }}
              className="text-center max-w-lg"
            >
              <motion.div
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ delay: 0.2, type: 'spring' }}
                className="text-4xl mb-4"
              >
                🔥
              </motion.div>
              <h2 className="text-2xl font-bold text-white mb-6">
                Votre première idée de vidéo virale
              </h2>
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.3 }}
                className="bg-[#1a1a24] rounded-2xl p-6 mb-6"
              >
                <div className="mb-4">
                  <span className="text-gray-500 text-sm uppercase tracking-wider">Topic</span>
                  <p className="text-violet-400 font-medium">{selectedTopics[0] || 'AI Automation'}</p>
                </div>
                <div className="mb-4">
                  <span className="text-gray-500 text-sm uppercase tracking-wider">Hook</span>
                  <p className="text-white text-lg font-medium">
                    "Watch AI automate my entire online business in 24 hours!"
                  </p>
                </div>
                <div className="mb-6">
                  <span className="text-gray-500 text-sm uppercase tracking-wider">Format</span>
                  <p className="text-gray-300">Transformation</p>
                </div>
                <div className="flex justify-between items-center pt-4 border-t border-gray-800">
                  <div>
                    <span className="text-gray-500 text-sm uppercase tracking-wider block">Score de viralité</span>
                    <span className="text-3xl font-bold text-violet-400">81</span>
                  </div>
                  <div className="text-right">
                    <span className="text-gray-500 text-sm uppercase tracking-wider block">Vues prédites</span>
                    <span className="text-xl font-medium text-white">300K - 1M</span>
                  </div>
                </div>
              </motion.div>
              <Button
                onClick={() => navigate('/dashboard')}
                className="w-full h-14 bg-gradient-to-r from-violet-600 to-fuchsia-600 hover:from-violet-500 hover:to-fuchsia-500 text-white font-semibold rounded-xl transition-all"
              >
                <Sparkles className="w-5 h-5 mr-2" />
                Créer la vidéo virale
              </Button>
              <button
                onClick={() => navigate('/dashboard')}
                className="mt-4 text-gray-500 hover:text-gray-400 transition-colors"
              >
                Passer et aller au tableau de bord →
              </button>
            </motion.div>
          )}
        </AnimatePresence>
      </main>
    </div>
  );
}
