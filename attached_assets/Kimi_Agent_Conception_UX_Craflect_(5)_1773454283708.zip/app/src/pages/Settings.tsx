import { useState } from 'react';
import { Sidebar } from '@/components/layout/Sidebar';
import { Header } from '@/components/layout/Header';
import { Card } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Separator } from '@/components/ui/separator';
import { Key, Bell, Shield, Globe, Database, Save } from 'lucide-react';

export function Settings() {
  const [maintenanceMode, setMaintenanceMode] = useState(false);
  const [emailNotifications, setEmailNotifications] = useState(true);
  const [apiKey, setApiKey] = useState('sk_live_craflect_xxxxxxxxxxxx');

  return (
    <div className="min-h-screen bg-gray-50 flex">
      <Sidebar />

      <div className="flex-1 flex flex-col min-h-screen overflow-hidden">
        <Header />

        <main className="flex-1 overflow-y-auto p-6">
          <div className="max-w-4xl mx-auto space-y-6">
            {/* Page Header */}
            <div>
              <h1 className="text-2xl font-bold text-gray-900">Settings</h1>
              <p className="text-sm text-gray-500 mt-1">
                Configure platform settings and preferences
              </p>
            </div>

            <Tabs defaultValue="general" className="space-y-6">
              <TabsList className="grid w-full grid-cols-4 lg:w-auto">
                <TabsTrigger value="general">General</TabsTrigger>
                <TabsTrigger value="api">API</TabsTrigger>
                <TabsTrigger value="notifications">Notifications</TabsTrigger>
                <TabsTrigger value="security">Security</TabsTrigger>
              </TabsList>

              {/* General Settings */}
              <TabsContent value="general" className="space-y-6">
                <Card className="p-6">
                  <div className="flex items-center gap-3 mb-6">
                    <Globe className="w-5 h-5 text-violet-600" />
                    <h3 className="text-lg font-semibold text-gray-900">Platform</h3>
                  </div>

                  <div className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div className="space-y-2">
                        <Label htmlFor="platform-name">Platform Name</Label>
                        <Input id="platform-name" defaultValue="Craflect" />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="support-email">Support Email</Label>
                        <Input id="support-email" defaultValue="support@craflect.com" />
                      </div>
                    </div>

                    <Separator />

                    <div className="flex items-center justify-between">
                      <div className="space-y-1">
                        <Label className="text-base">Maintenance Mode</Label>
                        <p className="text-sm text-gray-500">
                          Temporarily disable access for all non-admin users
                        </p>
                      </div>
                      <Switch
                        checked={maintenanceMode}
                        onCheckedChange={setMaintenanceMode}
                      />
                    </div>

                    <Separator />

                    <div className="flex items-center justify-between">
                      <div className="space-y-1">
                        <Label className="text-base">New User Registration</Label>
                        <p className="text-sm text-gray-500">
                          Allow new users to sign up
                        </p>
                      </div>
                      <Switch defaultChecked />
                    </div>
                  </div>
                </Card>

                <Card className="p-6">
                  <div className="flex items-center gap-3 mb-6">
                    <Database className="w-5 h-5 text-violet-600" />
                    <h3 className="text-lg font-semibold text-gray-900">Data Engine</h3>
                  </div>

                  <div className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div className="space-y-2">
                        <Label htmlFor="ingestion-rate">Max Daily Ingestion</Label>
                        <Input id="ingestion-rate" defaultValue="5000" type="number" />
                        <p className="text-xs text-gray-500">Maximum videos to ingest per day</p>
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="retention-days">Data Retention (days)</Label>
                        <Input id="retention-days" defaultValue="90" type="number" />
                        <p className="text-xs text-gray-500">Days to keep analytics data</p>
                      </div>
                    </div>
                  </div>
                </Card>
              </TabsContent>

              {/* API Settings */}
              <TabsContent value="api" className="space-y-6">
                <Card className="p-6">
                  <div className="flex items-center gap-3 mb-6">
                    <Key className="w-5 h-5 text-violet-600" />
                    <h3 className="text-lg font-semibold text-gray-900">API Keys</h3>
                  </div>

                  <div className="space-y-6">
                    <div className="space-y-2">
                      <Label htmlFor="api-key">Secret Key</Label>
                      <div className="flex gap-2">
                        <Input
                          id="api-key"
                          value={apiKey}
                          onChange={(e) => setApiKey(e.target.value)}
                          type="password"
                          className="font-mono"
                        />
                        <Button variant="outline">Reveal</Button>
                        <Button variant="outline">Regenerate</Button>
                      </div>
                      <p className="text-xs text-gray-500">
                        Keep this key secure. Never share it in client-side code.
                      </p>
                    </div>

                    <Separator />

                    <div className="space-y-2">
                      <Label htmlFor="webhook-url">Webhook URL</Label>
                      <Input
                        id="webhook-url"
                        placeholder="https://your-domain.com/webhook"
                      />
                      <p className="text-xs text-gray-500">
                        Receive real-time events from Craflect
                      </p>
                    </div>

                    <Separator />

                    <div className="flex items-center justify-between">
                      <div className="space-y-1">
                        <Label className="text-base">Rate Limiting</Label>
                        <p className="text-sm text-gray-500">
                          Limit API requests per minute
                        </p>
                      </div>
                      <Switch defaultChecked />
                    </div>
                  </div>
                </Card>
              </TabsContent>

              {/* Notifications Settings */}
              <TabsContent value="notifications" className="space-y-6">
                <Card className="p-6">
                  <div className="flex items-center gap-3 mb-6">
                    <Bell className="w-5 h-5 text-violet-600" />
                    <h3 className="text-lg font-semibold text-gray-900">Email Notifications</h3>
                  </div>

                  <div className="space-y-6">
                    <div className="flex items-center justify-between">
                      <div className="space-y-1">
                        <Label className="text-base">New User Signups</Label>
                        <p className="text-sm text-gray-500">
                          Receive an email when a new user registers
                        </p>
                      </div>
                      <Switch
                        checked={emailNotifications}
                        onCheckedChange={setEmailNotifications}
                      />
                    </div>

                    <Separator />

                    <div className="flex items-center justify-between">
                      <div className="space-y-1">
                        <Label className="text-base">New Subscriptions</Label>
                        <p className="text-sm text-gray-500">
                          Receive an email when a user upgrades to Pro
                        </p>
                      </div>
                      <Switch defaultChecked />
                    </div>

                    <Separator />

                    <div className="flex items-center justify-between">
                      <div className="space-y-1">
                        <Label className="text-base">Churn Alerts</Label>
                        <p className="text-sm text-gray-500">
                          Receive an email when a user cancels
                        </p>
                      </div>
                      <Switch defaultChecked />
                    </div>

                    <Separator />

                    <div className="flex items-center justify-between">
                      <div className="space-y-1">
                        <Label className="text-base">System Errors</Label>
                        <p className="text-sm text-gray-500">
                          Receive an email for critical system errors
                        </p>
                      </div>
                      <Switch defaultChecked />
                    </div>

                    <Separator />

                    <div className="flex items-center justify-between">
                      <div className="space-y-1">
                        <Label className="text-base">Daily Summary</Label>
                        <p className="text-sm text-gray-500">
                          Receive a daily summary of key metrics
                        </p>
                      </div>
                      <Switch />
                    </div>
                  </div>
                </Card>
              </TabsContent>

              {/* Security Settings */}
              <TabsContent value="security" className="space-y-6">
                <Card className="p-6">
                  <div className="flex items-center gap-3 mb-6">
                    <Shield className="w-5 h-5 text-violet-600" />
                    <h3 className="text-lg font-semibold text-gray-900">Security</h3>
                  </div>

                  <div className="space-y-6">
                    <div className="flex items-center justify-between">
                      <div className="space-y-1">
                        <Label className="text-base">Two-Factor Authentication</Label>
                        <p className="text-sm text-gray-500">
                          Require 2FA for all admin accounts
                        </p>
                      </div>
                      <Switch defaultChecked />
                    </div>

                    <Separator />

                    <div className="space-y-2">
                      <Label htmlFor="session-timeout">Session Timeout (hours)</Label>
                      <Input id="session-timeout" defaultValue="24" type="number" />
                      <p className="text-xs text-gray-500">
                        Automatically log out inactive users
                      </p>
                    </div>

                    <Separator />

                    <div className="space-y-2">
                      <Label htmlFor="max-attempts">Max Login Attempts</Label>
                      <Input id="max-attempts" defaultValue="5" type="number" />
                      <p className="text-xs text-gray-500">
                        Lock account after failed attempts
                      </p>
                    </div>

                    <Separator />

                    <div className="flex items-center justify-between">
                      <div className="space-y-1">
                        <Label className="text-base">IP Whitelist</Label>
                        <p className="text-sm text-gray-500">
                          Restrict admin access to specific IPs
                        </p>
                      </div>
                      <Switch />
                    </div>
                  </div>
                </Card>
              </TabsContent>
            </Tabs>

            {/* Save Button */}
            <div className="flex justify-end">
              <Button className="bg-violet-600 hover:bg-violet-700">
                <Save className="w-4 h-4 mr-2" />
                Save Changes
              </Button>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}
