import { useState } from 'react';
import { Sidebar } from '@/components/layout/Sidebar';
import { Header } from '@/components/layout/Header';
import { Card } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Search, MoreVertical, CreditCard, RefreshCw, X, FileText } from 'lucide-react';

// Mock subscriptions data
const mockSubscriptions = [
  { id: 1, user: 'Alice Martin', email: 'alice@example.com', plan: 'Pro', price: 24, status: 'active', billing: 'Monthly', nextBilling: '2024-07-15', mrr: 24 },
  { id: 2, user: 'Carla Santos', email: 'carla@example.com', plan: 'Pro', price: 24, status: 'active', billing: 'Monthly', nextBilling: '2024-07-08', mrr: 24 },
  { id: 3, user: 'Emma Wilson', email: 'emma@example.com', plan: 'Pro', price: 24, status: 'active', billing: 'Yearly', nextBilling: '2024-12-10', mrr: 20 },
  { id: 4, user: 'Grace Park', email: 'grace@example.com', plan: 'Pro', price: 24, status: 'active', billing: 'Monthly', nextBilling: '2024-07-22', mrr: 24 },
  { id: 5, user: 'John Doe', email: 'john@example.com', plan: 'Pro', price: 109, status: 'active', billing: 'Yearly', nextBilling: '2024-11-05', mrr: 9.08 },
  { id: 6, user: 'Sarah Lee', email: 'sarah@example.com', plan: 'Pro', price: 24, status: 'cancelled', billing: 'Monthly', nextBilling: '-', mrr: 0 },
  { id: 7, user: 'Mike Johnson', email: 'mike@example.com', plan: 'Pro', price: 24, status: 'past_due', billing: 'Monthly', nextBilling: '2024-06-20', mrr: 24 },
  { id: 8, user: 'Lisa Wang', email: 'lisa@example.com', plan: 'Pro', price: 109, status: 'active', billing: 'Yearly', nextBilling: '2025-01-15', mrr: 9.08 },
];

const statusColors: Record<string, string> = {
  active: 'bg-emerald-100 text-emerald-700 border-emerald-200',
  cancelled: 'bg-gray-100 text-gray-600 border-gray-200',
  past_due: 'bg-amber-100 text-amber-700 border-amber-200',
};

const planColors: Record<string, string> = {
  Pro: 'bg-violet-100 text-violet-700 border-violet-200',
  Enterprise: 'bg-fuchsia-100 text-fuchsia-700 border-fuchsia-200',
};

export function Subscriptions() {
  const [searchQuery, setSearchQuery] = useState('');

  const filteredSubscriptions = mockSubscriptions.filter(
    (sub) =>
      sub.user.toLowerCase().includes(searchQuery.toLowerCase()) ||
      sub.email.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const totalMrr = mockSubscriptions
    .filter((s) => s.status === 'active')
    .reduce((acc, s) => acc + s.mrr, 0);

  return (
    <div className="min-h-screen bg-gray-50 flex">
      <Sidebar />

      <div className="flex-1 flex flex-col min-h-screen overflow-hidden">
        <Header />

        <main className="flex-1 overflow-y-auto p-6">
          <div className="max-w-7xl mx-auto space-y-6">
            {/* Page Header */}
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-2xl font-bold text-gray-900">Subscriptions</h1>
                <p className="text-sm text-gray-500 mt-1">
                  Manage subscriptions and billing
                </p>
              </div>
              <div className="flex items-center gap-6">
                <div className="text-right">
                  <p className="text-2xl font-bold text-gray-900">98</p>
                  <p className="text-sm text-gray-500">Active subs</p>
                </div>
                <div className="text-right">
                  <p className="text-2xl font-bold text-emerald-600">${totalMrr.toFixed(0)}</p>
                  <p className="text-sm text-gray-500">MRR</p>
                </div>
              </div>
            </div>

            {/* Search & Filters */}
            <Card className="p-4">
              <div className="flex items-center gap-4">
                <div className="relative flex-1 max-w-md">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                  <Input
                    placeholder="Search by user or email..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-10"
                  />
                </div>
                <Button variant="outline">Filter</Button>
                <Button variant="outline">Export</Button>
              </div>
            </Card>

            {/* Subscriptions Table */}
            <Card>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>User</TableHead>
                    <TableHead>Plan</TableHead>
                    <TableHead>Price</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Billing</TableHead>
                    <TableHead>Next Billing</TableHead>
                    <TableHead>MRR</TableHead>
                    <TableHead className="w-10"></TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredSubscriptions.map((sub) => (
                    <TableRow key={sub.id}>
                      <TableCell>
                        <div>
                          <p className="font-medium text-gray-900">{sub.user}</p>
                          <p className="text-sm text-gray-500">{sub.email}</p>
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge variant="outline" className={planColors[sub.plan]}>
                          {sub.plan}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-gray-900 font-medium">
                        ${sub.price}
                      </TableCell>
                      <TableCell>
                        <Badge variant="outline" className={statusColors[sub.status]}>
                          {sub.status.replace('_', ' ')}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-gray-600">{sub.billing}</TableCell>
                      <TableCell className="text-gray-600">{sub.nextBilling}</TableCell>
                      <TableCell className="text-gray-900 font-medium">
                        ${sub.mrr.toFixed(2)}
                      </TableCell>
                      <TableCell>
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="icon">
                              <MoreVertical className="w-4 h-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem>
                              <FileText className="w-4 h-4 mr-2" />
                              View Invoices
                            </DropdownMenuItem>
                            <DropdownMenuItem>
                              <RefreshCw className="w-4 h-4 mr-2" />
                              Change Plan
                            </DropdownMenuItem>
                            <DropdownMenuItem>
                              <CreditCard className="w-4 h-4 mr-2" />
                              Update Payment
                            </DropdownMenuItem>
                            <DropdownMenuItem className="text-red-600">
                              <X className="w-4 h-4 mr-2" />
                              Cancel Subscription
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </Card>

            {/* Pagination */}
            <div className="flex items-center justify-between">
              <p className="text-sm text-gray-500">
                Showing {filteredSubscriptions.length} of 98 subscriptions
              </p>
              <div className="flex items-center gap-2">
                <Button variant="outline" size="sm" disabled>
                  Previous
                </Button>
                <Button variant="outline" size="sm">
                  Next
                </Button>
              </div>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}
