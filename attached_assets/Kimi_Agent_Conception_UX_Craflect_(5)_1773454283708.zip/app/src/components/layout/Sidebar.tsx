import { Link, useLocation } from 'react-router-dom';
import { LayoutDashboard, Users, CreditCard, ScrollText, Settings } from 'lucide-react';
import { cn } from '@/lib/utils';

const menuItems = [
  { id: 'overview', label: 'Overview', icon: LayoutDashboard, href: '/system/founder' },
  { id: 'users', label: 'Users', icon: Users, href: '/system/founder/users' },
  { id: 'subscriptions', label: 'Subscriptions', icon: CreditCard, href: '/system/founder/subscriptions' },
  { id: 'logs', label: 'System Logs', icon: ScrollText, href: '/system/founder/logs' },
  { id: 'settings', label: 'Settings', icon: Settings, href: '/system/founder/settings' },
];

export function Sidebar() {
  const location = useLocation();
  const currentPath = location.pathname;
  return (
    <aside className="w-64 bg-white border-r border-gray-200 min-h-screen flex flex-col">
      {/* Logo */}
      <div className="p-6 border-b border-gray-100">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-gradient-to-br from-violet-600 to-fuchsia-600 rounded-xl flex items-center justify-center">
            <span className="text-white font-bold text-lg">C</span>
          </div>
          <div>
            <h1 className="font-bold text-gray-900">Craflect</h1>
            <p className="text-xs text-gray-500">Founder Dashboard</p>
          </div>
        </div>
      </div>

      {/* Navigation */}
      <nav className="flex-1 p-4">
        <ul className="space-y-1">
          {menuItems.map((item) => {
            const Icon = item.icon;
            const isActive = currentPath === item.href;
            return (
              <li key={item.id}>
                <Link
                  to={item.href}
                  className={cn(
                    'flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium transition-all duration-200',
                    isActive
                      ? 'bg-violet-50 text-violet-700'
                      : 'text-gray-600 hover:bg-gray-50 hover:text-gray-900'
                  )}
                >
                  <Icon className={cn('w-5 h-5', isActive ? 'text-violet-600' : 'text-gray-400')} />
                  {item.label}
                </Link>
              </li>
            );
          })}
        </ul>
      </nav>

      {/* Footer */}
      <div className="p-4 border-t border-gray-100">
        <div className="bg-gradient-to-r from-violet-50 to-fuchsia-50 rounded-xl p-4">
          <p className="text-xs font-medium text-violet-900 mb-1">Admin Access</p>
          <p className="text-xs text-violet-700/70">Restricted to founders</p>
        </div>
      </div>
    </aside>
  );
}
