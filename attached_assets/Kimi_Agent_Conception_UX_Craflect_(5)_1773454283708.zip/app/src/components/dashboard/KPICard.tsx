import { TrendingUp, TrendingDown, Minus } from 'lucide-react';
import { Card } from '@/components/ui/card';
import { cn } from '@/lib/utils';

interface KPICardProps {
  title: string;
  value: string | number;
  subtitle?: string;
  change?: number;
  changeLabel?: string;
  trend?: 'up' | 'down' | 'neutral';
  status?: 'healthy' | 'warning' | 'critical' | 'neutral';
  comingSoon?: boolean;
  icon?: React.ReactNode;
}

export function KPICard({
  title,
  value,
  subtitle,
  change,
  changeLabel = 'vs last period',
  trend = 'neutral',
  status = 'neutral',
  comingSoon = false,
  icon,
}: KPICardProps) {
  const statusColors = {
    healthy: 'bg-emerald-50 border-emerald-200',
    warning: 'bg-amber-50 border-amber-200',
    critical: 'bg-red-50 border-red-200',
    neutral: 'bg-white border-gray-200',
  };

  const trendIcons = {
    up: <TrendingUp className="w-4 h-4" />,
    down: <TrendingDown className="w-4 h-4" />,
    neutral: <Minus className="w-4 h-4" />,
  };

  const trendColors = {
    up: 'text-emerald-600',
    down: 'text-red-600',
    neutral: 'text-gray-500',
  };

  if (comingSoon) {
    return (
      <Card className="p-5 border border-dashed border-gray-300 bg-gray-50/50">
        <p className="text-sm text-gray-500 mb-1">{title}</p>
        <div className="flex items-center justify-center py-4">
          <span className="text-sm font-medium text-gray-400">Coming soon</span>
        </div>
      </Card>
    );
  }

  return (
    <Card className={cn('p-5 border transition-all duration-200 hover:shadow-md', statusColors[status])}>
      <div className="flex items-start justify-between">
        <div>
          <p className="text-sm text-gray-500 mb-1">{title}</p>
          <p className="text-2xl font-bold text-gray-900">{value}</p>
          {subtitle && <p className="text-xs text-gray-400 mt-1">{subtitle}</p>}
        </div>
        {icon && <div className="text-gray-400">{icon}</div>}
      </div>
      
      {change !== undefined && (
        <div className="flex items-center gap-2 mt-3 pt-3 border-t border-gray-100/50">
          <span className={cn('flex items-center gap-1 text-xs font-medium', trendColors[trend])}>
            {trendIcons[trend]}
            {change > 0 ? '+' : ''}{change}%
          </span>
          <span className="text-xs text-gray-400">{changeLabel}</span>
        </div>
      )}
    </Card>
  );
}
