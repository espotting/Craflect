# BRIEF - CRAFLECT AUTH & ONBOARDING V2

## OBJECTIF
Implémenter les pages d'authentification avec vérification par code email et accès admin sécurisé.

---

## DÉPENDANCES

```bash
npm install react-router-dom framer-motion
```

---

## STRUCTURE

```
src/pages/auth/
├── Welcome.tsx              # Choix Google/Email
├── SignIn.tsx               # Connexion (détecte admin@craflect.com)
├── SignUp.tsx               # Inscription avec validation
├── ForgotPassword.tsx       # Reset password
├── EmailConfirmation.tsx    # Vérification code 6 chiffres
├── AdminVerification.tsx    # Vérification admin (code 6 chiffres)
```

---

## ROUTES

| Route | Page | Description |
|-------|------|-------------|
| `/welcome` | Welcome | Choix connexion |
| `/signin` | SignIn | Email + password |
| `/signup` | SignUp | Création compte |
| `/forgot-password` | ForgotPassword | Reset |
| `/email-confirmation` | EmailConfirmation | Code 6 chiffres |
| `/admin-verification` | AdminVerification | Code 6 chiffres (admin) |
| `/onboarding` | Onboarding | 5 étapes |

---

## WORKFLOWS

### Sign Up (User normal)
```
/welcome → /signup → /email-confirmation → /onboarding → /dashboard
```
- EmailConfirmation : saisir code 6 chiffres (pas de lien)
- Auto-focus entre inputs
- Support paste

### Sign In (User normal)
```
/welcome → /signin → /onboarding → /dashboard
```

### Sign In (Admin)
```
/welcome → /signin (admin@craflect.com) → /admin-verification → /system/founder
```
- Détection automatique de l'email admin
- Code 6 chiffres demandé systématiquement
- Redirige vers `/system/founder`

---

## VALIDATIONS

### EmailConfirmation
- Code 6 chiffres
- Auto-focus
- Paste support
- Resend avec countdown 60s
- Demo : code `000000` = erreur

### AdminVerification
- Même UX que EmailConfirmation
- Message spécifique "Admin Verification"
- Note de sécurité affichée
- Demo : code `000000` = erreur

---

## DÉTECTION ADMIN (SignIn.tsx)

```typescript
if (email.toLowerCase() === 'admin@craflect.com') {
  navigate('/admin-verification', { state: { email } });
  return;
}
```

---

## FICHIERS CLÉS MODIFIÉS

1. **SignIn.tsx** - Ajout détection admin
2. **EmailConfirmation.tsx** - Input code au lieu de lien
3. **AdminVerification.tsx** - Nouvelle page
4. **App.tsx** - Route `/admin-verification`

---

## TEST DÉMO

- **EmailConfirmation** : Aller à `/email-confirmation`, saisir n'importe quel code (sauf 000000)
- **Admin** : Aller à `/signin`, entrer `admin@craflect.com` + n'importe quel password → redirection vers `/admin-verification`
