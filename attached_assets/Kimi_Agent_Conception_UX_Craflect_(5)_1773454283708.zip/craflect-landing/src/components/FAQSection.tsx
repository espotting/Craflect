import { useState } from 'react';
import { ChevronRight } from 'lucide-react';
import type { FAQItem } from '@/types';

const faqs: FAQItem[] = [
  {
    question: 'How does Craflect find viral opportunities?',
    answer: 'Craflect analyzes thousands of videos in your niche every week, identifying patterns, hooks, and formats that are driving engagement. Our AI then generates personalized content ideas based on these insights.',
  },
  {
    question: 'Can I use Craflect for any niche?',
    answer: 'Yes! Craflect works across all niches. Whether you\'re in fitness, finance, fashion, or anything else, our system learns the specific patterns that work in your space.',
  },
  {
    question: 'What happens to my unused credits?',
    answer: 'Unused credits roll over to the next month, up to a maximum of 2 months. For example, with the Creator plan, you can accumulate up to 500 credits (2 months worth).',
  },
  {
    question: 'Is there a free trial?',
    answer: 'Yes! Every paid plan includes a 7-day free trial. No credit card required to start. You can explore all features and generate your first viral ideas before committing.',
  },
];

export const FAQSection = () => {
  const [openIndex, setOpenIndex] = useState<number | null>(null);

  return (
    <section className="py-24 relative">
      <div className="max-w-3xl mx-auto px-6">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold text-white mb-4">Frequently asked questions</h2>
          <p className="text-slate-400">
            Everything you need to know about Craflect.
          </p>
        </div>

        <div className="space-y-4">
          {faqs.map((faq, index) => (
            <div 
              key={index}
              className="bg-slate-900/50 rounded-xl border border-slate-800 overflow-hidden"
            >
              <button
                onClick={() => setOpenIndex(openIndex === index ? null : index)}
                className="w-full flex items-center justify-between p-5 text-left"
              >
                <span className="text-white font-medium">{faq.question}</span>
                <div className={`w-6 h-6 rounded-full bg-slate-800 flex items-center justify-center transition-transform ${
                  openIndex === index ? 'rotate-180' : ''
                }`}>
                  <ChevronRight className="w-4 h-4 text-slate-400 rotate-90" />
                </div>
              </button>
              {openIndex === index && (
                <div className="px-5 pb-5">
                  <p className="text-slate-400">{faq.answer}</p>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
