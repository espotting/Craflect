import { useState } from 'react';
import { Zap, Check, CheckCircle2, Lightbulb, ArrowRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import type { PricingPlan } from '@/types';

interface PricingSectionProps {
  onSelectPlan: (plan: PricingPlan) => void;
}

const plans: PricingPlan[] = [
  {
    name: 'Free',
    price: 0,
    period: 'month',
    credits: 30,
    videos: '~10',
    rollover: 0,
    description: 'Perfect for trying out Craflect',
    features: [
      'Viral Play of the Day',
      'Trending videos',
      'Basic templates',
      'Script generation',
      'Watermark on exports',
    ],
    cta: 'Get started free',
    highlighted: false,
  },
  {
    name: 'Creator',
    price: 24,
    yearlyPrice: 19,
    period: 'month',
    credits: 250,
    videos: '~80',
    rollover: 500,
    description: 'For serious content creators',
    features: [
      'Everything in Free',
      'Export enabled (no watermark)',
      'AI Avatar generation',
      'Viral Templates library',
      'Video Blueprint export',
      'Priority support',
    ],
    cta: 'Start free trial',
    highlighted: true,
    badge: 'Popular',
  },
  {
    name: 'Pro',
    price: 109,
    yearlyPrice: 99,
    period: 'month',
    credits: 1500,
    videos: '~500',
    rollover: 3000,
    description: 'For agencies and power users',
    features: [
      'Everything in Creator',
      'Video Remix (AI)',
      'Advanced analytics',
      'Team workspace',
      'API access',
      'Dedicated support',
    ],
    cta: 'Start free trial',
    highlighted: false,
  },
];

export const PricingSection = ({ onSelectPlan }: PricingSectionProps) => {
  const [yearly, setYearly] = useState(false);

  return (
    <section id="pricing" className="py-24 relative">
      <div className="max-w-6xl mx-auto px-6">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold text-white mb-4">
            Choose the right plan for your niche
          </h2>
          <p className="text-slate-400 text-lg mb-8">
            Every plan includes a 7-day free trial. No credit card required.
          </p>

          {/* Toggle */}
          <div className="inline-flex items-center gap-4 p-1 bg-slate-900 rounded-full border border-slate-800">
            <button
              onClick={() => setYearly(false)}
              className={`px-4 py-2 rounded-full text-sm font-medium transition-all ${
                !yearly ? 'bg-purple-600 text-white' : 'text-slate-400 hover:text-white'
              }`}
            >
              Monthly
            </button>
            <button
              onClick={() => setYearly(true)}
              className={`px-4 py-2 rounded-full text-sm font-medium transition-all flex items-center gap-2 ${
                yearly ? 'bg-purple-600 text-white' : 'text-slate-400 hover:text-white'
              }`}
            >
              Yearly
              <span className="px-2 py-0.5 bg-green-500/20 text-green-400 text-xs rounded-full">
                Save 20%
              </span>
            </button>
          </div>
        </div>

        {/* Trust Badges */}
        <div className="flex items-center justify-center gap-4 mb-12 flex-wrap">
          <div className="flex items-center gap-2 px-4 py-2 bg-slate-900 rounded-full border border-slate-800">
            <CheckCircle2 className="w-4 h-4 text-purple-400" />
            <span className="text-slate-400 text-sm">7-day free trial</span>
          </div>
          <div className="flex items-center gap-2 px-4 py-2 bg-slate-900 rounded-full border border-slate-800">
            <CheckCircle2 className="w-4 h-4 text-purple-400" />
            <span className="text-slate-400 text-sm">No credit card</span>
          </div>
          <div className="flex items-center gap-2 px-4 py-2 bg-slate-900 rounded-full border border-slate-800">
            <CheckCircle2 className="w-4 h-4 text-purple-400" />
            <span className="text-slate-400 text-sm">Cancel anytime</span>
          </div>
        </div>

        {/* Plans */}
        <div className="grid md:grid-cols-3 gap-6">
          {plans.map((plan, index) => (
            <div 
              key={index}
              className={`relative rounded-2xl p-6 border ${
                plan.highlighted 
                  ? 'bg-slate-900 border-purple-500/50' 
                  : 'bg-slate-900/50 border-slate-800'
              }`}
            >
              {plan.badge && (
                <div className="absolute -top-3 left-1/2 -translate-x-1/2">
                  <span className="px-3 py-1 bg-purple-600 text-white text-xs font-medium rounded-full">
                    {plan.badge}
                  </span>
                </div>
              )}

              <div className="mb-6">
                <h3 className="text-xl font-semibold text-white mb-1">{plan.name}</h3>
                <p className="text-slate-400 text-sm">{plan.description}</p>
              </div>

              <div className="mb-6">
                <div className="flex items-baseline gap-1">
                  <span className="text-4xl font-bold text-white">
                    ${yearly && plan.yearlyPrice ? plan.yearlyPrice : plan.price}
                  </span>
                  <span className="text-slate-400">/month</span>
                </div>
                {yearly && plan.yearlyPrice && (
                  <p className="text-slate-500 text-sm mt-1">
                    Billed annually (${plan.yearlyPrice * 12}/year)
                  </p>
                )}
              </div>

              <div className="mb-6 p-3 bg-slate-800/50 rounded-lg">
                <div className="flex items-center gap-2 text-sm mb-1">
                  <Zap className="w-4 h-4 text-yellow-400" />
                  <span className="text-white font-medium">{plan.credits}</span>
                  <span className="text-slate-400">AI credits / month</span>
                </div>
                <p className="text-green-400 text-sm font-medium">
                  ≈ {plan.videos} videos per month
                </p>
                <p className="text-slate-500 text-xs mt-1">
                  Max rollover: {plan.rollover} credits
                </p>
              </div>

              <ul className="space-y-3 mb-6">
                {plan.features.map((feature, i) => (
                  <li key={i} className="flex items-start gap-3">
                    <Check className="w-5 h-5 text-green-400 flex-shrink-0 mt-0.5" />
                    <span className="text-slate-300 text-sm">{feature}</span>
                  </li>
                ))}
              </ul>

              <Button 
                onClick={() => onSelectPlan(plan)}
                className={`w-full ${
                  plan.highlighted 
                    ? 'bg-purple-600 hover:bg-purple-700 text-white' 
                    : 'bg-slate-800 hover:bg-slate-700 text-white'
                }`}
              >
                {plan.cta}
                <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
            </div>
          ))}
        </div>

        {/* Credit Explanation */}
        <div className="mt-12 max-w-2xl mx-auto">
          <div className="bg-slate-900/50 rounded-xl p-6 border border-slate-800">
            <div className="flex items-start gap-4">
              <div className="w-10 h-10 rounded-lg bg-purple-500/20 flex items-center justify-center flex-shrink-0">
                <Lightbulb className="w-5 h-5 text-purple-400" />
              </div>
              <div>
                <h4 className="text-white font-semibold mb-2">What counts as a credit?</h4>
                <p className="text-slate-400 text-sm">
                  Each AI generation consumes credits: Generate Idea (1), Generate Script (1), 
                  Generate Blueprint (1), AI Avatar (3). Creating a standard video uses about 3 credits total.
                  Unused credits roll over for up to 2 months.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
