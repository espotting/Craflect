import { Sparkles, TrendingUp, Flame, ArrowRight, Play, Video } from 'lucide-react';
import { Button } from '@/components/ui/button';

interface HeroSectionProps {
  onGetStarted: () => void;
  onWatchDemo: () => void;
}

export const HeroSection = ({ onGetStarted, onWatchDemo }: HeroSectionProps) => {
  return (
    <section className="relative min-h-screen flex items-center justify-center pt-20 overflow-hidden">
      {/* Background Effects */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-purple-600/20 rounded-full blur-3xl" />
        <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-fuchsia-600/10 rounded-full blur-3xl" />
      </div>

      <div className="relative z-10 max-w-5xl mx-auto px-6 text-center">
        {/* Badge */}
        <div className="inline-flex items-center gap-2 px-4 py-2 bg-purple-500/10 border border-purple-500/20 rounded-full mb-8">
          <Sparkles className="w-4 h-4 text-purple-400" />
          <span className="text-purple-300 text-sm font-medium">AI Content Intelligence for Creators</span>
        </div>

        {/* Headline */}
        <h1 className="text-5xl md:text-7xl font-bold text-white mb-6 leading-tight">
          Stop guessing what to post.
          <br />
          <span className="bg-gradient-to-r from-purple-400 to-fuchsia-400 bg-clip-text text-transparent">
            See what actually works.
          </span>
          <br />
          Turn it into viral content.
        </h1>

        {/* Subheadline */}
        <p className="text-xl text-slate-400 mb-8 max-w-2xl mx-auto">
          Craflect analyzes what's already performing in your niche and turns it into 
          ready-to-post content ideas with scripts, blueprints, and AI-powered creation tools.
        </p>

        {/* Social Proof */}
        <p className="text-slate-500 text-sm mb-8">
          Analyzing 50,000+ viral videos every week
        </p>

        {/* CTAs */}
        <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
          <Button 
            size="lg" 
            onClick={onGetStarted}
            className="bg-purple-600 hover:bg-purple-700 text-white px-8 h-14 text-lg rounded-full shadow-lg shadow-purple-500/25"
          >
            See today's viral opportunities
            <ArrowRight className="w-5 h-5 ml-2" />
          </Button>
          <Button 
            size="lg" 
            variant="outline" 
            onClick={onWatchDemo}
            className="border-slate-700 text-slate-300 hover:bg-slate-800 px-8 h-14 text-lg rounded-full"
          >
            <Play className="w-5 h-5 mr-2" />
            See how it works
          </Button>
        </div>

        {/* Dashboard Preview */}
        <div className="mt-16 relative">
          <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-transparent to-transparent z-10 pointer-events-none" />
          <div className="bg-slate-900/80 backdrop-blur rounded-2xl border border-slate-800 p-2 shadow-2xl shadow-purple-500/10">
            <div className="bg-slate-950 rounded-xl overflow-hidden">
              {/* Dashboard Header */}
              <div className="flex items-center gap-2 px-4 py-3 bg-slate-900 border-b border-slate-800">
                <div className="flex gap-1.5">
                  <div className="w-3 h-3 rounded-full bg-red-500/50" />
                  <div className="w-3 h-3 rounded-full bg-yellow-500/50" />
                  <div className="w-3 h-3 rounded-full bg-green-500/50" />
                </div>
                <div className="flex-1 text-center text-xs text-slate-500">craflect.app/dashboard</div>
              </div>
              
              {/* Dashboard Content */}
              <div className="p-6">
                <div className="flex gap-6">
                  {/* Sidebar */}
                  <div className="w-48 space-y-1">
                    <div className="flex items-center gap-3 px-3 py-2 bg-purple-500/20 rounded-lg border border-purple-500/30">
                      <div className="w-5 h-5 rounded bg-purple-500 flex items-center justify-center">
                        <Sparkles className="w-3 h-3 text-white" />
                      </div>
                      <span className="text-purple-300 text-sm">Home</span>
                    </div>
                    {['Opportunities', 'Create', 'Workspace', 'Insights'].map((item, i) => (
                      <div key={i} className="flex items-center gap-3 px-3 py-2">
                        <div className="w-5 h-5 rounded bg-slate-800" />
                        <span className="text-slate-500 text-sm">{item}</span>
                      </div>
                    ))}
                  </div>
                  
                  {/* Main Content */}
                  <div className="flex-1 space-y-4">
                    {/* Viral Play of the Day Card */}
                    <div className="bg-gradient-to-br from-purple-900/50 via-slate-900/50 to-slate-900/50 rounded-xl p-4 border border-purple-500/30 relative overflow-hidden">
                      <div className="absolute top-0 right-0 w-32 h-32 bg-purple-500/10 rounded-full blur-2xl" />
                      <div className="relative">
                        <div className="flex items-center gap-2 mb-3">
                          <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-purple-500 to-fuchsia-500 flex items-center justify-center">
                            <Flame className="w-4 h-4 text-white" />
                          </div>
                          <span className="text-purple-300 text-xs font-medium uppercase tracking-wider">Viral Play of the Day</span>
                        </div>
                        <p className="text-white font-semibold text-lg mb-2">
                          "5 AI tools that will save you 10 hours every week"
                        </p>
                        <div className="flex gap-4 mb-3">
                          <span className="text-slate-400 text-xs">Listicle</span>
                          <span className="text-green-400 text-xs">120K - 600K views</span>
                          <span className="text-purple-400 text-xs">87% confidence</span>
                        </div>
                        <div className="flex gap-2">
                          <button className="px-4 py-2 bg-purple-600 hover:bg-purple-700 text-white text-sm rounded-lg flex items-center gap-2">
                            <Sparkles className="w-4 h-4" />
                            Create This Video
                          </button>
                          <button className="px-4 py-2 bg-slate-800 text-slate-300 text-sm rounded-lg">
                            See Similar
                          </button>
                        </div>
                      </div>
                    </div>
                    
                    {/* Trending Videos Grid */}
                    <div>
                      <div className="flex items-center gap-2 mb-3">
                        <TrendingUp className="w-4 h-4 text-orange-400" />
                        <span className="text-white text-sm font-medium">Trending Now</span>
                      </div>
                      <div className="grid grid-cols-4 gap-3">
                        {[
                          { score: 94, hook: 'I tested every AI writing tool...' },
                          { score: 88, hook: 'The one mistake killing...' },
                          { score: 91, hook: 'Stop doing this in your hooks...' },
                          { score: 96, hook: 'This format got me 1M views...' },
                        ].map((video, i) => (
                          <div key={i} className="relative aspect-[9/16] rounded-lg overflow-hidden group cursor-pointer">
                            <div className={`absolute inset-0 bg-gradient-to-br ${
                              i === 0 ? 'from-violet-600 via-purple-600 to-fuchsia-600' :
                              i === 1 ? 'from-blue-600 via-cyan-600 to-teal-600' :
                              i === 2 ? 'from-orange-600 via-amber-600 to-yellow-600' :
                              'from-rose-600 via-pink-600 to-purple-600'
                            }`} />
                            <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent" />
                            <div className="absolute top-2 right-2">
                              <span className={`px-1.5 py-0.5 text-[10px] font-bold rounded ${
                                video.score >= 90 ? 'bg-red-500/20 text-red-400' :
                                video.score >= 80 ? 'bg-orange-500/20 text-orange-400' :
                                'bg-yellow-500/20 text-yellow-400'
                              }`}>
                                <Flame className="w-2 h-2 inline mr-0.5" />
                                {video.score}
                              </span>
                            </div>
                            <div className="absolute bottom-0 left-0 right-0 p-2">
                              <p className="text-white text-[10px] line-clamp-2">{video.hook}</p>
                            </div>
                            <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity bg-black/50">
                              <button className="px-3 py-1.5 bg-purple-600 text-white text-xs rounded-lg">
                                Create Similar
                              </button>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
