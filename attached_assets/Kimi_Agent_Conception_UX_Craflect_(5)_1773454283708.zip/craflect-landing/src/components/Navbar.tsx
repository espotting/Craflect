import { useState, useEffect } from 'react';
import { ArrowRight, Globe, User, Menu, X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Separator } from '@/components/ui/separator';

interface NavbarProps {
  onGetStarted: () => void;
  onSignIn: () => void;
}

export const Navbar = ({ onGetStarted, onSignIn }: NavbarProps) => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 50);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToPricing = () => {
    document.getElementById('pricing')?.scrollIntoView({ behavior: 'smooth' });
    setMobileMenuOpen(false);
  };

  return (
    <nav className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
      isScrolled ? 'bg-slate-950/90 backdrop-blur-xl border-b border-slate-800' : 'bg-transparent'
    }`}>
      <div className="max-w-7xl mx-auto px-6 py-4">
        <div className="flex items-center justify-between">
          {/* Logo - Replit l'a déjà */}
          <a href="#" className="flex items-center gap-2">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-purple-600 to-fuchsia-600 flex items-center justify-center">
              <span className="text-white font-bold text-xl">C</span>
            </div>
            <span className="text-xl font-bold text-white">Craflect</span>
          </a>

          {/* Desktop Nav - Minimal */}
          <div className="hidden md:flex items-center gap-6">
            <button 
              onClick={scrollToPricing}
              className="text-slate-400 hover:text-white transition-colors text-sm font-medium"
            >
              Pricing
            </button>
            
            {/* Language */}
            <button className="w-9 h-9 rounded-full bg-slate-800/50 flex items-center justify-center hover:bg-slate-800 transition-colors">
              <Globe className="w-4 h-4 text-slate-400" />
            </button>
            
            {/* User / Sign in */}
            <button 
              onClick={onSignIn}
              className="w-9 h-9 rounded-full bg-slate-800/50 flex items-center justify-center hover:bg-slate-800 transition-colors"
            >
              <User className="w-4 h-4 text-slate-400" />
            </button>
            
            <Button 
              onClick={onGetStarted}
              className="bg-purple-600 hover:bg-purple-700 text-white rounded-full px-5"
            >
              Get started
              <ArrowRight className="w-4 h-4 ml-2" />
            </Button>
          </div>

          {/* Mobile Menu Button */}
          <button 
            className="md:hidden text-white"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>

        {/* Mobile Menu */}
        {mobileMenuOpen && (
          <div className="md:hidden mt-4 pb-4 border-t border-slate-800 pt-4">
            <div className="flex flex-col gap-4">
              <button 
                onClick={scrollToPricing}
                className="text-slate-400 hover:text-white transition-colors text-sm font-medium text-left"
              >
                Pricing
              </button>
              <Separator className="bg-slate-800" />
              <Button 
                onClick={onGetStarted}
                className="bg-purple-600 hover:bg-purple-700 text-white rounded-full w-full"
              >
                Get started
                <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
            </div>
          </div>
        )}
      </div>
    </nav>
  );
};
