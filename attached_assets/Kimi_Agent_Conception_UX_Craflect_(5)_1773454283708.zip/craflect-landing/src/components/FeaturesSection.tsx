import { BarChart3, Target, TrendingUp, Video } from 'lucide-react';

const features = [
  {
    icon: BarChart3,
    title: 'Built on real performance',
    description: 'Ideas are based on what\'s already performing in your niche — not generated randomly.',
  },
  {
    icon: Target,
    title: 'Focused on your niche',
    description: 'Each niche has its own signals, patterns, and winning formats.',
  },
  {
    icon: TrendingUp,
    title: 'Updated continuously',
    description: 'The more videos analyzed, the stronger the signal becomes.',
  },
  {
    icon: Video,
    title: 'Built for short-form',
    description: 'Designed specifically for TikTok, Reels, and Shorts.',
  },
];

export const FeaturesSection = () => {
  return (
    <section className="py-24 relative">
      <div className="max-w-6xl mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-white mb-4">
            Not another AI content generator.
          </h2>
          <p className="text-3xl font-bold bg-gradient-to-r from-purple-400 to-fuchsia-400 bg-clip-text text-transparent mb-4">
            A viral content intelligence system.
          </p>
          <p className="text-slate-400 text-lg max-w-2xl mx-auto">
            Craflect doesn't invent random ideas. It analyzes what's already working — 
            and turns it into clear content ideas.
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-6">
          {features.map((feature, index) => (
            <div 
              key={index} 
              className="bg-slate-900/50 rounded-2xl p-6 border border-slate-800 hover:border-purple-500/30 transition-all group"
            >
              <div className="w-12 h-12 rounded-xl bg-purple-500/20 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                <feature.icon className="w-6 h-6 text-purple-400" />
              </div>
              <h3 className="text-lg font-semibold text-white mb-2">{feature.title}</h3>
              <p className="text-slate-400">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
