import { Compass, FileText, Video } from 'lucide-react';

const steps = [
  {
    number: '1',
    icon: Compass,
    title: 'Discover what works',
    description: 'Our AI analyzes thousands of viral videos in your niche to identify winning patterns.',
  },
  {
    number: '2',
    icon: FileText,
    title: 'Generate your script',
    description: 'Turn insights into ready-to-use scripts with hooks, flow, and CTAs optimized for your audience.',
  },
  {
    number: '3',
    icon: Video,
    title: 'Post your video',
    description: 'Follow the blueprint to create and publish content that drives engagement and growth.',
  },
];

export const HowItWorksSection = () => {
  return (
    <section className="py-24 relative">
      <div className="max-w-6xl mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-white mb-4">How it works</h2>
          <p className="text-slate-400 text-lg">
            From discovery to published video — in 3 simple steps.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {steps.map((step, index) => (
            <div key={index} className="relative">
              <div className="bg-slate-900/50 rounded-2xl p-8 border border-slate-800 hover:border-purple-500/30 transition-all group">
                <div className="relative mb-6">
                  <div className="w-16 h-16 rounded-2xl bg-purple-500/20 flex items-center justify-center group-hover:scale-110 transition-transform">
                    <step.icon className="w-8 h-8 text-purple-400" />
                  </div>
                  <div className="absolute -top-2 -right-2 w-8 h-8 rounded-full bg-purple-600 flex items-center justify-center text-white font-bold text-sm">
                    {step.number}
                  </div>
                </div>
                <h3 className="text-xl font-semibold text-white mb-3">{step.title}</h3>
                <p className="text-slate-400">{step.description}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
