import { BarChart3, Target, FileText, ArrowRight } from 'lucide-react';
import { Button } from '@/components/ui/button';

interface DashboardPreviewSectionProps {
  onGetStarted: () => void;
}

export const DashboardPreviewSection = ({ onGetStarted }: DashboardPreviewSectionProps) => {
  return (
    <section className="py-24 relative">
      <div className="max-w-6xl mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-4">
            See it. Understand it. Use it.
          </h2>
          <p className="text-slate-400 text-lg">
            From viral signals to ready-to-post content ideas — in 3 steps.
          </p>
        </div>

        {/* Feature Cards */}
        <div className="grid md:grid-cols-3 gap-6 mb-12">
          {/* What's Working */}
          <div className="bg-slate-900/50 rounded-2xl p-6 border border-slate-800">
            <div className="flex items-center gap-2 mb-6">
              <BarChart3 className="w-5 h-5 text-purple-400" />
              <span className="text-purple-400 font-semibold text-sm uppercase tracking-wider">What's Working</span>
            </div>
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <span className="text-slate-400 text-sm">Confidence</span>
                <span className="text-purple-400 font-bold">87%</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-slate-400 text-sm">Signal strength</span>
                <span className="text-white font-medium">Strong</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-slate-400 text-sm">Videos analyzed</span>
                <span className="text-white font-medium">2,847</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-slate-400 text-sm">Top hook</span>
                <span className="text-white font-medium">Question (42%)</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-slate-400 text-sm">Top format</span>
                <span className="text-white font-medium">Listicle (38%)</span>
              </div>
            </div>
          </div>

          {/* What to Focus On */}
          <div className="bg-slate-900/50 rounded-2xl p-6 border border-slate-800">
            <div className="flex items-center gap-2 mb-6">
              <Target className="w-5 h-5 text-purple-400" />
              <span className="text-purple-400 font-semibold text-sm uppercase tracking-wider">What to Focus On</span>
            </div>
            <div className="space-y-4">
              {[
                'Use direct question hooks in the first 3 seconds',
                'Keep videos under 35 seconds for maximum retention',
                'Combine Tactical and Relatable angles',
                'Include a clear CTA at the end',
              ].map((tip, i) => (
                <div key={i} className="flex items-start gap-3">
                  <div className="w-5 h-5 rounded-full bg-purple-500/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                    <span className="text-purple-400 text-xs font-bold">{i + 1}</span>
                  </div>
                  <p className="text-slate-300 text-sm">{tip}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Your Structured Brief */}
          <div className="bg-slate-900/50 rounded-2xl p-6 border border-slate-800">
            <div className="flex items-center gap-2 mb-6">
              <FileText className="w-5 h-5 text-purple-400" />
              <span className="text-purple-400 font-semibold text-sm uppercase tracking-wider">Your Structured Brief</span>
            </div>
            <div className="space-y-4">
              <div>
                <span className="text-slate-500 text-xs uppercase tracking-wider">Hook</span>
                <p className="text-white text-sm mt-1 italic">
                  "I almost gave up on content creation until I discovered this one pattern..."
                </p>
              </div>
              <div>
                <span className="text-slate-500 text-xs uppercase tracking-wider">Flow</span>
                <p className="text-slate-300 text-sm mt-1">
                  Hook → Personal story → Pattern reveal → CTA
                </p>
              </div>
              <div>
                <span className="text-slate-500 text-xs uppercase tracking-wider">CTA</span>
                <p className="text-slate-300 text-sm mt-1">
                  Comment "PATTERN" and I'll send you the full breakdown.
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* CTA */}
        <div className="text-center">
          <Button 
            size="lg" 
            onClick={onGetStarted}
            className="bg-purple-600 hover:bg-purple-700 text-white px-8 h-14 text-lg rounded-full"
          >
            See today's viral opportunities
            <ArrowRight className="w-5 h-5 ml-2" />
          </Button>
        </div>
      </div>
    </section>
  );
};
