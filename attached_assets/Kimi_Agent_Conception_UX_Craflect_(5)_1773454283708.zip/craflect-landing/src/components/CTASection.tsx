import { ArrowRight } from 'lucide-react';
import { Button } from '@/components/ui/button';

interface CTASectionProps {
  onGetStarted: () => void;
}

export const CTASection = ({ onGetStarted }: CTASectionProps) => {
  return (
    <section className="py-24 relative">
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-purple-600/10 rounded-full blur-3xl" />
      </div>

      <div className="relative z-10 max-w-2xl mx-auto px-6 text-center">
        <h2 className="text-4xl font-bold text-white mb-4">
          Ready to stop guessing?
        </h2>
        <p className="text-slate-400 text-lg mb-8">
          Join thousands of creators who use Craflect to generate viral content ideas.
        </p>
        <Button 
          size="lg" 
          onClick={onGetStarted}
          className="bg-purple-600 hover:bg-purple-700 text-white px-8 h-14 text-lg rounded-full shadow-lg shadow-purple-500/25"
        >
          See today's viral opportunities
          <ArrowRight className="w-5 h-5 ml-2" />
        </Button>
        <p className="text-slate-500 text-sm mt-4">
          No credit card required • 7-day free trial • Cancel anytime
        </p>
      </div>
    </section>
  );
};
