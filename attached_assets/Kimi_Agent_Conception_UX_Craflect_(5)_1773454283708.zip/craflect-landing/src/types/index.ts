// CRAFLECT LANDING PAGE TYPES
// ============================

export interface PricingPlan {
  name: string;
  price: number;
  yearlyPrice?: number;
  period: 'month' | 'year';
  credits: number;
  videos: string;
  rollover: number;
  description: string;
  features: string[];
  cta: string;
  highlighted: boolean;
  badge?: string;
}

export interface FAQItem {
  question: string;
  answer: string;
}

export interface TrendingVideo {
  id: string;
  score: number;
  hook: string;
  gradient: string;
}

export interface Feature {
  icon: string;
  title: string;
  description: string;
}

export interface NavLink {
  label: string;
  href: string;
}

export interface FooterLinkGroup {
  category: string;
  items: string[];
}
