import { useState } from 'react';
import { 
  Navbar, 
  HeroSection, 
  HowItWorksSection, 
  DashboardPreviewSection,
  FeaturesSection,
  PricingSection,
  FAQSection,
  CTASection,
  Footer 
} from './components';
import type { PricingPlan } from './types';

function App() {
  // =====================
  // CTA HANDLERS
  // =====================
  
  // CTA: "Get started" / "See today's viral opportunities"
  // ACTION: Redirige vers le Dashboard ou ouvre le modal d'inscription
  const handleGetStarted = () => {
    // Option 1: Rediriger vers le Dashboard (si l'utilisateur est déjà connecté)
    // window.location.href = '/dashboard';
    
    // Option 2: Ouvrir le modal d'inscription/connexion
    console.log('Get Started clicked - Open signup modal');
    
    // Option 3: Scroller vers une section spécifique
    // document.getElementById('pricing')?.scrollIntoView({ behavior: 'smooth' });
  };

  // CTA: "See how it works" (bouton avec icône Play)
  // ACTION: Ouvre une vidéo de démo ou scrolle vers la section How it works
  const handleWatchDemo = () => {
    // Option 1: Ouvrir une modal vidéo
    console.log('Watch Demo clicked - Open video modal');
    
    // Option 2: Scroller vers la section How it works
    document.getElementById('how-it-works')?.scrollIntoView({ behavior: 'smooth' });
  };

  // CTA: "Sign in" (icône utilisateur dans le header)
  // ACTION: Ouvre le modal de connexion
  const handleSignIn = () => {
    console.log('Sign In clicked - Open login modal');
    // Rediriger vers la page de login
    // window.location.href = '/login';
  };

  // CTA: Sélection d'un plan dans la section Pricing
  // ACTION: Redirige vers Stripe Checkout ou ouvre le modal d'inscription
  const handleSelectPlan = (plan: PricingPlan) => {
    console.log('Plan selected:', plan.name);
    
    if (plan.name === 'Free') {
      // Rediriger vers l'inscription gratuite
      // window.location.href = '/signup?plan=free';
    } else {
      // Rediriger vers Stripe Checkout
      // stripe.redirectToCheckout({ priceId: plan.priceId });
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-200">
      <Navbar 
        onGetStarted={handleGetStarted}
        onSignIn={handleSignIn}
      />
      <main>
        <HeroSection 
          onGetStarted={handleGetStarted}
          onWatchDemo={handleWatchDemo}
        />
        <HowItWorksSection />
        <DashboardPreviewSection onGetStarted={handleGetStarted} />
        <FeaturesSection />
        <PricingSection onSelectPlan={handleSelectPlan} />
        <FAQSection />
        <CTASection onGetStarted={handleGetStarted} />
      </main>
      <Footer />
    </div>
  );
}

export default App;
