# Craflect Landing Page — Intégration Replit

## 📁 Structure des Fichiers

```
src/
├── components/
│   ├── Navbar.tsx              # Header minimal
│   ├── HeroSection.tsx         # Hero avec Dashboard preview
│   ├── HowItWorksSection.tsx   # 3 étapes du workflow
│   ├── DashboardPreviewSection.tsx  # See it. Understand it. Use it.
│   ├── FeaturesSection.tsx     # 4 features principales
│   ├── PricingSection.tsx      # 3 plans avec équivalents vidéos
│   ├── FAQSection.tsx          # FAQ accordéon
│   ├── CTASection.tsx          # CTA final
│   ├── Footer.tsx              # Footer avec liens
│   └── index.ts                # Exports
├── types/
│   └── index.ts                # Types TypeScript
└── App.tsx                     # Composant principal
```

---

## 🔗 CTAs à Connecter à l'Authentification

### 1. **"Get started"** (bouton principal)
- **Emplacement**: Navbar + Hero + CTA final
- **Action attendue**: Rediriger vers `/signup` ou ouvrir modal d'inscription
- **Code à implémenter**:
```tsx
const handleGetStarted = () => {
  // Si utilisateur connecté → Dashboard
  if (isAuthenticated) {
    window.location.href = '/dashboard';
  } else {
    // Sinon → Page d'inscription
    window.location.href = '/signup';
  }
};
```

### 2. **"Sign in"** (icône utilisateur dans le header)
- **Emplacement**: Navbar (icône User)
- **Action attendue**: Rediriger vers `/login`
- **Code à implémenter**:
```tsx
const handleSignIn = () => {
  window.location.href = '/login';
};
```

### 3. **"See how it works"** (bouton avec Play)
- **Emplacement**: Hero
- **Action attendue**: Scroller vers section "How it works" OU ouvrir vidéo
- **Code à implémenter**:
```tsx
const handleWatchDemo = () => {
  // Option 1: Scroller
  document.getElementById('how-it-works')?.scrollIntoView({ behavior: 'smooth' });
  
  // Option 2: Ouvrir modal vidéo
  setShowVideoModal(true);
};
```

### 4. **Sélection d'un plan** (Pricing)
- **Emplacement**: PricingSection
- **Action attendue**: Rediriger vers Stripe Checkout
- **Code à implémenter**: Voir section Stripe ci-dessous

---

## 💳 Configuration Stripe

### 1. Installation

```bash
npm install @stripe/stripe-js @stripe/react-stripe-js
```

### 2. Configuration

Créer un fichier `src/lib/stripe.ts`:

```typescript
import { loadStripe } from '@stripe/stripe-js';

// Clé publique Stripe (à mettre dans les variables d'environnement)
const STRIPE_PUBLIC_KEY = process.env.VITE_STRIPE_PUBLIC_KEY;

export const stripePromise = loadStripe(STRIPE_PUBLIC_KEY);

// IDs des prix Stripe (à configurer dans le Dashboard Stripe)
export const PRICE_IDS = {
  creator_monthly: 'price_xxx',  // $24/mois
  creator_yearly: 'price_xxx',   // $19/mois (facturé annuellement)
  pro_monthly: 'price_xxx',      // $109/mois
  pro_yearly: 'price_xxx',       // $99/mois (facturé annuellement)
};
```

### 3. Backend - Créer une session Checkout

Dans ton backend Express (server/routes.ts):

```typescript
import Stripe from 'stripe';

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY, {
  apiVersion: '2023-10-16',
});

// Route pour créer une session Checkout
app.post('/api/create-checkout-session', async (req, res) => {
  const { priceId, userId } = req.body;
  
  try {
    const session = await stripe.checkout.sessions.create({
      mode: 'subscription',
      payment_method_types: ['card'],
      line_items: [
        {
          price: priceId,
          quantity: 1,
        },
      ],
      success_url: `${process.env.APP_URL}/dashboard?success=true`,
      cancel_url: `${process.env.APP_URL}/pricing?canceled=true`,
      client_reference_id: userId, // Pour lier l'abonnement à l'utilisateur
      metadata: {
        userId: userId,
      },
    });

    res.json({ sessionId: session.id, url: session.url });
  } catch (error) {
    console.error('Stripe error:', error);
    res.status(500).json({ error: 'Failed to create checkout session' });
  }
});

// Webhook pour gérer les événements Stripe
app.post('/api/stripe-webhook', express.raw({ type: 'application/json' }), async (req, res) => {
  const sig = req.headers['stripe-signature'];
  const endpointSecret = process.env.STRIPE_WEBHOOK_SECRET;

  let event;
  try {
    event = stripe.webhooks.constructEvent(req.body, sig, endpointSecret);
  } catch (err) {
    console.error('Webhook error:', err.message);
    return res.status(400).send(`Webhook Error: ${err.message}`);
  }

  // Gérer les événements
  switch (event.type) {
    case 'checkout.session.completed':
      const session = event.data.object;
      // Mettre à jour l'utilisateur dans la BDD
      await updateUserSubscription(session.client_reference_id, {
        status: 'active',
        plan: session.metadata.plan,
        stripeSubscriptionId: session.subscription,
      });
      break;
      
    case 'invoice.payment_failed':
      // Gérer l'échec de paiement
      break;
      
    case 'customer.subscription.deleted':
      // Gérer la résiliation
      break;
  }

  res.json({ received: true });
});
```

### 4. Frontend - Intégration dans PricingSection

Modifier `handleSelectPlan` dans `App.tsx`:

```tsx
import { loadStripe } from '@stripe/stripe-js';

const stripePromise = loadStripe(import.meta.env.VITE_STRIPE_PUBLIC_KEY);

const handleSelectPlan = async (plan: PricingPlan, isYearly: boolean) => {
  // Si utilisateur non connecté → Rediriger vers signup
  if (!isAuthenticated) {
    window.location.href = '/signup?redirect=pricing';
    return;
  }
  
  // Si plan Free → Rediriger vers dashboard
  if (plan.name === 'Free') {
    window.location.href = '/dashboard';
    return;
  }
  
  // Sinon → Stripe Checkout
  const priceId = isYearly 
    ? PRICE_IDS[`${plan.name.toLowerCase()}_yearly`]
    : PRICE_IDS[`${plan.name.toLowerCase()}_monthly`];
  
  try {
    const response = await fetch('/api/create-checkout-session', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ 
        priceId, 
        userId: currentUser.id 
      }),
    });
    
    const { url } = await response.json();
    window.location.href = url; // Rediriger vers Stripe Checkout
  } catch (error) {
    console.error('Checkout error:', error);
    alert('Failed to start checkout. Please try again.');
  }
};
```

### 5. Variables d'Environnement Replit

Dans ton projet Replit, ajoute ces secrets:

```
VITE_STRIPE_PUBLIC_KEY=pk_live_xxx
STRIPE_SECRET_KEY=sk_live_xxx
STRIPE_WEBHOOK_SECRET=whsec_xxx
```

---

## 🔧 Intégration dans Replit

### 1. Copier les fichiers

Copie tous les fichiers du dossier `src/` dans ton projet Replit.

### 2. Mettre à jour App.tsx principal

Remplace le contenu de ton `App.tsx` par celui fourni, en adaptant les handlers selon ton système d'auth.

### 3. Installer les dépendances

```bash
npm install @stripe/stripe-js @stripe/react-stripe-js
```

### 4. Configurer les routes

Dans `server/routes.ts`, ajoute les routes Stripe (voir section ci-dessus).

---

## 🎨 Personnalisation

### Couleurs
Les couleurs sont définies dans Tailwind:
- **Primary**: `purple-600` (#7c3aed)
- **Accent**: `fuchsia-500` (#d946ef)
- **Background**: `slate-950` (#020617)

### Images
Remplace le Dashboard mock dans `HeroSection.tsx` par des screenshots réels:
```tsx
<img src="/screenshots/dashboard.png" alt="Craflect Dashboard" />
```

### Textes
Tous les textes sont dans les composants. Modifie-les directement selon tes besoins.

---

## 📱 Responsive
La landing page est entièrement responsive:
- **Desktop**: Layout complet
- **Tablet**: Grids ajustés
- **Mobile**: Menu hamburger, sections empilées

---

## ✅ Checklist Intégration

- [ ] Copier tous les fichiers dans `src/`
- [ ] Installer `@stripe/stripe-js`
- [ ] Configurer les variables d'environnement Stripe
- [ ] Créer les routes backend `/api/create-checkout-session`
- [ ] Configurer le webhook Stripe
- [ ] Connecter les CTAs à ton système d'auth
- [ ] Remplacer le Dashboard mock par des screenshots réels
- [ ] Tester le flux complet (signup → pricing → stripe → dashboard)

---

Besoin d'aide pour une étape spécifique ?
