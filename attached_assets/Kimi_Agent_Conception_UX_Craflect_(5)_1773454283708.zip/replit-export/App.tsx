import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { Overview } from '@/pages/Overview';
import { Users } from '@/pages/Users';
import { Subscriptions } from '@/pages/Subscriptions';
import { SystemLogs } from '@/pages/SystemLogs';
import { Settings } from '@/pages/Settings';

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/system/founder" element={<Overview />} />
        <Route path="/system/founder/users" element={<Users />} />
        <Route path="/system/founder/subscriptions" element={<Subscriptions />} />
        <Route path="/system/founder/logs" element={<SystemLogs />} />
        <Route path="/system/founder/settings" element={<Settings />} />
        <Route path="*" element={<Navigate to="/system/founder" replace />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;
