# BRIEF - CRAFLECT AUTH & ONBOARDING

## OBJECTIF
Implémenter les pages d'authentification et d'onboarding pour Craflect avec validation complète et gestion d'erreurs.

---

## DÉPENDANCES À INSTALLER

```bash
npm install react-router-dom framer-motion
```

---

## STRUCTURE DES FICHIERS

```
src/
├── App.tsx                          # Router principal
├── pages/
│   ├── auth/
│   │   ├── Welcome.tsx              # Page d'accueil (Google/Email)
│   │   ├── SignIn.tsx               # Connexion avec erreurs
│   │   ├── SignUp.tsx               # Inscription avec validation password
│   │   ├── ForgotPassword.tsx       # Réinitialisation mot de passe
│   │   ├── EmailConfirmation.tsx    # Page confirmation email
│   │   └── Admin2FA.tsx             # 2FA pour admin
│   └── onboarding/
│       └── Onboarding.tsx           # Funnel 5 étapes
```

---

## ROUTES

| Route | Page | Description |
|-------|------|-------------|
| `/welcome` | Welcome | Choix Google/Email |
| `/signin` | SignIn | Email + password + erreurs |
| `/signup` | SignUp | Email + password validation |
| `/forgot-password` | ForgotPassword | Reset password flow |
| `/email-confirmation` | EmailConfirmation | Attente vérification |
| `/admin-2fa` | Admin2FA | Code 6 chiffres |
| `/onboarding` | Onboarding | 5 étapes onboarding |

---

## VALIDATIONS IMPLÉMENTÉES

### SignIn
- Email requis + format valide
- Password requis
- Message d'erreur général : "Invalid email or password"
- Demo : email `error@test.com` = erreur

### SignUp
- Email requis + format valide
- Password : 8 caractères min, 1 majuscule, 1 chiffre, 1 spécial
- Confirm password : doit matcher
- Checkbox Terms obligatoire
- Validation en temps réel (checklist verte)

### ForgotPassword
- Email requis + format valide
- État "email envoyé" avec succès
- Compte à rebours 60s pour resend

### Admin2FA
- 6 chiffres obligatoires
- Auto-focus entre inputs
- Support paste
- Demo : code `000000` = erreur

---

## ONBOARDING (5 ÉTAPES)

1. **Welcome** : Titre + bouton Commencer
2. **Role** : Sélection 4 rôles (Créateur/Marketeur/Entrepreneur/Explorateur)
3. **Topics** : Sélection jusqu'à 3 niches
4. **Analyzing** : Animation loading + checklist
5. **Result** : Idée virale avec score + CTA

---

## WORKFLOW COMPLET

```
Landing Page → /welcome
                    ↓
            ┌───────┴───────┐
            ↓               ↓
      Google OAuth    /signup (email)
                            ↓
                    Validation password
                            ↓
              /email-confirmation
                            ↓
                    (click link in email)
                            ↓
                    /onboarding
                            ↓
                    Dashboard

SignIn Flow:
/welcome → /signin → (admin? → /admin-2fa → /dashboard)
                            ↓
                    (user → /onboarding → /dashboard)
```

---

## FEATURES CLÉS

- Animations Framer Motion sur toutes les pages
- Validation en temps réel
- Messages d'erreur sous chaque champ
- Loading states
- Responsive design
- Dark theme cohérent

---

## INTÉGRATION API (NEXT STEPS)

Remplacer les `setTimeout` par les vrais appels API :

```typescript
// SignIn
const response = await fetch('/api/auth/login', {
  method: 'POST',
  body: JSON.stringify({ email, password })
});

// SignUp
const response = await fetch('/api/auth/register', {
  method: 'POST',
  body: JSON.stringify({ email, password })
});

// 2FA
const response = await fetch('/api/auth/verify-2fa', {
  method: 'POST',
  body: JSON.stringify({ code })
});
```

---

## NOTES

- Toutes les pages sont en anglais (cohérent avec landing)
- Design sombre `#0a0a0f` cohérent avec le reste
- Couleurs : violet-600 à fuchsia-600 (dégradé)
- Pas de sidebar sur les pages auth (full screen)
