// CRAFLECT TYPES
// ==============

export type Page = 'home' | 'opportunities' | 'studio' | 'workspace' | 'insights' | 'settings' | 'billing';

export type WorkflowStep = 'idea' | 'script' | 'blueprint' | 'export';

export type StudioMode = 'opportunity' | 'script-to-video' | 'templates' | 'avatar' | 'remix';

export type SettingsTab = 'profile' | 'notifications' | 'security' | 'appearance';

export type PlanType = 'free' | 'creator' | 'pro';

export type ProjectStatus = 'idea' | 'script' | 'blueprint' | 'completed';

export interface VideoCard {
  id: string;
  thumbnail: string;
  hook: string;
  views: string;
  format: string;
  viralityScore: number;
  platform: 'tiktok' | 'reels' | 'shorts';
  creator: string;
}

export interface Opportunity {
  id: string;
  topic: string;
  hook: string;
  format: string;
  predictedViews: string;
  confidence: number;
  trend: 'rising' | 'stable' | 'hot';
  whyItWorks?: string;
}

export interface Project {
  id: string;
  title: string;
  hook: string;
  format: string;
  status: ProjectStatus;
  createdAt: string;
  viralityScore: number;
}

export interface Plan {
  name: string;
  price: number;
  yearlyPrice?: number;
  period: 'month' | 'year';
  credits: number;
  maxRollover: number;
  features: string[];
  cta: string;
  current: boolean;
  popular?: boolean;
  disabled?: boolean;
}

export interface CreditHistoryItem {
  action: string;
  cost: number;
  date: string;
  project: string;
}

export interface User {
  id: string;
  firstName: string;
  lastName: string;
  email: string;
  avatar?: string;
  bio?: string;
  plan: PlanType;
  credits: number;
  creditsUsed: number;
  creditsTotal: number;
}

export interface NotificationSettings {
  email: boolean;
  push: boolean;
  weekly: boolean;
  newOpportunities: boolean;
  creditAlerts: boolean;
}

export interface GeneratedContent {
  hook: string;
  script: string;
  blueprint: {
    scenes: Scene[];
    duration: string;
    visualStyle: string;
  };
}

export interface Scene {
  id: number;
  timestamp: string;
  description: string;
  visual: string;
  audio: string;
  textOverlay?: string;
}

export interface Pattern {
  name: string;
  score: number;
  volume: string;
}

export interface TrendingTopic {
  topic: string;
  growth: string;
  velocity: 'hot' | 'rising' | 'stable';
}
