import React, { useState } from 'react';
import { Play, Eye, Sparkles, BarChart3, Bookmark } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { ViralityBadge } from './ViralityBadge';
import type { VideoCard as VideoCardType } from '@/types';

interface VideoCardProps {
  video: VideoCardType;
  compact?: boolean;
  onCreateSimilar?: (video: VideoCardType) => void;
  onAnalyze?: (video: VideoCardType) => void;
  onSave?: (video: VideoCardType) => void;
}

export const VideoCard: React.FC<VideoCardProps> = ({ 
  video, 
  compact = false,
  onCreateSimilar,
  onAnalyze,
  onSave
}) => {
  const [isHovered, setIsHovered] = useState(false);

  const gradients: Record<string, string> = {
    'gradient-1': 'from-violet-600 via-purple-600 to-fuchsia-600',
    'gradient-2': 'from-blue-600 via-cyan-600 to-teal-600',
    'gradient-3': 'from-orange-600 via-amber-600 to-yellow-600',
    'gradient-4': 'from-rose-600 via-pink-600 to-purple-600',
  };

  if (compact) {
    return (
      <div className="group relative bg-slate-900/50 rounded-xl overflow-hidden border border-slate-800 hover:border-purple-500/50 transition-all cursor-pointer">
        <div className={`relative aspect-[9/16] bg-gradient-to-br ${gradients[video.thumbnail]} overflow-hidden`}>
          <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />
          <div className="absolute top-2 left-2">
            <span className="px-2 py-0.5 bg-black/60 backdrop-blur-sm text-white text-[10px] rounded-full capitalize">
              {video.platform}
            </span>
          </div>
          <div className="absolute top-2 right-2">
            <ViralityBadge score={video.viralityScore} />
          </div>
          <div className="absolute bottom-0 left-0 right-0 p-3">
            <p className="text-white font-medium text-xs line-clamp-2">{video.hook}</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div 
      className="group relative bg-slate-900/50 rounded-2xl overflow-hidden border border-slate-800 hover:border-purple-500/50 transition-all duration-300 hover:scale-[1.02] hover:shadow-2xl hover:shadow-purple-500/10"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      {/* Thumbnail */}
      <div className={`relative aspect-[9/16] bg-gradient-to-br ${gradients[video.thumbnail]} overflow-hidden`}>
        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />
        
        {/* Platform Badge */}
        <div className="absolute top-3 left-3">
          <span className="px-2 py-0.5 bg-black/60 backdrop-blur-sm text-white text-xs rounded-full capitalize">
            {video.platform}
          </span>
        </div>
        
        {/* Virality Score */}
        <div className="absolute top-3 right-3">
          <ViralityBadge score={video.viralityScore} />
        </div>
        
        {/* Hover Actions */}
        <div className={`absolute inset-0 flex flex-col items-center justify-center gap-2 transition-opacity duration-300 ${isHovered ? 'opacity-100' : 'opacity-0'}`}>
          <Button 
            size="sm" 
            className="bg-purple-600 hover:bg-purple-700 text-white w-36"
            onClick={() => onCreateSimilar?.(video)}
          >
            <Sparkles className="w-4 h-4 mr-2" />Create Similar
          </Button>
          <Button 
            size="sm" 
            variant="outline" 
            className="border-white/30 text-white hover:bg-white/20 w-36"
            onClick={() => onAnalyze?.(video)}
          >
            <BarChart3 className="w-4 h-4 mr-2" />Analyze
          </Button>
          <Button 
            size="sm" 
            variant="outline" 
            className="border-white/30 text-white hover:bg-white/20 w-36"
            onClick={() => onSave?.(video)}
          >
            <Bookmark className="w-4 h-4 mr-2" />Save
          </Button>
        </div>
        
        {/* Hook Text */}
        <div className="absolute bottom-0 left-0 right-0 p-4">
          <p className="text-white font-semibold text-sm line-clamp-2 leading-tight">
            {video.hook}
          </p>
        </div>
      </div>
      
      {/* Card Info */}
      <div className="p-4">
        <div className="flex items-center justify-between mb-2">
          <span className="text-xs text-slate-400">{video.format}</span>
          <div className="flex items-center gap-1 text-xs text-slate-400">
            <Eye className="w-3 h-3" />
            {video.views}
          </div>
        </div>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Avatar className="w-6 h-6">
              <AvatarFallback className="bg-slate-700 text-xs">
                {video.creator[1].toUpperCase()}
              </AvatarFallback>
            </Avatar>
            <span className="text-xs text-slate-400">{video.creator}</span>
          </div>
        </div>
      </div>
    </div>
  );
};
