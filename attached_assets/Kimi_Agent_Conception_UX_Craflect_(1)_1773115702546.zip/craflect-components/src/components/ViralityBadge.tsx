import React from 'react';
import { Flame } from 'lucide-react';
import { Badge } from './ui/Badge';

interface ViralityBadgeProps {
  score: number;
  className?: string;
}

export const ViralityBadge: React.FC<ViralityBadgeProps> = ({ score, className }) => {
  const getVariant = () => {
    if (score >= 90) return 'red';
    if (score >= 80) return 'orange';
    if (score >= 60) return 'yellow';
    return 'slate';
  };

  return (
    <Badge variant={getVariant()} className={className}>
      <Flame className="w-3 h-3 mr-1" />
      {score}
    </Badge>
  );
};
