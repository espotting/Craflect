import React from 'react';
import { Badge } from './ui/Badge';
import type { ProjectStatus } from '@/types';

interface StatusBadgeProps {
  status: ProjectStatus;
  className?: string;
}

export const StatusBadge: React.FC<StatusBadgeProps> = ({ status, className }) => {
  const config = {
    idea: { variant: 'slate' as const, label: 'Idea' },
    script: { variant: 'purple' as const, label: 'Script' },
    blueprint: { variant: 'purple' as const, label: 'Blueprint' },
    completed: { variant: 'green' as const, label: 'Ready' },
  };

  const { variant, label } = config[status];

  return (
    <Badge variant={variant} className={className}>
      {label}
    </Badge>
  );
};
