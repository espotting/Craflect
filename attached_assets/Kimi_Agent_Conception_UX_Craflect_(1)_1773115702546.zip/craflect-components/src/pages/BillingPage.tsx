import React from 'react';
import { CreditCard, Zap, BarChart3, Check, ExternalLink, Plus, Lightbulb, FileText, Layers, User } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/Badge';
import type { Plan, CreditHistoryItem } from '@/types';

interface BillingPageProps {
  currentPlan: Plan;
  creditsUsed: number;
  creditsTotal: number;
  plans: Plan[];
  creditHistory: CreditHistoryItem[];
  onUpgrade: (plan: Plan) => void;
  onManageSubscription: () => void;
}

export const BillingPage: React.FC<BillingPageProps> = ({
  currentPlan,
  creditsUsed,
  creditsTotal,
  plans,
  creditHistory,
  onUpgrade,
  onManageSubscription
}) => {
  const creditsRemaining = creditsTotal - creditsUsed;
  const creditsPercent = (creditsUsed / creditsTotal) * 100;

  const creditCosts = [
    { action: 'Generate Idea', cost: 1, icon: Lightbulb },
    { action: 'Generate Script', cost: 1, icon: FileText },
    { action: 'Generate Blueprint', cost: 1, icon: Layers },
    { action: 'AI Avatar', cost: 3, icon: User },
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h2 className="text-2xl font-bold text-white">Plan & Billing</h2>
        <p className="text-slate-400">Manage your subscription and AI credits</p>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-3 gap-6">
        {/* Current Plan */}
        <div className="bg-slate-900/50 rounded-2xl p-6 border border-slate-800">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <CreditCard className="w-5 h-5 text-purple-400" />
              <span className="text-slate-400">Current Plan</span>
            </div>
            <Badge variant="purple">{currentPlan.name}</Badge>
          </div>
          <p className="text-3xl font-bold text-white mb-1">
            ${currentPlan.price}<span className="text-lg text-slate-400">/mo</span>
          </p>
          <p className="text-slate-400 text-sm mb-4">Renews on Apr 10, 2026</p>
          <Button 
            variant="outline" 
            className="w-full border-slate-700 text-slate-300"
            onClick={onManageSubscription}
          >
            <ExternalLink className="w-4 h-4 mr-2" />
            Manage Subscription
          </Button>
        </div>

        {/* AI Credits */}
        <div className="bg-slate-900/50 rounded-2xl p-6 border border-slate-800">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <Zap className="w-5 h-5 text-yellow-400" />
              <span className="text-slate-400">AI Credits</span>
            </div>
            <Badge variant="yellow">{creditsRemaining} left</Badge>
          </div>
          <div className="flex items-end gap-2 mb-2">
            <span className="text-3xl font-bold text-white">{creditsUsed}</span>
            <span className="text-lg text-slate-400">/ {creditsTotal}</span>
          </div>
          <p className="text-slate-400 text-sm mb-4">
            {creditsRemaining} credits remaining this month
          </p>
          <div className="h-2 bg-slate-800 rounded-full overflow-hidden">
            <div 
              className="h-full bg-gradient-to-r from-yellow-400 to-orange-400 transition-all"
              style={{ width: `${creditsPercent}%` }}
            />
          </div>
        </div>

        {/* Usage Stats */}
        <div className="bg-slate-900/50 rounded-2xl p-6 border border-slate-800">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <BarChart3 className="w-5 h-5 text-green-400" />
              <span className="text-slate-400">This Month</span>
            </div>
          </div>
          <div className="space-y-3">
            <div className="flex justify-between text-sm">
              <span className="text-slate-400">Scripts Generated</span>
              <span className="text-white">24</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-slate-400">Blueprints Created</span>
              <span className="text-white">18</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-slate-400">Videos Exported</span>
              <span className="text-white">12</span>
            </div>
          </div>
        </div>
      </div>

      {/* Credit Costs */}
      <div className="bg-slate-900/50 rounded-2xl p-6 border border-slate-800">
        <h3 className="text-white font-semibold mb-4">AI Credit Costs</h3>
        <div className="grid grid-cols-4 gap-4">
          {creditCosts.map((item, i) => (
            <div key={i} className="flex items-center gap-3 p-4 bg-slate-800/50 rounded-xl">
              <div className="w-10 h-10 rounded-lg bg-purple-500/20 flex items-center justify-center">
                <item.icon className="w-5 h-5 text-purple-400" />
              </div>
              <div>
                <p className="text-white text-sm">{item.action}</p>
                <p className="text-yellow-400 text-sm font-medium">{item.cost} credit{item.cost > 1 ? 's' : ''}</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Plans Comparison */}
      <div>
        <h3 className="text-white font-semibold mb-4">Compare Plans</h3>
        <div className="grid grid-cols-3 gap-6">
          {plans.map((plan) => (
            <div 
              key={plan.name}
              className={`bg-slate-900/50 rounded-2xl p-6 border ${
                plan.current ? 'border-purple-500/50' : 'border-slate-800'
              }`}
            >
              <div className="flex items-center justify-between mb-2">
                <h4 className="text-white font-semibold">{plan.name}</h4>
                {plan.current && <Badge variant="purple">Current</Badge>}
                {plan.popular && <Badge variant="green">Popular</Badge>}
              </div>
              <p className="text-3xl font-bold text-white mb-1">
                ${plan.price}<span className="text-lg text-slate-400">/mo</span>
              </p>
              <p className="text-slate-400 text-sm mb-4">
                {plan.credits.toLocaleString()} AI credits
                <span className="text-slate-500"> (max rollover: {plan.maxRollover})</span>
              </p>
              <ul className="space-y-2 mb-6">
                {plan.features.map((feature, i) => (
                  <li key={i} className="flex items-center gap-2 text-sm text-slate-300">
                    <Check className="w-4 h-4 text-green-400" />
                    {feature}
                  </li>
                ))}
              </ul>
              <Button 
                className={`w-full ${
                  plan.current 
                    ? 'bg-slate-800 text-slate-400 cursor-not-allowed' 
                    : 'bg-purple-600 hover:bg-purple-700 text-white'
                }`}
                disabled={plan.current}
                onClick={() => onUpgrade(plan)}
              >
                {plan.cta}
              </Button>
            </div>
          ))}
        </div>
      </div>

      {/* Credit History */}
      <div className="bg-slate-900/50 rounded-2xl p-6 border border-slate-800">
        <h3 className="text-white font-semibold mb-4">Credit History</h3>
        <div className="space-y-3">
          {creditHistory.map((item, i) => (
            <div key={i} className="flex items-center justify-between p-4 bg-slate-800/50 rounded-xl">
              <div className="flex items-center gap-4">
                <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${
                  item.cost < 0 ? 'bg-green-500/20' : 'bg-purple-500/20'
                }`}>
                  {item.cost < 0 ? (
                    <Zap className="w-5 h-5 text-green-400" />
                  ) : (
                    <Lightbulb className="w-5 h-5 text-purple-400" />
                  )}
                </div>
                <div>
                  <p className="text-white text-sm">{item.action}</p>
                  <p className="text-slate-400 text-xs">{item.project} • {item.date}</p>
                </div>
              </div>
              <span className={`font-medium ${item.cost < 0 ? 'text-green-400' : 'text-slate-300'}`}>
                {item.cost < 0 ? '+' : '-'}{Math.abs(item.cost)} credit{Math.abs(item.cost) > 1 ? 's' : ''}
              </span>
            </div>
          ))}
        </div>
      </div>

      {/* Payment Methods */}
      <div className="bg-slate-900/50 rounded-2xl p-6 border border-slate-800">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-white font-semibold">Payment Methods</h3>
          <Button variant="outline" className="border-slate-700 text-slate-300">
            <Plus className="w-4 h-4 mr-2" />
            Add Card
          </Button>
        </div>
        <div className="p-4 bg-slate-800/50 rounded-xl flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="w-12 h-8 bg-gradient-to-r from-purple-500 to-fuchsia-500 rounded flex items-center justify-center">
              <CreditCard className="w-6 h-4 text-white" />
            </div>
            <div>
              <p className="text-white text-sm">•••• 4242</p>
              <p className="text-slate-400 text-xs">Expires 12/27</p>
            </div>
          </div>
          <Badge variant="green">Default</Badge>
        </div>
      </div>
    </div>
  );
};
