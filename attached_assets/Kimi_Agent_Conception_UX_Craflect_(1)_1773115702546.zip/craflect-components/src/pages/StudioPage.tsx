import React from 'react';
import { ChevronLeft, Lightbulb, FileText, Layers, User, Film, Sparkles, ArrowRight, Clock, CheckCircle2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/Badge';
import { StatusBadge } from '@/components/StatusBadge';
import { ViralityBadge } from '@/components/ViralityBadge';
import type { Project } from '@/types';

interface StudioPageProps {
  onBack: () => void;
  onSelectMode: (mode: string) => void;
  recentProjects: Project[];
}

const studioModes = [
  {
    id: 'opportunity',
    icon: Lightbulb,
    title: 'Start from Viral Opportunity',
    description: 'Use a viral opportunity from our database as your starting point',
    badge: 'Recommended',
    color: 'from-purple-500 to-fuchsia-500',
  },
  {
    id: 'script-to-video',
    icon: FileText,
    title: 'Script to Video',
    description: 'Turn your script into a complete video blueprint',
    color: 'from-blue-500 to-cyan-500',
  },
  {
    id: 'templates',
    icon: Layers,
    title: 'Viral Templates',
    description: 'Start from proven templates ready to customize',
    color: 'from-green-500 to-emerald-500',
  },
  {
    id: 'avatar',
    icon: User,
    title: 'AI Avatar',
    description: 'Create videos with your AI-generated avatar',
    badge: 'Popular',
    color: 'from-orange-500 to-amber-500',
  },
  {
    id: 'remix',
    icon: Film,
    title: 'Video Remix',
    description: 'Transform existing videos with AI enhancements',
    badge: 'Pro',
    disabled: true,
    color: 'from-pink-500 to-rose-500',
  },
];

export const StudioPage: React.FC<StudioPageProps> = ({
  onBack,
  onSelectMode,
  recentProjects
}) => {
  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex items-center gap-4">
        <Button variant="outline" size="icon" onClick={onBack} className="border-slate-700">
          <ChevronLeft className="w-5 h-5" />
        </Button>
        <div>
          <h2 className="text-2xl font-bold text-white">Studio Creation</h2>
          <p className="text-slate-400">Choose your creation mode</p>
        </div>
      </div>

      {/* Creation Modes */}
      <div className="grid grid-cols-2 gap-6">
        {studioModes.map((mode) => (
          <div
            key={mode.id}
            onClick={() => !mode.disabled && onSelectMode(mode.id)}
            className={`relative bg-slate-900/50 rounded-2xl p-6 border transition-all ${
              mode.disabled 
                ? 'opacity-50 cursor-not-allowed border-slate-800' 
                : 'border-slate-800 hover:border-purple-500/50 cursor-pointer group'
            }`}
          >
            {mode.badge && (
              <Badge 
                variant={mode.badge === 'Pro' ? 'purple' : 'default'}
                className="absolute top-4 right-4"
              >
                {mode.badge}
              </Badge>
            )}
            
            <div className={`w-14 h-14 rounded-2xl bg-gradient-to-br ${mode.color} flex items-center justify-center mb-4 group-hover:scale-110 transition-transform`}>
              <mode.icon className="w-7 h-7 text-white" />
            </div>
            
            <h3 className="text-white font-semibold text-lg mb-2">{mode.title}</h3>
            <p className="text-slate-400 text-sm">{mode.description}</p>
            
            {!mode.disabled && (
              <div className="mt-4 flex items-center text-purple-400 text-sm font-medium opacity-0 group-hover:opacity-100 transition-opacity">
                Start Creating
                <ArrowRight className="w-4 h-4 ml-1" />
              </div>
            )}
          </div>
        ))}
      </div>

      {/* Recent Projects */}
      {recentProjects.length > 0 && (
        <div>
          <h3 className="text-white font-semibold mb-4">Recent Projects</h3>
          <div className="grid grid-cols-4 gap-4">
            {recentProjects.map((project) => (
              <div 
                key={project.id} 
                className="bg-slate-900/50 rounded-xl p-4 border border-slate-800 hover:border-purple-500/30 transition-all cursor-pointer group"
              >
                <div className="flex items-start justify-between mb-3">
                  <StatusBadge status={project.status} />
                  <button className="text-slate-500 hover:text-white opacity-0 group-hover:opacity-100 transition-opacity">
                    <span className="sr-only">More options</span>
                    <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24">
                      <circle cx="12" cy="5" r="2" />
                      <circle cx="12" cy="12" r="2" />
                      <circle cx="12" cy="19" r="2" />
                    </svg>
                  </button>
                </div>
                <p className="text-white font-medium text-sm line-clamp-2 mb-2">
                  {project.hook}
                </p>
                <div className="flex items-center justify-between">
                  <span className="text-xs text-slate-400 flex items-center gap-1">
                    <Clock className="w-3 h-3" />
                    {project.createdAt}
                  </span>
                  <ViralityBadge score={project.viralityScore} />
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Quick Tip */}
      <div className="bg-blue-900/20 rounded-xl p-4 border border-blue-500/20 flex items-start gap-3">
        <Sparkles className="w-5 h-5 text-blue-400 mt-0.5" />
        <div>
          <p className="text-blue-300 font-medium text-sm">Pro Tip</p>
          <p className="text-blue-400/80 text-sm">
            Start with "Viral Opportunity" for the best results. Our AI analyzes 50,000+ videos 
            to find the patterns that work in your niche.
          </p>
        </div>
      </div>
    </div>
  );
};
