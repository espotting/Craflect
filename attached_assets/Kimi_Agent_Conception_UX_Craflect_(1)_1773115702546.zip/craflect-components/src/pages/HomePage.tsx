import React from 'react';
import { TrendingUp, Zap, Sparkles, ArrowRight, BarChart3 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { VideoCard } from '@/components/VideoCard';
import { OpportunityCard } from '@/components/OpportunityCard';
import { GuidedWorkflow } from '@/components/GuidedWorkflow';
import type { VideoCard as VideoCardType, Opportunity, WorkflowStep } from '@/types';

interface HomePageProps {
  intelligenceMode: boolean;
  onToggleMode: () => void;
  onNavigate: (page: string) => void;
  workflowStep: WorkflowStep;
  onWorkflowNext: () => void;
  viralPlay: Opportunity;
  trendingVideos: VideoCardType[];
  opportunities: Opportunity[];
  onCreateVideo: (item: Opportunity | VideoCardType) => void;
  onCreateSimilar: (video: VideoCardType) => void;
  onAnalyze: (video: VideoCardType) => void;
  onSave: (video: VideoCardType) => void;
}

// Intelligence Layer Component
const IntelligenceLayer: React.FC = () => {
  const stats = [
    { label: 'Videos Analyzed', value: '50,247', change: '+12%', icon: BarChart3, color: 'text-blue-400' },
    { label: 'Patterns Detected', value: '1,847', change: '+8%', icon: TrendingUp, color: 'text-purple-400' },
    { label: 'Avg Virality Score', value: '72.4', change: '+5%', icon: Zap, color: 'text-orange-400' },
    { label: 'Success Rate', value: '68%', change: '+15%', icon: TrendingUp, color: 'text-green-400' },
  ];

  const patterns = [
    { name: 'Question Hook + Listicle', score: 94, volume: '2.4K videos' },
    { name: 'Story + Lesson Learned', score: 89, volume: '1.8K videos' },
    { name: 'Myth Busting Format', score: 86, volume: '1.2K videos' },
    { name: 'Before/After Reveal', score: 82, volume: '956 videos' },
  ];

  const topics = [
    { topic: 'AI Tools', growth: '+245%', velocity: 'hot' as const },
    { topic: 'Productivity Hacks', growth: '+189%', velocity: 'rising' as const },
    { topic: 'Content Strategy', growth: '+156%', velocity: 'rising' as const },
    { topic: 'Side Hustles', growth: '+134%', velocity: 'stable' as const },
    { topic: 'Mindset Shifts', growth: '+98%', velocity: 'stable' as const },
  ];

  const hooks = [
    { type: 'Question', avgViews: '450K', engagement: '8.5%' },
    { type: 'Story', avgViews: '380K', engagement: '7.2%' },
    { type: 'Listicle', avgViews: '520K', engagement: '9.1%' },
    { type: 'Myth', avgViews: '290K', engagement: '6.8%' },
    { type: 'CTA', avgViews: '180K', engagement: '4.5%' },
  ];

  return (
    <div className="space-y-6">
      {/* Stats */}
      <div className="grid grid-cols-4 gap-4">
        {stats.map((stat, i) => (
          <div key={i} className="bg-slate-900/50 rounded-xl p-4 border border-slate-800">
            <div className="flex items-center justify-between mb-2">
              <span className="text-slate-400 text-sm">{stat.label}</span>
              <stat.icon className={`w-4 h-4 ${stat.color}`} />
            </div>
            <div className="flex items-end gap-2">
              <span className="text-2xl font-bold text-white">{stat.value}</span>
              <span className="text-green-400 text-sm">{stat.change}</span>
            </div>
          </div>
        ))}
      </div>

      {/* Charts */}
      <div className="grid grid-cols-2 gap-6">
        {/* Patterns */}
        <div className="bg-slate-900/50 rounded-2xl p-6 border border-slate-800">
          <h3 className="text-white font-semibold mb-4 flex items-center gap-2">
            <BarChart3 className="w-5 h-5 text-purple-400" />
            Top Performing Patterns
          </h3>
          <div className="space-y-3">
            {patterns.map((item, i) => (
              <div key={i} className="flex items-center gap-4">
                <span className="text-slate-500 w-6">{i + 1}</span>
                <div className="flex-1">
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-white text-sm">{item.name}</span>
                    <span className="text-purple-400 text-sm font-medium">{item.score}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="flex-1 h-1.5 bg-slate-800 rounded-full overflow-hidden">
                      <div 
                        className="h-full bg-gradient-to-r from-purple-500 to-fuchsia-500"
                        style={{ width: `${item.score}%` }}
                      />
                    </div>
                    <span className="text-slate-500 text-xs">{item.volume}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Topics */}
        <div className="bg-slate-900/50 rounded-2xl p-6 border border-slate-800">
          <h3 className="text-white font-semibold mb-4 flex items-center gap-2">
            <Zap className="w-5 h-5 text-orange-400" />
            Trending Topics (7d)
          </h3>
          <div className="space-y-3">
            {topics.map((item, i) => (
              <div key={i} className="flex items-center justify-between py-2 border-b border-slate-800 last:border-0">
                <div className="flex items-center gap-3">
                  <span className="text-slate-500">#</span>
                  <span className="text-white text-sm">{item.topic}</span>
                </div>
                <span className={`px-2 py-0.5 rounded-full text-xs font-medium ${
                  item.velocity === 'hot' ? 'bg-red-500/20 text-red-400' :
                  item.velocity === 'rising' ? 'bg-orange-500/20 text-orange-400' :
                  'bg-green-500/20 text-green-400'
                }`}>
                  {item.growth}
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Hook Performance */}
      <div className="bg-slate-900/50 rounded-2xl p-6 border border-slate-800">
        <h3 className="text-white font-semibold mb-4 flex items-center gap-2">
          <TrendingUp className="w-5 h-5 text-blue-400" />
          Hook Performance by Type
        </h3>
        <div className="grid grid-cols-5 gap-4">
          {hooks.map((hook, i) => (
            <div key={i} className="bg-slate-800/50 rounded-xl p-4 text-center">
              <p className="text-white font-medium mb-1">{hook.type}</p>
              <p className="text-2xl font-bold text-white mb-1">{hook.avgViews}</p>
              <p className="text-slate-400 text-sm mb-2">avg views</p>
              <div className="flex items-center justify-center gap-1">
                <TrendingUp className="w-4 h-4 text-purple-400" />
                <span className="text-purple-400 text-sm">{hook.engagement}</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export const HomePage: React.FC<HomePageProps> = ({
  intelligenceMode,
  onToggleMode,
  onNavigate,
  workflowStep,
  onWorkflowNext,
  viralPlay,
  trendingVideos,
  opportunities,
  onCreateVideo,
  onCreateSimilar,
  onAnalyze,
  onSave
}) => {
  if (intelligenceMode) {
    return <IntelligenceLayer />;
  }

  return (
    <div className="space-y-8">
      {/* Viral Play of the Day */}
      <section>
        <OpportunityCard 
          opportunity={viralPlay} 
          featured 
          onCreate={onCreateVideo}
        />
      </section>
      
      {/* Trending Now */}
      <section>
        <div className="flex items-center justify-between mb-6">
          <div>
            <h2 className="text-xl font-bold text-white flex items-center gap-2">
              <TrendingUp className="w-5 h-5 text-orange-400" />
              Trending Now
            </h2>
            <p className="text-slate-400 text-sm mt-1">
              Videos performing exceptionally well in your niche
            </p>
          </div>
          <Button 
            variant="outline" 
            className="border-slate-700 text-slate-300"
            onClick={() => onNavigate('opportunities')}
          >
            View All
            <ArrowRight className="w-4 h-4 ml-1" />
          </Button>
        </div>
        
        <div className="grid grid-cols-4 gap-6">
          {trendingVideos.map(video => (
            <VideoCard 
              key={video.id} 
              video={video}
              onCreateSimilar={onCreateSimilar}
              onAnalyze={onAnalyze}
              onSave={onSave}
            />
          ))}
        </div>
      </section>
      
      {/* More Opportunities */}
      <section>
        <div className="flex items-center justify-between mb-6">
          <div>
            <h2 className="text-xl font-bold text-white flex items-center gap-2">
              <Zap className="w-5 h-5 text-yellow-400" />
              More Opportunities
            </h2>
            <p className="text-slate-400 text-sm mt-1">
              Additional content ideas based on current trends
            </p>
          </div>
        </div>
        
        <div className="grid grid-cols-2 gap-4">
          {opportunities.map(opp => (
            <OpportunityCard 
              key={opp.id} 
              opportunity={opp}
              onCreate={onCreateVideo}
            />
          ))}
        </div>
      </section>

      {/* CTA Create */}
      <section className="bg-gradient-to-r from-purple-900/30 to-fuchsia-900/30 rounded-2xl p-8 border border-purple-500/20">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-2xl font-bold text-white mb-2">
              Ready to create your next viral video?
            </h2>
            <p className="text-slate-400">
              Jump into the Studio and turn these insights into viral content
            </p>
          </div>
          <Button 
            size="lg" 
            className="bg-purple-600 hover:bg-purple-700 text-white px-8 h-14 text-lg font-semibold rounded-xl"
            onClick={() => onNavigate('studio')}
          >
            <Sparkles className="w-5 h-5 mr-2" />
            Open Studio
            <ArrowRight className="w-5 h-5 ml-2" />
          </Button>
        </div>
      </section>

      {/* Guided Workflow */}
      <GuidedWorkflow 
        currentStep={workflowStep}
        onNextAction={onWorkflowNext}
      />
    </div>
  );
};
