import React from 'react';
import { Video, Hash, TrendingUp, Filter } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { VideoCard } from '@/components/VideoCard';
import type { VideoCard as VideoCardType } from '@/types';

interface OpportunitiesPageProps {
  videos: VideoCardType[];
  onCreateSimilar: (video: VideoCardType) => void;
  onAnalyze: (video: VideoCardType) => void;
  onSave: (video: VideoCardType) => void;
}

export const OpportunitiesPage: React.FC<OpportunitiesPageProps> = ({
  videos,
  onCreateSimilar,
  onAnalyze,
  onSave
}) => {
  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-white">Opportunities</h2>
          <p className="text-slate-400">All viral opportunities matched to your niche</p>
        </div>
        
        {/* Filters */}
        <div className="flex items-center gap-3">
          <Button variant="outline" className="border-slate-700 text-slate-300">
            <Filter className="w-4 h-4 mr-2" />
            Filter
          </Button>
          <Button variant="outline" className="border-slate-700 text-slate-300">
            <Video className="w-4 h-4 mr-2" />
            Format
          </Button>
          <Button variant="outline" className="border-slate-700 text-slate-300">
            <Hash className="w-4 h-4 mr-2" />
            Topic
          </Button>
          <Button variant="outline" className="border-slate-700 text-slate-300">
            <TrendingUp className="w-4 h-4 mr-2" />
            Trending
          </Button>
        </div>
      </div>

      {/* Grid */}
      <div className="grid grid-cols-4 gap-6">
        {videos.map((video, i) => (
          <VideoCard 
            key={`${video.id}-${i}`}
            video={video}
            onCreateSimilar={onCreateSimilar}
            onAnalyze={onAnalyze}
            onSave={onSave}
          />
        ))}
      </div>

      {/* Load More */}
      <div className="flex justify-center pt-4">
        <Button variant="outline" className="border-slate-700 text-slate-300 px-8">
          Load More
        </Button>
      </div>
    </div>
  );
};
