import React, { useState } from 'react';
import { User, Bell, Shield, Palette, LogOut, Check, Upload, Mail, Globe, Moon, Sun } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { Separator } from '@/components/ui/separator';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import type { SettingsTab, NotificationSettings } from '@/types';

interface SettingsPageProps {
  user: {
    firstName: string;
    lastName: string;
    email: string;
    bio: string;
  };
  onSaveProfile: (data: Partial<typeof user>) => void;
  onSignOut: () => void;
}

export const SettingsPage: React.FC<SettingsPageProps> = ({
  user,
  onSaveProfile,
  onSignOut
}) => {
  const [activeTab, setActiveTab] = useState<SettingsTab>('profile');
  const [darkMode, setDarkMode] = useState(true);
  const [notifications, setNotifications] = useState<NotificationSettings>({
    email: true,
    push: false,
    weekly: true,
    newOpportunities: true,
    creditAlerts: true,
  });
  const [profileData, setProfileData] = useState(user);

  const tabs = [
    { id: 'profile' as SettingsTab, label: 'Profile', icon: User },
    { id: 'notifications' as SettingsTab, label: 'Notifications', icon: Bell },
    { id: 'security' as SettingsTab, label: 'Security', icon: Shield },
    { id: 'appearance' as SettingsTab, label: 'Appearance', icon: Palette },
  ];

  const handleSaveProfile = () => {
    onSaveProfile(profileData);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h2 className="text-2xl font-bold text-white">Settings</h2>
        <p className="text-slate-400">Manage your account and platform preferences</p>
      </div>

      <div className="grid grid-cols-4 gap-6">
        {/* Sidebar */}
        <div className="space-y-2">
          {tabs.map((tab) => (
            <div
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center gap-3 px-4 py-3 rounded-xl cursor-pointer transition-all ${
                activeTab === tab.id 
                  ? 'bg-purple-500/20 text-purple-300 border border-purple-500/30' 
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
              }`}
            >
              <tab.icon className="w-5 h-5" />
              <span className="text-sm font-medium">{tab.label}</span>
            </div>
          ))}
          
          <Separator className="my-4 bg-slate-800" />
          
          <div 
            onClick={onSignOut}
            className="flex items-center gap-3 px-4 py-3 rounded-xl cursor-pointer text-red-400 hover:bg-red-500/10 transition-all"
          >
            <LogOut className="w-5 h-5" />
            <span className="text-sm font-medium">Sign Out</span>
          </div>
        </div>

        {/* Content */}
        <div className="col-span-3">
          {/* Profile Tab */}
          {activeTab === 'profile' && (
            <div className="bg-slate-900/50 rounded-2xl p-6 border border-slate-800 space-y-6">
              <h3 className="text-white font-semibold text-lg">Profile Information</h3>
              
              {/* Avatar */}
              <div className="flex items-center gap-6">
                <Avatar className="w-20 h-20">
                  <AvatarFallback className="bg-gradient-to-br from-purple-500 to-fuchsia-500 text-white text-2xl">
                    {profileData.firstName[0]}{profileData.lastName[0]}
                  </AvatarFallback>
                </Avatar>
                <div>
                  <Button variant="outline" className="border-slate-700 text-slate-300 mb-2">
                    <Upload className="w-4 h-4 mr-2" />
                    Change Avatar
                  </Button>
                  <p className="text-slate-500 text-sm">JPG, GIF or PNG. 1MB max.</p>
                </div>
              </div>

              {/* Name */}
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-slate-400 text-sm">First Name</label>
                  <input
                    type="text"
                    value={profileData.firstName}
                    onChange={(e) => setProfileData({ ...profileData, firstName: e.target.value })}
                    className="w-full bg-slate-800 border border-slate-700 rounded-lg px-4 py-2 text-white focus:outline-none focus:border-purple-500/50"
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-slate-400 text-sm">Last Name</label>
                  <input
                    type="text"
                    value={profileData.lastName}
                    onChange={(e) => setProfileData({ ...profileData, lastName: e.target.value })}
                    className="w-full bg-slate-800 border border-slate-700 rounded-lg px-4 py-2 text-white focus:outline-none focus:border-purple-500/50"
                  />
                </div>
              </div>

              {/* Email */}
              <div className="space-y-2">
                <label className="text-slate-400 text-sm">Email Address</label>
                <input
                  type="email"
                  value={profileData.email}
                  disabled
                  className="w-full bg-slate-800/50 border border-slate-700 rounded-lg px-4 py-2 text-slate-400 cursor-not-allowed"
                />
                <p className="text-slate-500 text-xs">Managed via your authentication provider.</p>
              </div>

              {/* Bio */}
              <div className="space-y-2">
                <label className="text-slate-400 text-sm">Bio</label>
                <textarea
                  value={profileData.bio}
                  onChange={(e) => setProfileData({ ...profileData, bio: e.target.value })}
                  className="w-full bg-slate-800 border border-slate-700 rounded-lg px-4 py-2 text-white h-24 resize-none focus:outline-none focus:border-purple-500/50"
                />
              </div>

              <Button 
                className="bg-purple-600 hover:bg-purple-700 text-white"
                onClick={handleSaveProfile}
              >
                <Check className="w-4 h-4 mr-2" />
                Save Changes
              </Button>
            </div>
          )}

          {/* Notifications Tab */}
          {activeTab === 'notifications' && (
            <div className="bg-slate-900/50 rounded-2xl p-6 border border-slate-800 space-y-6">
              <h3 className="text-white font-semibold text-lg">Notification Preferences</h3>
              
              <div className="space-y-4">
                {[
                  { key: 'email', label: 'Email Notifications', desc: 'Receive updates about your content', icon: Mail },
                  { key: 'push', label: 'Push Notifications', desc: 'Get notified about viral opportunities', icon: Bell },
                  { key: 'weekly', label: 'Weekly Digest', desc: 'Trending content in your niche', icon: Globe },
                  { key: 'newOpportunities', label: 'New Opportunities', desc: 'Alert when new viral opportunities match your niche', icon: Bell },
                  { key: 'creditAlerts', label: 'Credit Alerts', desc: 'Notify when credits are running low', icon: Bell },
                ].map((item) => (
                  <div key={item.key} className="flex items-center justify-between p-4 bg-slate-800/50 rounded-xl">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-lg bg-purple-500/20 flex items-center justify-center">
                        <item.icon className="w-5 h-5 text-purple-400" />
                      </div>
                      <div>
                        <p className="text-white font-medium">{item.label}</p>
                        <p className="text-slate-400 text-sm">{item.desc}</p>
                      </div>
                    </div>
                    <Switch
                      checked={notifications[item.key as keyof NotificationSettings]}
                      onCheckedChange={(v) => setNotifications({ ...notifications, [item.key]: v })}
                    />
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Security Tab */}
          {activeTab === 'security' && (
            <div className="bg-slate-900/50 rounded-2xl p-6 border border-slate-800 space-y-6">
              <h3 className="text-white font-semibold text-lg">Security Settings</h3>
              
              <div className="space-y-4">
                <div className="p-4 bg-slate-800/50 rounded-xl">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-white font-medium">Password</p>
                      <p className="text-slate-400 text-sm">Last changed 3 months ago</p>
                    </div>
                    <Button variant="outline" className="border-slate-700 text-slate-300">
                      Change Password
                    </Button>
                  </div>
                </div>

                <div className="p-4 bg-slate-800/50 rounded-xl">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-lg bg-green-500/20 flex items-center justify-center">
                        <Shield className="w-5 h-5 text-green-400" />
                      </div>
                      <div>
                        <p className="text-white font-medium">Two-Factor Authentication</p>
                        <p className="text-slate-400 text-sm">Add an extra layer of security</p>
                      </div>
                    </div>
                    <span className="px-2 py-1 bg-green-500/20 text-green-400 text-xs rounded-full">
                      Enabled
                    </span>
                  </div>
                </div>

                <div className="p-4 bg-slate-800/50 rounded-xl">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-lg bg-slate-700 flex items-center justify-center">
                        <Globe className="w-5 h-5 text-slate-400" />
                      </div>
                      <div>
                        <p className="text-white font-medium">Active Sessions</p>
                        <p className="text-slate-400 text-sm">2 active sessions</p>
                      </div>
                    </div>
                    <Button variant="outline" className="border-slate-700 text-slate-300">
                      Manage
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Appearance Tab */}
          {activeTab === 'appearance' && (
            <div className="bg-slate-900/50 rounded-2xl p-6 border border-slate-800 space-y-6">
              <h3 className="text-white font-semibold text-lg">Appearance</h3>
              
              <div className="flex items-center justify-between p-4 bg-slate-800/50 rounded-xl">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-purple-500/20 flex items-center justify-center">
                    {darkMode ? <Moon className="w-5 h-5 text-purple-400" /> : <Sun className="w-5 h-5 text-yellow-400" />}
                  </div>
                  <div>
                    <p className="text-white font-medium">Dark Mode</p>
                    <p className="text-slate-400 text-sm">Toggle between light and dark theme</p>
                  </div>
                </div>
                <Switch checked={darkMode} onCheckedChange={setDarkMode} />
              </div>

              <div className="space-y-3">
                <label className="text-slate-400 text-sm">Accent Color</label>
                <div className="flex gap-3">
                  {['#7C5CFF', '#FF5C5C', '#5CFF7C', '#5C9FFF', '#FF5C9F'].map((color) => (
                    <button
                      key={color}
                      className="w-10 h-10 rounded-full cursor-pointer border-2 border-transparent hover:border-white transition-all"
                      style={{ backgroundColor: color }}
                      onClick={() => console.log('Color selected:', color)}
                    />
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
