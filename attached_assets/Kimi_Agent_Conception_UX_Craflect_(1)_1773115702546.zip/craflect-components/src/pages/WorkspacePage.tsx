import React from 'react';
import { Lightbulb, FileText, Bookmark, FolderOpen, Sparkles, Download, RefreshCw } from 'lucide-react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { StatusBadge } from '@/components/StatusBadge';
import { ViralityBadge } from '@/components/ViralityBadge';
import { VideoCard } from '@/components/VideoCard';
import type { Project, VideoCard as VideoCardType } from '@/types';

interface WorkspacePageProps {
  ideas: Project[];
  scripts: Project[];
  savedVideos: VideoCardType[];
  onOpenProject: (project: Project) => void;
  onGenerateVariation: (project: Project) => void;
  onExportProject: (project: Project) => void;
}

export const WorkspacePage: React.FC<WorkspacePageProps> = ({
  ideas,
  scripts,
  savedVideos,
  onOpenProject,
  onGenerateVariation,
  onExportProject
}) => {
  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-white">Workspace</h2>
          <p className="text-slate-400">All your projects and saved content</p>
        </div>
      </div>

      {/* Tabs */}
      <Tabs defaultValue="ideas" className="w-full">
        <TabsList className="bg-slate-900/50 border border-slate-800">
          <TabsTrigger 
            value="ideas" 
            className="data-[state=active]:bg-purple-500/20 data-[state=active]:text-purple-300"
          >
            <Lightbulb className="w-4 h-4 mr-2" />
            Generated Ideas
            {ideas.length > 0 && (
              <span className="ml-2 px-1.5 py-0.5 bg-slate-700 rounded-full text-xs">
                {ideas.length}
              </span>
            )}
          </TabsTrigger>
          <TabsTrigger 
            value="scripts"
            className="data-[state=active]:bg-purple-500/20 data-[state=active]:text-purple-300"
          >
            <FileText className="w-4 h-4 mr-2" />
            Created Scripts
            {scripts.length > 0 && (
              <span className="ml-2 px-1.5 py-0.5 bg-slate-700 rounded-full text-xs">
                {scripts.length}
              </span>
            )}
          </TabsTrigger>
          <TabsTrigger 
            value="saved"
            className="data-[state=active]:bg-purple-500/20 data-[state=active]:text-purple-300"
          >
            <Bookmark className="w-4 h-4 mr-2" />
            Saved Inspirations
            {savedVideos.length > 0 && (
              <span className="ml-2 px-1.5 py-0.5 bg-slate-700 rounded-full text-xs">
                {savedVideos.length}
              </span>
            )}
          </TabsTrigger>
        </TabsList>

        {/* Generated Ideas */}
        <TabsContent value="ideas" className="mt-6">
          {ideas.length === 0 ? (
            <div className="text-center py-16">
              <div className="w-16 h-16 rounded-2xl bg-slate-800 flex items-center justify-center mx-auto mb-4">
                <Lightbulb className="w-8 h-8 text-slate-500" />
              </div>
              <h3 className="text-white font-medium mb-2">No ideas yet</h3>
              <p className="text-slate-400 text-sm mb-4">
                Start by exploring opportunities and generating ideas
              </p>
              <Button className="bg-purple-600 hover:bg-purple-700 text-white">
                <Sparkles className="w-4 h-4 mr-2" />
                Explore Opportunities
              </Button>
            </div>
          ) : (
            <div className="grid grid-cols-4 gap-4">
              {ideas.map((project) => (
                <div 
                  key={project.id} 
                  className="bg-slate-900/50 rounded-xl p-4 border border-slate-800 hover:border-purple-500/30 transition-all group"
                >
                  <StatusBadge status={project.status} />
                  <p className="text-white font-medium text-sm mt-3 line-clamp-2 mb-3">
                    {project.hook}
                  </p>
                  <div className="flex items-center justify-between mb-3">
                    <span className="text-xs text-slate-400">{project.createdAt}</span>
                    <ViralityBadge score={project.viralityScore} />
                  </div>
                  <div className="flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                    <Button 
                      size="sm" 
                      variant="outline"
                      className="flex-1 border-slate-700 text-slate-300 text-xs"
                      onClick={() => onOpenProject(project)}
                    >
                      <FolderOpen className="w-3 h-3 mr-1" />
                      Open
                    </Button>
                    <Button 
                      size="sm" 
                      className="flex-1 bg-purple-600 hover:bg-purple-700 text-white text-xs"
                      onClick={() => onGenerateVariation(project)}
                    >
                      <RefreshCw className="w-3 h-3 mr-1" />
                      Variation
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </TabsContent>

        {/* Created Scripts */}
        <TabsContent value="scripts" className="mt-6">
          {scripts.length === 0 ? (
            <div className="text-center py-16">
              <div className="w-16 h-16 rounded-2xl bg-slate-800 flex items-center justify-center mx-auto mb-4">
                <FileText className="w-8 h-8 text-slate-500" />
              </div>
              <h3 className="text-white font-medium mb-2">No scripts yet</h3>
              <p className="text-slate-400 text-sm mb-4">
                Generate your first script from an opportunity
              </p>
              <Button className="bg-purple-600 hover:bg-purple-700 text-white">
                <Sparkles className="w-4 h-4 mr-2" />
                Create Script
              </Button>
            </div>
          ) : (
            <div className="grid grid-cols-4 gap-4">
              {scripts.map((project) => (
                <div 
                  key={project.id} 
                  className="bg-slate-900/50 rounded-xl p-4 border border-slate-800 hover:border-purple-500/30 transition-all group"
                >
                  <StatusBadge status={project.status} />
                  <p className="text-white font-medium text-sm mt-3 line-clamp-2 mb-3">
                    {project.hook}
                  </p>
                  <div className="flex items-center justify-between mb-3">
                    <span className="text-xs text-slate-400">{project.createdAt}</span>
                    <ViralityBadge score={project.viralityScore} />
                  </div>
                  <div className="flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                    <Button 
                      size="sm" 
                      variant="outline"
                      className="flex-1 border-slate-700 text-slate-300 text-xs"
                      onClick={() => onOpenProject(project)}
                    >
                      <FolderOpen className="w-3 h-3 mr-1" />
                      Open
                    </Button>
                    <Button 
                      size="sm" 
                      className="flex-1 bg-purple-600 hover:bg-purple-700 text-white text-xs"
                      onClick={() => onExportProject(project)}
                    >
                      <Download className="w-3 h-3 mr-1" />
                      Export
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </TabsContent>

        {/* Saved Inspirations */}
        <TabsContent value="saved" className="mt-6">
          {savedVideos.length === 0 ? (
            <div className="text-center py-16">
              <div className="w-16 h-16 rounded-2xl bg-slate-800 flex items-center justify-center mx-auto mb-4">
                <Bookmark className="w-8 h-8 text-slate-500" />
              </div>
              <h3 className="text-white font-medium mb-2">No saved videos</h3>
              <p className="text-slate-400 text-sm mb-4">
                Save inspiring videos while browsing opportunities
              </p>
              <Button className="bg-purple-600 hover:bg-purple-700 text-white">
                <Sparkles className="w-4 h-4 mr-2" />
                Browse Opportunities
              </Button>
            </div>
          ) : (
            <div className="grid grid-cols-4 gap-4">
              {savedVideos.map((video) => (
                <VideoCard key={video.id} video={video} compact />
              ))}
            </div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
};
