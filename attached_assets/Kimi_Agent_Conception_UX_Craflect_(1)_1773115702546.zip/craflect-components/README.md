# Craflect Components — Integration Guide

## Overview

This package contains all the React components and pages for the new Craflect UX, following the approved Product Brief Final.

## What's Included

### Components
- `VideoCard` — Video cards with hover actions (Create Similar, Analyze, Save)
- `OpportunityCard` — Viral Play of the Day and compact opportunity cards
- `GuidedWorkflow` — Sticky workflow bar (Idea → Script → Blueprint → Export)
- `ViralityBadge` — Score display with color coding
- `StatusBadge` — Project status indicators
- `PaywallModal` — Upgrade prompt modal

### Pages
- `HomePage` — Creator Mode + Intelligence Mode toggle
- `OpportunitiesPage` — Grid with filters
- `StudioPage` — 5 creation modes selection
- `WorkspacePage` — Tabs for Ideas, Scripts, Saved
- `SettingsPage` — Profile, Notifications, Security, Appearance
- `BillingPage` — Plans, credits, payment methods

## Stack Compatibility

These components are built for:
- **React 18** (same as your current stack)
- **TypeScript** (same as your current stack)
- **Tailwind CSS** (same as your current stack)
- **shadcn/ui** (same as your current stack)

## Installation Steps

### 1. Copy Components

Copy the following files to your Replit project:

```
src/
├── components/
│   ├── ui/
│   │   └── Badge.tsx          # New badge component
│   ├── VideoCard.tsx
│   ├── OpportunityCard.tsx
│   ├── GuidedWorkflow.tsx
│   ├── ViralityBadge.tsx
│   ├── StatusBadge.tsx
│   └── PaywallModal.tsx
├── pages/
│   ├── HomePage.tsx
│   ├── OpportunitiesPage.tsx
│   ├── StudioPage.tsx
│   ├── WorkspacePage.tsx
│   ├── SettingsPage.tsx
│   └── BillingPage.tsx
├── types/
│   └── index.ts               # Type definitions
└── components/index.ts        # Component exports
    pages/index.ts             # Page exports
```

### 2. Update Dependencies

Ensure you have these shadcn/ui components installed:

```bash
npx shadcn add button badge avatar switch separator tabs dialog progress
```

### 3. Update Tailwind Config

Add these colors to your `tailwind.config.js`:

```javascript
module.exports = {
  theme: {
    extend: {
      colors: {
        slate: {
          950: '#020617',
          900: '#0f172a',
          800: '#1e293b',
          700: '#334155',
        },
        purple: {
          500: '#8b5cf6',
          600: '#7c3aed',
        },
        fuchsia: {
          500: '#d946ef',
          600: '#c026d3',
        }
      }
    }
  }
}
```

### 4. Integration Example

Here's how to integrate into your main App.tsx:

```tsx
import { useState } from 'react';
import { HomePage, OpportunitiesPage, StudioPage, WorkspacePage, SettingsPage, BillingPage } from './pages';
import { PaywallModal } from './components';
import type { Page, WorkflowStep, Opportunity, VideoCard } from './types';

function App() {
  const [currentPage, setCurrentPage] = useState<Page>('home');
  const [intelligenceMode, setIntelligenceMode] = useState(false);
  const [workflowStep, setWorkflowStep] = useState<WorkflowStep>('idea');
  const [showPaywall, setShowPaywall] = useState(false);

  // Mock data (replace with your API calls)
  const viralPlay = {
    id: '1',
    topic: 'AI Tools',
    hook: '5 AI tools that will save you 10 hours every week',
    format: 'Listicle',
    predictedViews: '120K - 600K',
    confidence: 87,
    trend: 'hot' as const,
    whyItWorks: 'Listicles perform 3x better...'
  };

  const trendingVideos = [/* your data */];
  const opportunities = [/* your data */];
  const projects = [/* your data */];

  const handleCreateVideo = (item: Opportunity | VideoCard) => {
    // Check if user has enough credits
    // If free plan, show paywall
    setShowPaywall(true);
  };

  const renderPage = () => {
    switch (currentPage) {
      case 'home':
        return (
          <HomePage
            intelligenceMode={intelligenceMode}
            onToggleMode={() => setIntelligenceMode(!intelligenceMode)}
            onNavigate={setCurrentPage}
            workflowStep={workflowStep}
            onWorkflowNext={() => setWorkflowStep('script')}
            viralPlay={viralPlay}
            trendingVideos={trendingVideos}
            opportunities={opportunities}
            onCreateVideo={handleCreateVideo}
            onCreateSimilar={handleCreateVideo}
            onAnalyze={(v) => console.log('Analyze', v)}
            onSave={(v) => console.log('Save', v)}
          />
        );
      case 'opportunities':
        return (
          <OpportunitiesPage
            videos={trendingVideos}
            onCreateSimilar={handleCreateVideo}
            onAnalyze={(v) => console.log('Analyze', v)}
            onSave={(v) => console.log('Save', v)}
          />
        );
      case 'studio':
        return (
          <StudioPage
            onBack={() => setCurrentPage('home')}
            onSelectMode={(mode) => console.log('Selected mode:', mode)}
            recentProjects={projects}
          />
        );
      case 'workspace':
        return (
          <WorkspacePage
            ideas={projects.filter(p => p.status === 'idea')}
            scripts={projects.filter(p => p.status === 'script' || p.status === 'blueprint')}
            savedVideos={[]}
            onOpenProject={(p) => console.log('Open', p)}
            onGenerateVariation={(p) => console.log('Variation', p)}
            onExportProject={(p) => console.log('Export', p)}
          />
        );
      case 'settings':
        return (
          <SettingsPage
            user={{
              firstName: 'John',
              lastName: 'Doe',
              email: 'john@example.com',
              bio: 'Content creator focused on AI and productivity tips.'
            }}
            onSaveProfile={(data) => console.log('Save', data)}
            onSignOut={() => console.log('Sign out')}
          />
        );
      case 'billing':
        return (
          <BillingPage
            currentPlan={{
              name: 'Creator',
              price: 24,
              period: 'month',
              credits: 250,
              maxRollover: 500,
              features: ['Export enabled', 'Templates', 'AI Avatar'],
              cta: 'Current Plan',
              current: true,
              popular: true
            }}
            creditsUsed={47}
            creditsTotal={250}
            plans={[/* your plans */]}
            creditHistory={[/* your history */]}
            onUpgrade={(plan) => console.log('Upgrade to', plan.name)}
            onManageSubscription={() => console.log('Manage')}
          />
        );
      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-200">
      {/* Your sidebar */}
      <Sidebar currentPage={currentPage} onNavigate={setCurrentPage} />
      
      {/* Main content */}
      <main className="ml-64">
        <Header 
          currentPage={currentPage}
          intelligenceMode={intelligenceMode}
          onToggleMode={() => setIntelligenceMode(!intelligenceMode)}
        />
        <div className="p-8 pb-32">
          {renderPage()}
        </div>
      </main>

      {/* Paywall Modal */}
      <PaywallModal
        isOpen={showPaywall}
        onClose={() => setShowPaywall(false)}
        feature="Export Video"
        currentPlan="Free"
        plans={upgradePlans}
        onUpgrade={(plan) => {
          console.log('Upgrade to', plan.name);
          setShowPaywall(false);
        }}
      />
    </div>
  );
}
```

## Key Features Implemented

### ✅ Navigation Simplifiée
- 5 items principaux : Home, Opportunities, Create, Workspace, Insights
- 3 items secondaires : Settings, Plan & Billing, Help

### ✅ 2 Couches (Creator / Intelligence)
- Toggle dans le header de la Home
- Creator Mode : Viral Play, Trending, Opportunities
- Intelligence Mode : Analytics, Patterns, Trends

### ✅ Viral Play of the Day
- Hook, Format, Predicted Views, Confidence
- "Why it works" explanation
- Actions : Create This Video, See Similar

### ✅ Hover Actions sur Vidéos
- Create Similar (génère hook + script + blueprint)
- Analyze (ouvre analytics)
- Save (ajoute aux favoris)

### ✅ Guided Workflow
- Barre sticky en bas
- 4 étapes : Idea → Script → Blueprint → Export
- CTA "Next: [Action]" clair

### ✅ Studio Creation
- 5 modes : Opportunity, Script-to-Video, Templates, AI Avatar, Video Remix
- Video Remix marqué "Pro / Coming Soon"
- Recent Projects affichés

### ✅ AI Credits System
- Coûts affichés dans Billing
- Generate Idea = 1 credit
- Generate Script = 1 credit
- Generate Blueprint = 1 credit
- AI Avatar = 3 credits

### ✅ Paywall
- Apparaît avant Export
- Free = preview uniquement
- Creator = export enabled

### ✅ Credit Rollover
- Max 2 mois
- Affiché dans les plans

## Pricing Structure (from brief)

| Plan | Monthly | Yearly | Credits | Rollover |
|------|---------|--------|---------|----------|
| Free | $0 | - | 30 | 0 |
| Creator | $24 | $19 | 250 | 500 |
| Pro/Agency | $109 | $99 | 1500 | 3000 |

## Next Steps

1. **Copy components** to your Replit project
2. **Install shadcn dependencies**
3. **Update your App.tsx** with the new page structure
4. **Connect to your API** for real data
5. **Test the workflow** end-to-end

## Questions?

Refer to the Product Brief Final for detailed specifications.
