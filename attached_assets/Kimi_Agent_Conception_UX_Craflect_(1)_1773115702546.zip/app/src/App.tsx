import { useState } from 'react';
import { 
  Sparkles, 
  TrendingUp, 
  Zap, 
  Video, 
  FileText, 
  Layers, 
  Download,
  ChevronRight,
  BarChart3,
  Eye,
  Flame,
  ArrowRight,
  Home,
  Compass,
  PlusCircle,
  FolderOpen,
  Settings,
  CreditCard,
  Lightbulb,
  Target,
  Hash,
  CheckCircle2,
  Upload,
  Film,
  Palette,
  ChevronLeft,
  Bookmark,
  User,
  Bell,
  Shield,
  Globe,
  Moon,
  Sun,
  LogOut,
  Check,
  Activity,
  PieChart,
  LineChart,
  ExternalLink
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Switch } from '@/components/ui/switch';
import { Progress } from '@/components/ui/progress';
import { Separator } from '@/components/ui/separator';

// Types
type Page = 'home' | 'opportunities' | 'studio' | 'workspace' | 'insights' | 'settings' | 'billing';
type SettingsTab = 'profile' | 'notifications' | 'security' | 'appearance';

// Mock Data
const viralPlayOfTheDay = {
  id: '1',
  topic: 'AI Tools',
  hook: '5 AI tools that will save you 10 hours every week',
  format: 'Listicle',
  predictedViews: '120K - 600K',
  confidence: 87,
  trend: 'hot' as const,
  whyItWorks: 'Listicles perform 3x better in the productivity niche. The specific number (5) creates curiosity, and the time-saving promise (10 hours) provides a clear benefit.'
};

const trendingVideos = [
  { id: '1', thumbnail: 'gradient-1', hook: 'I tested every AI writing tool so you don\'t have to', views: '2.4M', format: 'Review', viralityScore: 94, platform: 'tiktok' as const, creator: '@contentguru' },
  { id: '2', thumbnail: 'gradient-2', hook: 'The one mistake killing your engagement', views: '890K', format: 'Storytelling', viralityScore: 88, platform: 'reels' as const, creator: '@viralqueen' },
  { id: '3', thumbnail: 'gradient-3', hook: 'Stop doing this in your hooks (seriously)', views: '1.2M', format: 'Educational', viralityScore: 91, platform: 'shorts' as const, creator: '@growthlab' },
  { id: '4', thumbnail: 'gradient-4', hook: 'This format got me 1M views in 3 days', views: '3.1M', format: 'Case Study', viralityScore: 96, platform: 'tiktok' as const, creator: '@viralpro' },
];

const opportunities = [
  { id: '2', topic: 'Productivity Hacks', hook: 'The 2-minute rule that changed my life', format: 'Story + Lesson', predictedViews: '80K - 350K', confidence: 82, trend: 'rising' as const },
  { id: '3', topic: 'Content Strategy', hook: 'Why your content isn\'t going viral (the real reason)', format: 'Myth Busting', predictedViews: '150K - 500K', confidence: 79, trend: 'stable' as const },
];

const projects = [
  { id: '1', title: 'AI Tools Video', hook: '5 AI tools that will save you 10 hours every week', format: 'Listicle', status: 'blueprint' as const, createdAt: '2 hours ago', viralityScore: 87 },
  { id: '2', title: 'Engagement Tips', hook: 'The one mistake killing your engagement', format: 'Educational', status: 'script' as const, createdAt: '1 day ago', viralityScore: 88 },
  { id: '3', title: 'Viral Hooks', hook: 'Stop doing this in your hooks', format: 'Storytelling', status: 'idea' as const, createdAt: '3 days ago', viralityScore: 91 },
];

const plans = [
  { name: 'Free', price: 0, period: 'month', credits: 40, features: ['Viral Play of the Day', 'Trending videos', 'Basic templates', 'Script generation'], cta: 'Current Plan', current: false },
  { name: 'Creator', price: 29, period: 'month', credits: 1000, features: ['Everything in Free', 'AI Avatar generation', 'Viral Templates library', 'Video Blueprint export', 'Priority support'], cta: 'Upgrade', current: true, popular: true },
  { name: 'Studio', price: 69, period: 'month', credits: 3000, features: ['Everything in Creator', 'Video Remix (AI)', 'Advanced analytics', 'Team collaboration', 'API access'], cta: 'Upgrade', current: false },
];

const creditHistory = [
  { action: 'Generate Script', cost: 2, date: 'Today, 2:34 PM', project: 'AI Tools Video' },
  { action: 'Generate Blueprint', cost: 3, date: 'Today, 2:36 PM', project: 'AI Tools Video' },
  { action: 'Generate Script', cost: 2, date: 'Yesterday, 10:15 AM', project: 'Engagement Tips' },
  { action: 'Monthly refill', cost: -1000, date: 'Mar 1, 2026', project: 'Subscription' },
];

// Components
const SidebarItem = ({ icon: Icon, label, active, badge, onClick }: { icon: any, label: string, active?: boolean, badge?: string, onClick?: () => void }) => (
  <div 
    onClick={onClick}
    className={`flex items-center gap-3 px-4 py-3 rounded-xl cursor-pointer transition-all ${active ? 'bg-purple-500/20 text-purple-300 border border-purple-500/30' : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'}`}
  >
    <Icon className="w-5 h-5" />
    <span className="text-sm font-medium">{label}</span>
    {badge && (
      <Badge className="ml-auto bg-purple-500/20 text-purple-300 text-xs">{badge}</Badge>
    )}
  </div>
);

const ViralityBadge = ({ score }: { score: number }) => {
  const color = score >= 90 ? 'bg-red-500/20 text-red-400 border-red-500/30' : 
                 score >= 80 ? 'bg-orange-500/20 text-orange-400 border-orange-500/30' : 
                 score >= 60 ? 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30' :
                 'bg-slate-500/20 text-slate-400 border-slate-500/30';
  return <Badge className={`${color} border text-xs font-semibold`}><Flame className="w-3 h-3 mr-1" />{score}</Badge>;
};

const StatusBadge = ({ status }: { status: 'idea' | 'script' | 'blueprint' | 'completed' }) => {
  const colors = { idea: 'bg-slate-500/20 text-slate-400', script: 'bg-blue-500/20 text-blue-400', blueprint: 'bg-purple-500/20 text-purple-400', completed: 'bg-green-500/20 text-green-400' };
  const labels = { idea: 'Idea', script: 'Script', blueprint: 'Blueprint', completed: 'Ready' };
  return <Badge className={`${colors[status]} text-xs`}>{labels[status]}</Badge>;
};

// Video Card Component
const VideoCard = ({ video, compact = false }: { video: any, compact?: boolean }) => {
  const [isHovered, setIsHovered] = useState(false);
  const gradients: Record<string, string> = {
    'gradient-1': 'from-violet-600 via-purple-600 to-fuchsia-600',
    'gradient-2': 'from-blue-600 via-cyan-600 to-teal-600',
    'gradient-3': 'from-orange-600 via-amber-600 to-yellow-600',
    'gradient-4': 'from-rose-600 via-pink-600 to-purple-600',
  };
  
  if (compact) {
    return (
      <div className="group relative bg-slate-900/50 rounded-xl overflow-hidden border border-slate-800 hover:border-purple-500/50 transition-all">
        <div className={`relative aspect-[9/16] bg-gradient-to-br ${gradients[video.thumbnail]} overflow-hidden`}>
          <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />
          <div className="absolute top-2 left-2">
            <Badge className="bg-black/60 backdrop-blur-sm text-white border-0 text-[10px]">{video.platform}</Badge>
          </div>
          <div className="absolute top-2 right-2">
            <ViralityBadge score={video.viralityScore} />
          </div>
          <div className="absolute bottom-0 left-0 right-0 p-3">
            <p className="text-white font-medium text-xs line-clamp-2">{video.hook}</p>
          </div>
        </div>
      </div>
    );
  }
  
  return (
    <div 
      className="group relative bg-slate-900/50 rounded-2xl overflow-hidden border border-slate-800 hover:border-purple-500/50 transition-all duration-300 hover:scale-[1.02]"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      <div className={`relative aspect-[9/16] bg-gradient-to-br ${gradients[video.thumbnail]} overflow-hidden`}>
        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />
        <div className="absolute top-3 left-3">
          <Badge className="bg-black/60 backdrop-blur-sm text-white border-0 text-xs capitalize">{video.platform}</Badge>
        </div>
        <div className="absolute top-3 right-3">
          <ViralityBadge score={video.viralityScore} />
        </div>
        <div className={`absolute inset-0 flex items-center justify-center transition-opacity duration-300 ${isHovered ? 'opacity-100' : 'opacity-0'}`}>
          <div className="flex flex-col gap-2">
            <Button size="sm" className="bg-purple-600 hover:bg-purple-700 text-white">
              <Sparkles className="w-4 h-4 mr-2" />Create Similar
            </Button>
            <Button size="sm" variant="outline" className="border-white/30 text-white hover:bg-white/20">
              <BarChart3 className="w-4 h-4 mr-2" />Analyze
            </Button>
            <Button size="sm" variant="outline" className="border-white/30 text-white hover:bg-white/20">
              <Bookmark className="w-4 h-4 mr-2" />Save
            </Button>
          </div>
        </div>
        <div className="absolute bottom-0 left-0 right-0 p-4">
          <p className="text-white font-semibold text-sm line-clamp-2 leading-tight">{video.hook}</p>
        </div>
      </div>
      <div className="p-4">
        <div className="flex items-center justify-between mb-2">
          <span className="text-xs text-slate-400">{video.format}</span>
          <div className="flex items-center gap-1 text-xs text-slate-400">
            <Eye className="w-3 h-3" />{video.views}
          </div>
        </div>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Avatar className="w-6 h-6">
              <AvatarFallback className="bg-slate-700 text-xs">{video.creator[1].toUpperCase()}</AvatarFallback>
            </Avatar>
            <span className="text-xs text-slate-400">{video.creator}</span>
          </div>
        </div>
      </div>
    </div>
  );
};

// Trend colors mapping
const trendColors: Record<string, string> = { hot: 'text-red-400 bg-red-500/20', rising: 'text-orange-400 bg-orange-500/20', stable: 'text-green-400 bg-green-500/20' };

// Opportunity Card
const OpportunityCard = ({ opportunity, featured = false }: { opportunity: any, featured?: boolean }) => {
  
  if (featured) {
    return (
      <div className="relative bg-gradient-to-br from-purple-900/50 via-slate-900/50 to-slate-900/50 rounded-3xl p-8 border border-purple-500/30 overflow-hidden">
        <div className="absolute top-0 right-0 w-96 h-96 bg-purple-500/20 rounded-full blur-3xl -translate-y-1/2 translate-x-1/2" />
        <div className="absolute bottom-0 left-0 w-64 h-64 bg-fuchsia-500/10 rounded-full blur-3xl translate-y-1/2 -translate-x-1/2" />
        <div className="relative z-10">
          <div className="flex items-center gap-3 mb-6">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-purple-500 to-fuchsia-500 flex items-center justify-center">
              <Flame className="w-6 h-6 text-white" />
            </div>
            <div>
              <Badge className="bg-purple-500/20 text-purple-300 border-purple-500/30 mb-1">
                <Sparkles className="w-3 h-3 mr-1" />VIRAL PLAY OF THE DAY
              </Badge>
              <p className="text-slate-400 text-sm">Based on 50,000+ analyzed videos</p>
            </div>
          </div>
          <div className="mb-6">
            <div className="flex items-center gap-2 mb-3">
              <Badge className="bg-slate-800 text-slate-300">{opportunity.topic}</Badge>
              <Badge className={trendColors[opportunity.trend]}>
                <TrendingUp className="w-3 h-3 mr-1" />
                {opportunity.trend === 'hot' ? 'TRENDING NOW' : opportunity.trend === 'rising' ? 'RISING' : 'STABLE'}
              </Badge>
            </div>
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-4 leading-tight">"{opportunity.hook}"</h2>
            <div className="flex flex-wrap items-center gap-6 text-sm mb-4">
              <div className="flex items-center gap-2 text-slate-400">
                <Video className="w-4 h-4" />Format: <span className="text-white font-medium">{opportunity.format}</span>
              </div>
              <div className="flex items-center gap-2 text-slate-400">
                <Eye className="w-4 h-4" />Predicted: <span className="text-green-400 font-medium">{opportunity.predictedViews}</span>
              </div>
              <div className="flex items-center gap-2 text-slate-400">
                <Target className="w-4 h-4" />Confidence: <span className="text-purple-400 font-medium">{opportunity.confidence}%</span>
              </div>
            </div>
            <div className="bg-slate-900/50 rounded-xl p-4 border border-slate-800">
              <p className="text-slate-400 text-sm"><span className="text-purple-400 font-medium">Why it works:</span> {opportunity.whyItWorks}</p>
            </div>
          </div>
          <div className="flex items-center gap-4">
            <Button size="lg" className="bg-gradient-to-r from-purple-600 to-fuchsia-600 hover:from-purple-700 hover:to-fuchsia-700 text-white px-8 h-14 text-lg font-semibold rounded-xl shadow-lg shadow-purple-500/25">
              <Sparkles className="w-5 h-5 mr-2" />Create This Video<ArrowRight className="w-5 h-5 ml-2" />
            </Button>
            <Button variant="outline" size="lg" className="border-slate-700 text-slate-300 hover:bg-slate-800 h-14 px-6 rounded-xl">See Similar</Button>
          </div>
        </div>
      </div>
    );
  }
  
  return (
    <div className="bg-slate-900/50 rounded-2xl p-5 border border-slate-800 hover:border-purple-500/30 transition-all cursor-pointer group">
      <div className="flex items-start justify-between mb-3">
        <Badge className="bg-slate-800 text-slate-300">{opportunity.topic}</Badge>
        <Badge className={trendColors[opportunity.trend]}>
          <TrendingUp className="w-3 h-3 mr-1" />{opportunity.confidence}%
        </Badge>
      </div>
      <p className="text-white font-medium mb-4 line-clamp-2">"{opportunity.hook}"</p>
      <div className="flex items-center justify-between text-sm">
        <div className="flex items-center gap-4 text-slate-400">
          <span className="flex items-center gap-1"><Video className="w-4 h-4" />{opportunity.format}</span>
          <span className="flex items-center gap-1 text-green-400"><Eye className="w-4 h-4" />{opportunity.predictedViews}</span>
        </div>
        <Button size="sm" className="bg-purple-600/0 hover:bg-purple-600 text-purple-400 hover:text-white transition-all opacity-0 group-hover:opacity-100">
          <Sparkles className="w-4 h-4 mr-1" />Create
        </Button>
      </div>
    </div>
  );
};

// Guided Workflow Bar
const GuidedWorkflow = ({ currentStep }: { currentStep: number }) => {
  const steps = [
    { id: 1, label: 'Idea', icon: Lightbulb, description: 'Find viral opportunity' },
    { id: 2, label: 'Script', icon: FileText, description: 'Generate script' },
    { id: 3, label: 'Blueprint', icon: Layers, description: 'Plan your video' },
    { id: 4, label: 'Export', icon: Download, description: 'Ready to publish' },
  ];

  const getNextAction = () => {
    if (currentStep === 1) return 'Generate Script';
    if (currentStep === 2) return 'Generate Blueprint';
    if (currentStep === 3) return 'Export Video';
    return 'Create Another';
  };

  return (
    <div className="bg-slate-900/90 backdrop-blur-xl border-t border-slate-800 p-4">
      <div className="max-w-6xl mx-auto">
        <div className="flex items-center justify-between">
          <div className="flex items-center flex-1">
            {steps.map((step, index) => {
              const Icon = step.icon;
              const isActive = step.id === currentStep;
              const isCompleted = step.id < currentStep;
              
              return (
                <div key={step.id} className="flex items-center flex-1">
                  <div className={`flex items-center gap-3 px-4 py-3 rounded-xl transition-all ${
                    isActive ? 'bg-purple-500/20 text-purple-300' : 
                    isCompleted ? 'bg-green-500/20 text-green-400' : 
                    'text-slate-500'
                  }`}>
                    <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${
                      isActive ? 'bg-purple-500 text-white' : 
                      isCompleted ? 'bg-green-500 text-white' : 
                      'bg-slate-800'
                    }`}>
                      {isCompleted ? <CheckCircle2 className="w-5 h-5" /> : <Icon className="w-5 h-5" />}
                    </div>
                    <div>
                      <p className="font-medium text-sm">{step.label}</p>
                      <p className="text-xs opacity-70">{step.description}</p>
                    </div>
                  </div>
                  {index < steps.length - 1 && (
                    <div className={`w-8 h-0.5 mx-2 ${isCompleted ? 'bg-green-500/50' : 'bg-slate-800'}`} />
                  )}
                </div>
              );
            })}
          </div>
          <Button className="bg-purple-600 hover:bg-purple-700 text-white ml-4">
            Next: {getNextAction()}
            <ChevronRight className="w-4 h-4 ml-1" />
          </Button>
        </div>
      </div>
    </div>
  );
};

// Settings Page
const SettingsPage = () => {
  const [activeTab, setActiveTab] = useState<SettingsTab>('profile');
  const [darkMode, setDarkMode] = useState(true);
  const [notifications, setNotifications] = useState({ email: true, push: false, weekly: true });

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-white">Settings</h2>
        <p className="text-slate-400">Manage your account and platform preferences</p>
      </div>

      <div className="grid grid-cols-4 gap-6">
        {/* Sidebar Tabs */}
        <div className="space-y-2">
          <div 
            onClick={() => setActiveTab('profile')}
            className={`flex items-center gap-3 px-4 py-3 rounded-xl cursor-pointer transition-all ${activeTab === 'profile' ? 'bg-purple-500/20 text-purple-300 border border-purple-500/30' : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'}`}
          >
            <User className="w-5 h-5" />
            <span className="text-sm font-medium">Profile</span>
          </div>
          <div 
            onClick={() => setActiveTab('notifications')}
            className={`flex items-center gap-3 px-4 py-3 rounded-xl cursor-pointer transition-all ${activeTab === 'notifications' ? 'bg-purple-500/20 text-purple-300 border border-purple-500/30' : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'}`}
          >
            <Bell className="w-5 h-5" />
            <span className="text-sm font-medium">Notifications</span>
          </div>
          <div 
            onClick={() => setActiveTab('security')}
            className={`flex items-center gap-3 px-4 py-3 rounded-xl cursor-pointer transition-all ${activeTab === 'security' ? 'bg-purple-500/20 text-purple-300 border border-purple-500/30' : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'}`}
          >
            <Shield className="w-5 h-5" />
            <span className="text-sm font-medium">Security</span>
          </div>
          <div 
            onClick={() => setActiveTab('appearance')}
            className={`flex items-center gap-3 px-4 py-3 rounded-xl cursor-pointer transition-all ${activeTab === 'appearance' ? 'bg-purple-500/20 text-purple-300 border border-purple-500/30' : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'}`}
          >
            <Palette className="w-5 h-5" />
            <span className="text-sm font-medium">Appearance</span>
          </div>
          <Separator className="my-4 bg-slate-800" />
          <div className="flex items-center gap-3 px-4 py-3 rounded-xl cursor-pointer text-red-400 hover:bg-red-500/10 transition-all">
            <LogOut className="w-5 h-5" />
            <span className="text-sm font-medium">Sign Out</span>
          </div>
        </div>

        {/* Content */}
        <div className="col-span-3">
          {activeTab === 'profile' && (
            <div className="bg-slate-900/50 rounded-2xl p-6 border border-slate-800 space-y-6">
              <h3 className="text-white font-semibold text-lg">Profile Information</h3>
              
              <div className="flex items-center gap-6">
                <Avatar className="w-20 h-20">
                  <AvatarFallback className="bg-gradient-to-br from-purple-500 to-fuchsia-500 text-white text-2xl">JD</AvatarFallback>
                </Avatar>
                <div>
                  <Button variant="outline" className="border-slate-700 text-slate-300 mb-2">
                    <Upload className="w-4 h-4 mr-2" />Change Avatar
                  </Button>
                  <p className="text-slate-500 text-sm">JPG, GIF or PNG. 1MB max.</p>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-slate-400 text-sm">First Name</label>
                  <input type="text" defaultValue="John" className="w-full bg-slate-800 border border-slate-700 rounded-lg px-4 py-2 text-white focus:outline-none focus:border-purple-500/50" />
                </div>
                <div className="space-y-2">
                  <label className="text-slate-400 text-sm">Last Name</label>
                  <input type="text" defaultValue="Doe" className="w-full bg-slate-800 border border-slate-700 rounded-lg px-4 py-2 text-white focus:outline-none focus:border-purple-500/50" />
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-slate-400 text-sm">Email Address</label>
                <input type="email" defaultValue="john@example.com" disabled className="w-full bg-slate-800/50 border border-slate-700 rounded-lg px-4 py-2 text-slate-400 cursor-not-allowed" />
                <p className="text-slate-500 text-xs">Managed via your authentication provider.</p>
              </div>

              <div className="space-y-2">
                <label className="text-slate-400 text-sm">Bio</label>
                <textarea defaultValue="Content creator focused on AI and productivity tips." className="w-full bg-slate-800 border border-slate-700 rounded-lg px-4 py-2 text-white h-24 resize-none focus:outline-none focus:border-purple-500/50" />
              </div>

              <Button className="bg-purple-600 hover:bg-purple-700 text-white">
                <Check className="w-4 h-4 mr-2" />Save Changes
              </Button>
            </div>
          )}

          {activeTab === 'notifications' && (
            <div className="bg-slate-900/50 rounded-2xl p-6 border border-slate-800 space-y-6">
              <h3 className="text-white font-semibold text-lg">Notification Preferences</h3>
              
              <div className="space-y-4">
                <div className="flex items-center justify-between p-4 bg-slate-800/50 rounded-xl">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-lg bg-purple-500/20 flex items-center justify-center">
                      <MailIcon className="w-5 h-5 text-purple-400" />
                    </div>
                    <div>
                      <p className="text-white font-medium">Email Notifications</p>
                      <p className="text-slate-400 text-sm">Receive updates about your content</p>
                    </div>
                  </div>
                  <Switch checked={notifications.email} onCheckedChange={(v) => setNotifications({...notifications, email: v})} />
                </div>

                <div className="flex items-center justify-between p-4 bg-slate-800/50 rounded-xl">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-lg bg-blue-500/20 flex items-center justify-center">
                      <Bell className="w-5 h-5 text-blue-400" />
                    </div>
                    <div>
                      <p className="text-white font-medium">Push Notifications</p>
                      <p className="text-slate-400 text-sm">Get notified about viral opportunities</p>
                    </div>
                  </div>
                  <Switch checked={notifications.push} onCheckedChange={(v) => setNotifications({...notifications, push: v})} />
                </div>

                <div className="flex items-center justify-between p-4 bg-slate-800/50 rounded-xl">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-lg bg-green-500/20 flex items-center justify-center">
                      <TrendingUp className="w-5 h-5 text-green-400" />
                    </div>
                    <div>
                      <p className="text-white font-medium">Weekly Digest</p>
                      <p className="text-slate-400 text-sm">Trending content in your niche</p>
                    </div>
                  </div>
                  <Switch checked={notifications.weekly} onCheckedChange={(v) => setNotifications({...notifications, weekly: v})} />
                </div>
              </div>
            </div>
          )}

          {activeTab === 'security' && (
            <div className="bg-slate-900/50 rounded-2xl p-6 border border-slate-800 space-y-6">
              <h3 className="text-white font-semibold text-lg">Security Settings</h3>
              
              <div className="space-y-4">
                <div className="p-4 bg-slate-800/50 rounded-xl">
                  <div className="flex items-center justify-between mb-4">
                    <div>
                      <p className="text-white font-medium">Password</p>
                      <p className="text-slate-400 text-sm">Last changed 3 months ago</p>
                    </div>
                    <Button variant="outline" className="border-slate-700 text-slate-300">Change Password</Button>
                  </div>
                </div>

                <div className="p-4 bg-slate-800/50 rounded-xl">
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-lg bg-green-500/20 flex items-center justify-center">
                        <Shield className="w-5 h-5 text-green-400" />
                      </div>
                      <div>
                        <p className="text-white font-medium">Two-Factor Authentication</p>
                        <p className="text-slate-400 text-sm">Add an extra layer of security</p>
                      </div>
                    </div>
                    <Badge className="bg-green-500/20 text-green-400">Enabled</Badge>
                  </div>
                </div>

                <div className="p-4 bg-slate-800/50 rounded-xl">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-lg bg-slate-700 flex items-center justify-center">
                        <Globe className="w-5 h-5 text-slate-400" />
                      </div>
                      <div>
                        <p className="text-white font-medium">Active Sessions</p>
                        <p className="text-slate-400 text-sm">2 active sessions</p>
                      </div>
                    </div>
                    <Button variant="outline" className="border-slate-700 text-slate-300">Manage</Button>
                  </div>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'appearance' && (
            <div className="bg-slate-900/50 rounded-2xl p-6 border border-slate-800 space-y-6">
              <h3 className="text-white font-semibold text-lg">Appearance</h3>
              
              <div className="flex items-center justify-between p-4 bg-slate-800/50 rounded-xl">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-purple-500/20 flex items-center justify-center">
                    {darkMode ? <Moon className="w-5 h-5 text-purple-400" /> : <Sun className="w-5 h-5 text-yellow-400" />}
                  </div>
                  <div>
                    <p className="text-white font-medium">Dark Mode</p>
                    <p className="text-slate-400 text-sm">Toggle between light and dark theme</p>
                  </div>
                </div>
                <Switch checked={darkMode} onCheckedChange={setDarkMode} />
              </div>

              <div className="space-y-3">
                <label className="text-slate-400 text-sm">Accent Color</label>
                <div className="flex gap-3">
                  {['#7C5CFF', '#FF5C5C', '#5CFF7C', '#5C9FFF', '#FF5C9F'].map((color) => (
                    <div 
                      key={color}
                      className="w-10 h-10 rounded-full cursor-pointer border-2 border-transparent hover:border-white transition-all"
                      style={{ backgroundColor: color }}
                    />
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

// Billing Page
const BillingPage = () => {
  const creditsUsed = 247;
  const creditsTotal = 1000;
  const creditsPercent = (creditsUsed / creditsTotal) * 100;

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-white">Plan & Billing</h2>
        <p className="text-slate-400">Manage your subscription and AI credits</p>
      </div>

      {/* Current Plan & Credits */}
      <div className="grid grid-cols-3 gap-6">
        {/* Current Plan */}
        <div className="bg-slate-900/50 rounded-2xl p-6 border border-slate-800">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <CreditCard className="w-5 h-5 text-purple-400" />
              <span className="text-slate-400">Current Plan</span>
            </div>
            <Badge className="bg-purple-500/20 text-purple-300">Creator</Badge>
          </div>
          <p className="text-3xl font-bold text-white mb-1">€29<span className="text-lg text-slate-400">/month</span></p>
          <p className="text-slate-400 text-sm mb-4">Renews on Apr 10, 2026</p>
          <Button variant="outline" className="w-full border-slate-700 text-slate-300">
            <ExternalLink className="w-4 h-4 mr-2" />Manage Subscription
          </Button>
        </div>

        {/* AI Credits */}
        <div className="bg-slate-900/50 rounded-2xl p-6 border border-slate-800">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <Zap className="w-5 h-5 text-yellow-400" />
              <span className="text-slate-400">AI Credits</span>
            </div>
            <Badge className="bg-yellow-500/20 text-yellow-400">{creditsTotal - creditsUsed} left</Badge>
          </div>
          <div className="flex items-end gap-2 mb-2">
            <span className="text-3xl font-bold text-white">{creditsUsed}</span>
            <span className="text-lg text-slate-400">/ {creditsTotal}</span>
          </div>
          <p className="text-slate-400 text-sm mb-4">{creditsTotal - creditsUsed} credits remaining this month</p>
          <Progress value={creditsPercent} className="h-2" />
        </div>

        {/* Usage Stats */}
        <div className="bg-slate-900/50 rounded-2xl p-6 border border-slate-800">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <BarChart3 className="w-5 h-5 text-green-400" />
              <span className="text-slate-400">This Month</span>
            </div>
          </div>
          <div className="space-y-3">
            <div className="flex justify-between text-sm">
              <span className="text-slate-400">Scripts Generated</span>
              <span className="text-white">24</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-slate-400">Blueprints Created</span>
              <span className="text-white">18</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-slate-400">Videos Exported</span>
              <span className="text-white">12</span>
            </div>
          </div>
        </div>
      </div>

      {/* Credit Cost Reference */}
      <div className="bg-slate-900/50 rounded-2xl p-6 border border-slate-800">
        <h3 className="text-white font-semibold mb-4">AI Credit Costs</h3>
        <div className="grid grid-cols-4 gap-4">
          {[
            { action: 'Generate Idea', cost: 2, icon: Lightbulb },
            { action: 'Generate Script', cost: 2, icon: FileText },
            { action: 'Generate Blueprint', cost: 3, icon: Layers },
            { action: 'AI Avatar', cost: 5, icon: User },
          ].map((item, i) => (
            <div key={i} className="flex items-center gap-3 p-4 bg-slate-800/50 rounded-xl">
              <div className="w-10 h-10 rounded-lg bg-purple-500/20 flex items-center justify-center">
                <item.icon className="w-5 h-5 text-purple-400" />
              </div>
              <div>
                <p className="text-white text-sm">{item.action}</p>
                <p className="text-yellow-400 text-sm font-medium">{item.cost} credits</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Plans Comparison */}
      <div>
        <h3 className="text-white font-semibold mb-4">Compare Plans</h3>
        <div className="grid grid-cols-3 gap-6">
          {plans.map((plan) => (
            <div key={plan.name} className={`bg-slate-900/50 rounded-2xl p-6 border ${plan.current ? 'border-purple-500/50' : 'border-slate-800'}`}>
              <div className="flex items-center justify-between mb-2">
                <h4 className="text-white font-semibold">{plan.name}</h4>
                {plan.current && <Badge className="bg-purple-500/20 text-purple-300">Current</Badge>}
                {plan.popular && <Badge className="bg-green-500/20 text-green-400">Popular</Badge>}
              </div>
              <p className="text-3xl font-bold text-white mb-1">€{plan.price}<span className="text-lg text-slate-400">/{plan.period}</span></p>
              <p className="text-slate-400 text-sm mb-4">{plan.credits.toLocaleString()} AI credits</p>
              <ul className="space-y-2 mb-6">
                {plan.features.map((feature, i) => (
                  <li key={i} className="flex items-center gap-2 text-sm text-slate-300">
                    <Check className="w-4 h-4 text-green-400" />{feature}
                  </li>
                ))}
              </ul>
              <Button 
                className={`w-full ${plan.current ? 'bg-slate-800 text-slate-400 cursor-not-allowed' : 'bg-purple-600 hover:bg-purple-700 text-white'}`}
                disabled={plan.current}
              >
                {plan.cta}
              </Button>
            </div>
          ))}
        </div>
      </div>

      {/* Credit History */}
      <div className="bg-slate-900/50 rounded-2xl p-6 border border-slate-800">
        <h3 className="text-white font-semibold mb-4">Credit History</h3>
        <div className="space-y-3">
          {creditHistory.map((item, i) => (
            <div key={i} className="flex items-center justify-between p-4 bg-slate-800/50 rounded-xl">
              <div className="flex items-center gap-4">
                <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${item.cost < 0 ? 'bg-green-500/20' : 'bg-purple-500/20'}`}>
                  {item.cost < 0 ? <Zap className="w-5 h-5 text-green-400" /> : <Sparkles className="w-5 h-5 text-purple-400" />}
                </div>
                <div>
                  <p className="text-white text-sm">{item.action}</p>
                  <p className="text-slate-400 text-xs">{item.project} • {item.date}</p>
                </div>
              </div>
              <span className={`font-medium ${item.cost < 0 ? 'text-green-400' : 'text-slate-300'}`}>
                {item.cost < 0 ? '+' : '-'}{Math.abs(item.cost)} credits
              </span>
            </div>
          ))}
        </div>
      </div>

      {/* Payment Methods */}
      <div className="bg-slate-900/50 rounded-2xl p-6 border border-slate-800">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-white font-semibold">Payment Methods</h3>
          <Button variant="outline" className="border-slate-700 text-slate-300">
            <PlusCircle className="w-4 h-4 mr-2" />Add Card
          </Button>
        </div>
        <div className="p-4 bg-slate-800/50 rounded-xl flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="w-12 h-8 bg-gradient-to-r from-purple-500 to-fuchsia-500 rounded flex items-center justify-center">
              <CreditCard className="w-6 h-4 text-white" />
            </div>
            <div>
              <p className="text-white text-sm">•••• 4242</p>
              <p className="text-slate-400 text-xs">Expires 12/27</p>
            </div>
          </div>
          <Badge className="bg-green-500/20 text-green-400">Default</Badge>
        </div>
      </div>
    </div>
  );
};

// Intelligence Mode (2ème couche)
const IntelligenceLayer = () => (
  <div className="space-y-6">
    {/* Toggle */}
    <div className="flex items-center justify-between">
      <div>
        <h2 className="text-2xl font-bold text-white flex items-center gap-2">
          <BarChart3 className="w-6 h-6 text-purple-400" />
          Intelligence Mode
        </h2>
        <p className="text-slate-400">Deep analytics and pattern detection</p>
      </div>
      <div className="flex items-center gap-2 px-4 py-2 bg-slate-900 rounded-xl border border-slate-800">
        <Badge className="bg-purple-500/20 text-purple-300">Creator</Badge>
        <span className="text-slate-400">|</span>
        <Badge className="bg-slate-800 text-slate-400">Intelligence</Badge>
      </div>
    </div>

    {/* Stats Cards */}
    <div className="grid grid-cols-4 gap-4">
      {[
        { label: 'Videos Analyzed', value: '50,247', change: '+12%', icon: Video, color: 'text-blue-400' },
        { label: 'Patterns Detected', value: '1,847', change: '+8%', icon: Target, color: 'text-purple-400' },
        { label: 'Avg Virality Score', value: '72.4', change: '+5%', icon: Flame, color: 'text-orange-400' },
        { label: 'Success Rate', value: '68%', change: '+15%', icon: TrendingUp, color: 'text-green-400' },
      ].map((stat, i) => (
        <div key={i} className="bg-slate-900/50 rounded-xl p-4 border border-slate-800">
          <div className="flex items-center justify-between mb-2">
            <span className="text-slate-400 text-sm">{stat.label}</span>
            <stat.icon className={`w-4 h-4 ${stat.color}`} />
          </div>
          <div className="flex items-end gap-2">
            <span className="text-2xl font-bold text-white">{stat.value}</span>
            <span className="text-green-400 text-sm">{stat.change}</span>
          </div>
        </div>
      ))}
    </div>

    {/* Charts Grid */}
    <div className="grid grid-cols-2 gap-6">
      {/* Top Patterns */}
      <div className="bg-slate-900/50 rounded-2xl p-6 border border-slate-800">
        <h3 className="text-white font-semibold mb-4 flex items-center gap-2">
          <BarChart3 className="w-5 h-5 text-purple-400" />Top Performing Patterns
        </h3>
        <div className="space-y-3">
          {[
            { pattern: 'Question Hook + Listicle', score: 94, volume: '2.4K videos' },
            { pattern: 'Story + Lesson Learned', score: 89, volume: '1.8K videos' },
            { pattern: 'Myth Busting Format', score: 86, volume: '1.2K videos' },
            { pattern: 'Before/After Reveal', score: 82, volume: '956 videos' },
          ].map((item, i) => (
            <div key={i} className="flex items-center gap-4">
              <span className="text-slate-500 w-6">{i + 1}</span>
              <div className="flex-1">
                <div className="flex items-center justify-between mb-1">
                  <span className="text-white text-sm">{item.pattern}</span>
                  <span className="text-purple-400 text-sm font-medium">{item.score}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Progress value={item.score} className="h-1.5 flex-1" />
                  <span className="text-slate-500 text-xs">{item.volume}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Trending Topics */}
      <div className="bg-slate-900/50 rounded-2xl p-6 border border-slate-800">
        <h3 className="text-white font-semibold mb-4 flex items-center gap-2">
          <Zap className="w-5 h-5 text-orange-400" />Trending Topics (7d)
        </h3>
        <div className="space-y-3">
          {[
            { topic: 'AI Tools', growth: '+245%', velocity: 'hot' },
            { topic: 'Productivity Hacks', growth: '+189%', velocity: 'rising' },
            { topic: 'Content Strategy', growth: '+156%', velocity: 'rising' },
            { topic: 'Side Hustles', growth: '+134%', velocity: 'stable' },
            { topic: 'Mindset Shifts', growth: '+98%', velocity: 'stable' },
          ].map((item, i) => (
            <div key={i} className="flex items-center justify-between py-2 border-b border-slate-800 last:border-0">
              <div className="flex items-center gap-3">
                <Hash className="w-4 h-4 text-slate-500" />
                <span className="text-white text-sm">{item.topic}</span>
              </div>
              <Badge className={
                item.velocity === 'hot' ? 'bg-red-500/20 text-red-400' :
                item.velocity === 'rising' ? 'bg-orange-500/20 text-orange-400' :
                'bg-green-500/20 text-green-400'
              }>{item.growth}</Badge>
            </div>
          ))}
        </div>
      </div>
    </div>

    {/* Hook Performance */}
    <div className="bg-slate-900/50 rounded-2xl p-6 border border-slate-800">
      <h3 className="text-white font-semibold mb-4 flex items-center gap-2">
        <Target className="w-5 h-5 text-blue-400" />Hook Performance by Type
      </h3>
      <div className="grid grid-cols-5 gap-4">
        {[
          { type: 'Question', avgViews: '450K', engagement: '8.5%', trend: 'up' },
          { type: 'Story', avgViews: '380K', engagement: '7.2%', trend: 'up' },
          { type: 'Listicle', avgViews: '520K', engagement: '9.1%', trend: 'up' },
          { type: 'Myth', avgViews: '290K', engagement: '6.8%', trend: 'down' },
          { type: 'CTA', avgViews: '180K', engagement: '4.5%', trend: 'stable' },
        ].map((hook, i) => (
          <div key={i} className="bg-slate-800/50 rounded-xl p-4 text-center">
            <p className="text-white font-medium mb-1">{hook.type}</p>
            <p className="text-2xl font-bold text-white mb-1">{hook.avgViews}</p>
            <p className="text-slate-400 text-sm mb-2">avg views</p>
            <div className="flex items-center justify-center gap-1">
              <Activity className="w-4 h-4 text-purple-400" />
              <span className="text-purple-400 text-sm">{hook.engagement}</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  </div>
);

// Main App
export default function App() {
  const [currentPage, setCurrentPage] = useState<Page>('home');
  const [workflowStep] = useState(1);
  const [intelligenceMode, setIntelligenceMode] = useState(false);

  const renderPage = () => {
    if (intelligenceMode && currentPage === 'home') {
      return <IntelligenceLayer />;
    }

    switch (currentPage) {
      case 'home':
        return (
          <div className="space-y-8">
            <OpportunityCard opportunity={viralPlayOfTheDay} featured />
            <section>
              <div className="flex items-center justify-between mb-6">
                <div>
                  <h2 className="text-xl font-bold text-white flex items-center gap-2">
                    <TrendingUp className="w-5 h-5 text-orange-400" />Trending Now
                  </h2>
                  <p className="text-slate-400 text-sm mt-1">Videos performing exceptionally well in your niche</p>
                </div>
                <Button variant="outline" className="border-slate-700 text-slate-300" onClick={() => setCurrentPage('opportunities')}>
                  View All<ChevronRight className="w-4 h-4 ml-1" />
                </Button>
              </div>
              <div className="grid grid-cols-4 gap-6">
                {trendingVideos.map(video => <VideoCard key={video.id} video={video} />)},
              </div>
            </section>
            <section>
              <div className="flex items-center justify-between mb-6">
                <div>
                  <h2 className="text-xl font-bold text-white flex items-center gap-2">
                    <Zap className="w-5 h-5 text-yellow-400" />More Opportunities
                  </h2>
                  <p className="text-slate-400 text-sm mt-1">Additional content ideas based on current trends</p>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                {opportunities.map(opp => <OpportunityCard key={opp.id} opportunity={opp} />)}
              </div>
            </section>
            <section className="bg-gradient-to-r from-purple-900/30 to-fuchsia-900/30 rounded-2xl p-8 border border-purple-500/20">
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="text-2xl font-bold text-white mb-2">Ready to create?</h2>
                  <p className="text-slate-400">Jump into the Studio and turn these insights into viral content</p>
                </div>
                <Button size="lg" className="bg-purple-600 hover:bg-purple-700 text-white px-8 h-14 text-lg font-semibold rounded-xl" onClick={() => setCurrentPage('studio')}>
                  <Sparkles className="w-5 h-5 mr-2" />Open Studio<ArrowRight className="w-5 h-5 ml-2" />
                </Button>
              </div>
            </section>
          </div>
        );
      case 'opportunities':
        return (
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-2xl font-bold text-white">Opportunities</h2>
                <p className="text-slate-400">All viral opportunities matched to your niche</p>
              </div>
              <div className="flex items-center gap-3">
                <Button variant="outline" className="border-slate-700 text-slate-300"><Video className="w-4 h-4 mr-2" />Format</Button>
                <Button variant="outline" className="border-slate-700 text-slate-300"><Hash className="w-4 h-4 mr-2" />Topic</Button>
                <Button variant="outline" className="border-slate-700 text-slate-300"><TrendingUp className="w-4 h-4 mr-2" />Trending</Button>
              </div>
            </div>
            <div className="grid grid-cols-4 gap-6">
              {[...trendingVideos, ...trendingVideos.slice(0, 2)].map((video, i) => <VideoCard key={`${video.id}-${i}`} video={video} />)},
            </div>
          </div>
        );
      case 'studio':
        return (
          <div className="space-y-8">
            <div className="flex items-center gap-4">
              <Button variant="outline" size="icon" onClick={() => setCurrentPage('home')} className="border-slate-700">
                <ChevronLeft className="w-5 h-5" />
              </Button>
              <div>
                <h2 className="text-2xl font-bold text-white">Studio Creation</h2>
                <p className="text-slate-400">Choose your creation mode</p>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-6">
              {[
                { icon: Lightbulb, title: 'Start from Opportunity', desc: 'Use a viral opportunity from our database', badge: 'Recommended', color: 'from-purple-500 to-fuchsia-500' },
                { icon: FileText, title: 'Script to Video', desc: 'Turn your script into a complete video blueprint', color: 'from-blue-500 to-cyan-500' },
                { icon: Layers, title: 'Viral Templates', desc: 'Start from proven templates', color: 'from-green-500 to-emerald-500' },
                { icon: User, title: 'AI Avatar', desc: 'Create videos with your AI avatar', badge: 'Popular', color: 'from-orange-500 to-amber-500' },
                { icon: Film, title: 'Video Remix', desc: 'Transform existing videos with AI', badge: 'Pro', disabled: true, color: 'from-pink-500 to-rose-500' },
              ].map((mode, i) => (
                <div key={i} className={`relative bg-slate-900/50 rounded-2xl p-6 border border-slate-800 transition-all ${mode.disabled ? 'opacity-50 cursor-not-allowed' : 'hover:border-purple-500/50 cursor-pointer group'}`}>
                  {mode.badge && <Badge className="absolute top-4 right-4 bg-purple-500/20 text-purple-300 text-xs">{mode.badge}</Badge>}
                  <div className={`w-14 h-14 rounded-2xl bg-gradient-to-br ${mode.color} flex items-center justify-center mb-4 group-hover:scale-110 transition-transform`}>
                    <mode.icon className="w-7 h-7 text-white" />
                  </div>
                  <h3 className="text-white font-semibold text-lg mb-2">{mode.title}</h3>
                  <p className="text-slate-400 text-sm">{mode.desc}</p>
                  {!mode.disabled && <div className="mt-4 flex items-center text-purple-400 text-sm font-medium opacity-0 group-hover:opacity-100 transition-opacity">Start Creating<ArrowRight className="w-4 h-4 ml-1" /></div>}
                </div>
              ))}
            </div>
          </div>
        );
      case 'workspace':
        return (
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-2xl font-bold text-white">Workspace</h2>
                <p className="text-slate-400">All your projects and saved content</p>
              </div>
            </div>
            <Tabs defaultValue="ideas" className="w-full">
              <TabsList className="bg-slate-900/50 border border-slate-800">
                <TabsTrigger value="ideas" className="data-[state=active]:bg-purple-500/20 data-[state=active]:text-purple-300"><Lightbulb className="w-4 h-4 mr-2" />Generated Ideas</TabsTrigger>
                <TabsTrigger value="scripts" className="data-[state=active]:bg-purple-500/20 data-[state=active]:text-purple-300"><FileText className="w-4 h-4 mr-2" />Created Scripts</TabsTrigger>
                <TabsTrigger value="saved" className="data-[state=active]:bg-purple-500/20 data-[state=active]:text-purple-300"><Bookmark className="w-4 h-4 mr-2" />Saved Inspirations</TabsTrigger>
              </TabsList>
              <TabsContent value="ideas" className="mt-6">
                <div className="grid grid-cols-4 gap-4">
                  {projects.filter(p => p.status === 'idea').map(project => (
                    <div key={project.id} className="bg-slate-900/50 rounded-xl p-4 border border-slate-800">
                      <StatusBadge status={project.status} />
                      <p className="text-white font-medium text-sm mt-3 line-clamp-2">{project.hook}</p>
                      <div className="flex items-center justify-between mt-3">
                        <span className="text-xs text-slate-400">{project.createdAt}</span>
                        <ViralityBadge score={project.viralityScore} />
                      </div>
                    </div>
                  ))}
                </div>
              </TabsContent>
              <TabsContent value="scripts" className="mt-6">
                <div className="grid grid-cols-4 gap-4">
                  {projects.filter(p => p.status === 'script' || p.status === 'blueprint').map(project => (
                    <div key={project.id} className="bg-slate-900/50 rounded-xl p-4 border border-slate-800">
                      <StatusBadge status={project.status} />
                      <p className="text-white font-medium text-sm mt-3 line-clamp-2">{project.hook}</p>
                      <div className="flex items-center justify-between mt-3">
                        <span className="text-xs text-slate-400">{project.createdAt}</span>
                        <ViralityBadge score={project.viralityScore} />
                      </div>
                    </div>
                  ))}
                </div>
              </TabsContent>
              <TabsContent value="saved" className="mt-6">
                <div className="grid grid-cols-4 gap-4">
                  {trendingVideos.slice(0, 3).map(video => <VideoCard key={video.id} video={video} compact />)}
                </div>
              </TabsContent>
            </Tabs>
          </div>
        );
      case 'insights':
        return (
          <div className="space-y-6">
            <div>
              <h2 className="text-2xl font-bold text-white">Insights</h2>
              <p className="text-slate-400">Advanced analytics and intelligence</p>
            </div>
            <div className="grid grid-cols-2 gap-6">
              {[
                { title: 'Niche Growth Charts', icon: LineChart, desc: 'Track your niche performance over time' },
                { title: 'Hook Performance', icon: Target, desc: 'See which hooks drive the most engagement' },
                { title: 'Format Success Rates', icon: PieChart, desc: 'Compare performance across video formats' },
                { title: 'Trend Velocity', icon: Activity, desc: 'Identify emerging trends before they peak' },
              ].map((item, i) => (
                <div key={i} className="bg-slate-900/50 rounded-2xl p-8 border border-slate-800 flex flex-col items-center text-center">
                  <div className="w-16 h-16 rounded-2xl bg-purple-500/20 flex items-center justify-center mb-4">
                    <item.icon className="w-8 h-8 text-purple-400" />
                  </div>
                  <h3 className="text-white font-semibold text-lg mb-2">{item.title}</h3>
                  <p className="text-slate-400 mb-4">{item.desc}</p>
                  <Badge className="bg-slate-800 text-slate-400">Coming Soon</Badge>
                </div>
              ))}
            </div>
          </div>
        );
      case 'settings':
        return <SettingsPage />;
      case 'billing':
        return <BillingPage />;
      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-200 font-sans">
      {/* Sidebar */}
      <aside className="fixed left-0 top-0 h-full w-64 bg-slate-900/80 backdrop-blur-xl border-r border-slate-800">
        <div className="p-6 flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-purple-600 to-fuchsia-600 flex items-center justify-center flex-shrink-0">
            <Sparkles className="w-5 h-5 text-white" />
          </div>
          <span className="text-xl font-bold text-white">Craflect</span>
        </div>
        
        <nav className="px-3 space-y-1">
          <SidebarItem icon={Home} label="Home" active={currentPage === 'home'} onClick={() => setCurrentPage('home')} />
          <SidebarItem icon={Compass} label="Opportunities" badge="3 new" active={currentPage === 'opportunities'} onClick={() => setCurrentPage('opportunities')} />
          <SidebarItem icon={PlusCircle} label="Create" active={currentPage === 'studio'} onClick={() => setCurrentPage('studio')} />
          <SidebarItem icon={FolderOpen} label="Workspace" active={currentPage === 'workspace'} onClick={() => setCurrentPage('workspace')} />
          <SidebarItem icon={BarChart3} label="Insights" active={currentPage === 'insights'} onClick={() => setCurrentPage('insights')} />
        </nav>
        
        <div className="mt-8 px-3 space-y-1">
          <div className="px-4 py-2 text-xs font-semibold text-slate-500 uppercase tracking-wider">Settings</div>
          <SidebarItem icon={Settings} label="Settings" active={currentPage === 'settings'} onClick={() => setCurrentPage('settings')} />
          <SidebarItem icon={CreditCard} label="Plan & Billing" active={currentPage === 'billing'} onClick={() => setCurrentPage('billing')} />
        </div>
        
        <div className="absolute bottom-0 left-0 right-0 p-4 border-t border-slate-800">
          <div className="flex items-center gap-3">
            <Avatar className="w-10 h-10">
              <AvatarFallback className="bg-gradient-to-br from-purple-500 to-fuchsia-500 text-white">JD</AvatarFallback>
            </Avatar>
            <div className="flex-1 min-w-0">
              <p className="text-white font-medium text-sm truncate">John Doe</p>
              <p className="text-slate-500 text-xs">Creator Plan</p>
            </div>
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <main className="ml-64">
        {/* Header */}
        <header className="sticky top-0 z-40 bg-slate-950/80 backdrop-blur-xl border-b border-slate-800">
          <div className="flex items-center justify-between px-8 py-4">
            <div className="flex items-center gap-2 text-sm">
              <span className="text-slate-400">Dashboard</span>
              <ChevronRight className="w-4 h-4 text-slate-600" />
              <span className="text-white font-medium capitalize">{currentPage}</span>
            </div>
            
            <div className="flex items-center gap-4">
              {/* Mode Toggle - Only on Home */}
              {currentPage === 'home' && (
                <div className="flex items-center gap-2 px-2 py-1 bg-slate-900 rounded-lg border border-slate-800">
                  <button
                    onClick={() => setIntelligenceMode(false)}
                    className={`px-3 py-1.5 rounded-md text-sm font-medium transition-all ${!intelligenceMode ? 'bg-purple-600 text-white' : 'text-slate-400 hover:text-white'}`}
                  >
                    <Sparkles className="w-4 h-4 inline mr-1" />Creator
                  </button>
                  <button
                    onClick={() => setIntelligenceMode(true)}
                    className={`px-3 py-1.5 rounded-md text-sm font-medium transition-all ${intelligenceMode ? 'bg-purple-600 text-white' : 'text-slate-400 hover:text-white'}`}
                  >
                    <BarChart3 className="w-4 h-4 inline mr-1" />Intelligence
                  </button>
                </div>
              )}
              
              <Button size="icon" variant="outline" className="border-slate-700">
                <Bell className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </header>

        {/* Content */}
        <div className="p-8 pb-32">
          {renderPage()}
        </div>

        {/* Guided Workflow - Only on Home in Creator mode */}
        {currentPage === 'home' && !intelligenceMode && (
          <GuidedWorkflow currentStep={workflowStep} />
        )}
      </main>
    </div>
  );
}

// Mail Icon component
const MailIcon = ({ className }: { className?: string }) => (
  <svg className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
  </svg>
);
