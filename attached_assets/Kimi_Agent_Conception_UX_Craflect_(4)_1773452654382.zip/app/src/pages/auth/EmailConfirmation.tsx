import { useEffect, useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Mail, ArrowRight, RefreshCw, CheckCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';

export function EmailConfirmation() {
  const location = useLocation();
  const email = location.state?.email || 'your email';
  const [countdown, setCountdown] = useState(60);
  const [canResend, setCanResend] = useState(false);
  const [isResending, setIsResending] = useState(false);
  const [resent, setResent] = useState(false);

  useEffect(() => {
    if (countdown > 0) {
      const timer = setTimeout(() => setCountdown(countdown - 1), 1000);
      return () => clearTimeout(timer);
    } else {
      setCanResend(true);
    }
  }, [countdown]);

  const handleResend = async () => {
    setIsResending(true);
    await new Promise(resolve => setTimeout(resolve, 1500));
    setIsResending(false);
    setResent(true);
    setCountdown(60);
    setCanResend(false);
    setTimeout(() => setResent(false), 3000);
  };

  return (
    <div className="min-h-screen bg-[#0a0a0f] flex flex-col">
      {/* Header */}
      <header className="p-6">
        <Link to="/" className="flex items-center gap-2">
          <div className="w-10 h-10 bg-gradient-to-br from-violet-600 to-fuchsia-600 rounded-xl flex items-center justify-center">
            <span className="text-white font-bold text-lg">C</span>
          </div>
          <span className="text-white font-bold text-xl">Craflect</span>
        </Link>
      </header>

      {/* Main Content */}
      <main className="flex-1 flex items-center justify-center px-6 py-12">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="w-full max-w-md text-center"
        >
          {/* Icon */}
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ delay: 0.2, type: 'spring', stiffness: 200 }}
            className="w-24 h-24 bg-violet-500/10 rounded-full flex items-center justify-center mx-auto mb-8"
          >
            <Mail className="w-12 h-12 text-violet-500" />
          </motion.div>

          {/* Title */}
          <h1 className="text-3xl font-bold text-white mb-4">Verify your email</h1>
          <p className="text-gray-400 mb-8">
            We've sent a verification link to{' '}
            <span className="text-white font-medium">{email}</span>. 
            Click the link to verify your account and continue.
          </p>

          {/* Success Message */}
          {resent && (
            <motion.div
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              className="mb-6 p-4 bg-emerald-500/10 border border-emerald-500/20 rounded-xl flex items-center justify-center gap-2"
            >
              <CheckCircle className="w-5 h-5 text-emerald-500" />
              <span className="text-emerald-400">Email resent successfully!</span>
            </motion.div>
          )}

          {/* Resend */}
          <div className="mb-8">
            <p className="text-gray-500 mb-4">Didn't receive the email?</p>
            <Button
              variant="outline"
              onClick={handleResend}
              disabled={!canResend || isResending}
              className="h-12 px-6 border-gray-700 text-gray-300 hover:bg-gray-800 hover:text-white rounded-xl transition-all disabled:opacity-50"
            >
              {isResending ? (
                <motion.div
                  animate={{ rotate: 360 }}
                  transition={{ duration: 1, repeat: Infinity, ease: 'linear' }}
                  className="w-5 h-5 border-2 border-gray-500 border-t-transparent rounded-full"
                />
              ) : (
                <>
                  <RefreshCw className={`w-4 h-4 mr-2 ${!canResend ? 'opacity-50' : ''}`} />
                  {canResend ? 'Resend email' : `Resend in ${countdown}s`}
                </>
              )}
            </Button>
          </div>

          {/* Tips */}
          <div className="p-6 bg-[#1a1a24] rounded-2xl mb-8">
            <h3 className="text-white font-medium mb-3">Tips:</h3>
            <ul className="text-left text-gray-400 space-y-2 text-sm">
              <li className="flex items-start gap-2">
                <span className="text-violet-500 mt-0.5">•</span>
                Check your spam or junk folder
              </li>
              <li className="flex items-start gap-2">
                <span className="text-violet-500 mt-0.5">•</span>
                Make sure your email address is correct
              </li>
              <li className="flex items-start gap-2">
                <span className="text-violet-500 mt-0.5">•</span>
                Add noreply@craflect.com to your contacts
              </li>
            </ul>
          </div>

          {/* Continue (for demo) */}
          <Link to="/onboarding">
            <Button className="h-14 px-8 bg-gradient-to-r from-violet-600 to-fuchsia-600 hover:from-violet-500 hover:to-fuchsia-500 text-white font-semibold rounded-xl transition-all">
              I've verified my email
              <ArrowRight className="w-5 h-5 ml-2" />
            </Button>
          </Link>
        </motion.div>
      </main>
    </div>
  );
}
