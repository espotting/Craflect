import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { Welcome } from '@/pages/auth/Welcome';
import { SignIn } from '@/pages/auth/SignIn';
import { SignUp } from '@/pages/auth/SignUp';
import { ForgotPassword } from '@/pages/auth/ForgotPassword';
import { EmailConfirmation } from '@/pages/auth/EmailConfirmation';
import { Admin2FA } from '@/pages/auth/Admin2FA';
import { Onboarding } from '@/pages/onboarding/Onboarding';

function App() {
  return (
    <BrowserRouter>
      <Routes>
        {/* Auth Routes */}
        <Route path="/welcome" element={<Welcome />} />
        <Route path="/signin" element={<SignIn />} />
        <Route path="/signup" element={<SignUp />} />
        <Route path="/forgot-password" element={<ForgotPassword />} />
        <Route path="/email-confirmation" element={<EmailConfirmation />} />
        <Route path="/admin-2fa" element={<Admin2FA />} />
        
        {/* Onboarding */}
        <Route path="/onboarding" element={<Onboarding />} />
        
        {/* Redirects */}
        <Route path="/" element={<Navigate to="/welcome" replace />} />
        <Route path="*" element={<Navigate to="/welcome" replace />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;
